package com.jpony;

import java.util.EventObject;

public interface TimerStateListener {
    
    public void updateTimers(float tpf); 
    
}
