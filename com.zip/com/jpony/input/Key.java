package com.jpony.input;

import com.jme3.input.controls.InputListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.input.controls.MouseButtonTrigger;
import com.jme3.input.controls.Trigger;
import com.jpony.GameManager;

/**
 * The Key class represents any input key. This can be from the keyboard ,
 * mouse , or hand held controller.
 * @author beer money
 */
public class Key {
    
    private final GameManager     gameManager;
    
    public String                 name;
    
    public boolean                pressed = false;
    public boolean                released = false;
    public boolean                down = false;
    public boolean                up = false;
    
    public boolean                triggered = false;
    
    private boolean               interruptIdle = false;
    
    public Key(String name,GameManager gameManager){
        this.name = name;
        this.gameManager = gameManager;
    }
    
    /**
     * Determines if the key is pressed , released , up or down.
     * For internal use only.
     */
    public void update(){
        if (triggered){  
          
          pressed = !down && !pressed; // The initiating mouse click
          down = true;
          up = false;
        } else { // the left button is not pressed
           if (released){
               released = false;
           }
           if (down){
               // button released
               down = false;
               pressed = false;
               released = true;
           }
           up = true;
        }
    }
    
    /**
     * Adds a key trigger to they key. The input manager is
     * automatically registered as a listener.
     * @param key The key trigger to add.
     */
    public void addKeyTrigger(int key){
       gameManager.app.getInputManager().addMapping(name, new KeyTrigger(key));
    }
    
    /**
     * Adds a mouse trigger to they key. The input manager is
     * automatically registered as a listener.
     * @param mouseKey The mouse trigger to add.
     */
    public void addMouseTrigger(int mouseKey){
       gameManager.app.getInputManager().addMapping(name, new MouseButtonTrigger(mouseKey)); 
    }
    
    /**
     * Deletes the keys mappings.
     */
    public void removeMapping(){
       gameManager.app.getInputManager().deleteMapping(name);
    }
    
    /**
     * Removes the specified key trigger.
     * @param trigger The trigger to remove.
     */
    public void removeTrigger(Trigger trigger){
       gameManager.app.getInputManager().deleteTrigger(name, trigger);
    }
    
    /**
     * Adds a listener to they key
     * @param listener The listener
     */
    public void addListener(InputListener listener){
       gameManager.app.getInputManager().addListener(listener, name);
    }
    
    /**
     * @return Does the key interrupt the idle state.
     */
    public boolean isInterruptIdle() {
        return interruptIdle;
    }

    /**
     * Setting to true will cause the player
     * idle state to be set to active when the key is triggered. This
     * is typically used for keys that play animations.
     * @param interruptIdle Will the key interrupt the idle state.
     */
    public void setInterruptIdle(boolean interruptIdle) {
        this.interruptIdle = interruptIdle;
    }


}
