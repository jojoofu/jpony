package com.jpony.input;

public interface InputManagerListener {
    
    /**
     * This event fires when the input manager becomes idle.
     * It will become idle when no input is incoming.
     * @param idle Is the input manager idle.
     */
    public void inputIdleStateChange(boolean idle);
    
    /**
     * This event fires when the input manager is disabled/enabled.
     * @param enabled Is the input manager enabled.
     */
    public void inputEnabledStateChange(boolean enabled);
    
}
