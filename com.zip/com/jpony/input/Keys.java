package com.jpony.input;

public class Keys {
    
    public static final String[]            KEYS =  {
      "LEFT",
      "RIGHT",
      "FORWARD",
      "BACKWARD",
      "TURN_LEFT",
      "TURN_RIGHT",
      "UP",
      "DOWN",
      "JUMP",
      "ACTION",
      "MOVE_CAMERA",
      "ACTION2",
      "VIEW_FPS",
      "VIEW_TP",
      "VIEW_TD",
      "RESET_CAMERA",
      "MOUSE_LEFT",
      "MOUSE_RIGHT",
      "MOUSE_UP",
      "MOUSE_DOWN",
      "MOUSE_BUTTON_LEFT",
      "MOUSE_BUTTON_RIGHT",
      "MOUSE_BUTTON_MIDDLE",
      "WHEEL_FORWARD",
      "WHEEL_BACKWARD"
    };
    
    public static final String              LEFT = "LEFT";
    public static final String              RIGHT = "RIGHT";
    public static final String              TURN_LEFT = "TURN_LEFT";
    public static final String              TURN_RIGHT = "TURN_RIGHT";
    public static final String              FORWARD = "FORWARD";
    public static final String              BACKWARD = "BACKWARD";
    public static final String              UP = "UP";
    public static final String              DOWN = "DOWN";
    public static final String              JUMP = "JUMP";
    public static final String              ACTION = "ACTION";
    public static final String              MOVE_CAMERA = "MOVE_CAMERA";
    public static final String              ACTION2 = "ACTION2";
    public static final String              VIEW_FPS = "VIEW_FPS";
    public static final String              VIEW_TP = "VIEW_TP";
    public static final String              VIEW_TD = "VIEW_TD";
    public static final String              RESET_CAMERA = "RESET_CAMERA";
    
    // MOUSE KEYS
    public static final String              MOUSE_LEFT = "MOUSE_LEFT";
    public static final String              MOUSE_RIGHT = "MOUSE_RIGHT";
    public static final String              MOUSE_UP = "MOUSE_UP";
    public static final String              MOUSE_DOWN = "MOUSE_DOWN";
    public static final String              MOUSE_BUTTON_LEFT = "MOUSE_BUTTON_LEFT";
    public static final String              MOUSE_BUTTON_RIGHT = "MOUSE_BUTTON_RIGHT";
    public static final String              MOUSE_BUTTON_MIDDLE = "MOUSE_BUTTON_MIDDLE";
    public static final String              WHEEL_FORWARD = "WHEEL_FORWARD";
    public static final String              WHEEL_BACKWARD = "WHEEL_BACKWARD";
    
}
