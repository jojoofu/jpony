package com.jpony.input;

public interface ControlInterface {
    
    public void initialize();
    
    public void update(float tpf);
    
    public void cleanUp();
    
}
