package com.jpony.input;

import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.input.controls.MouseButtonTrigger;
import com.jpony.GameManager;
import com.jme3.cursors.plugins.JmeCursor;
import com.jme3.input.RawInputListener;
import com.jme3.input.controls.AnalogListener;
import com.jme3.input.controls.InputListener;
import com.jme3.input.controls.MouseAxisTrigger;
import com.jme3.input.event.JoyAxisEvent;
import com.jme3.input.event.JoyButtonEvent;
import com.jme3.input.event.KeyInputEvent;
import com.jme3.input.event.MouseButtonEvent;
import com.jme3.input.event.MouseMotionEvent;
import com.jme3.input.event.TouchEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The input manager handles setting up keys for use in JPony. JPony
 * keys are unviresally accessible through the game manager. You only
 * need to register keys once to use them anywhere through out your
 * application.
 * @author beer money
 */
public class InputManager implements ActionListener , AnalogListener {

private boolean                      idle = true;
private boolean                      enabled = true;

private final GameManager            gameManager; 

public List<Key>                     keys = new ArrayList<>();
private final List                   listener = new ArrayList();


public InputManager(GameManager gameManager){
    
     this.gameManager = gameManager;
     initialize();
     map();
     
}

/**
 * Adds an input manager listener
 * @param listener The listener to add.
 */
public synchronized void addListener(InputManagerListener listener) {
        this.listener.add(listener);
}
   
/**
 * Removes an input manager listener
 * @param listener The listener to remove.
 */
public synchronized void removeListener(InputManagerListener listener) {
        this.listener.remove(listener);
}

private synchronized void fireIdleStateChanged(boolean idle) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((InputManagerListener)iterator.next()).inputIdleStateChange(idle);
        }
}

private synchronized void fireEnabledStateChanged(boolean enabled) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((InputManagerListener)iterator.next()).inputEnabledStateChange(idle);
        }
}

// create our default keys.
private void initialize(){
    keys.add(new Key(Keys.LEFT,gameManager));
    keys.add(new Key(Keys.RIGHT,gameManager));
    keys.add(new Key(Keys.FORWARD,gameManager));
    keys.add(new Key(Keys.BACKWARD,gameManager));
    keys.add(new Key(Keys.TURN_LEFT,gameManager));
    keys.add(new Key(Keys.TURN_RIGHT,gameManager));
    keys.add(new Key(Keys.UP,gameManager));
    keys.add(new Key(Keys.DOWN,gameManager));
    keys.add(new Key(Keys.JUMP,gameManager));
    keys.add(new Key(Keys.ACTION,gameManager));
    keys.add(new Key(Keys.MOVE_CAMERA,gameManager));
    keys.add(new Key(Keys.ACTION2,gameManager));
    keys.add(new Key(Keys.VIEW_FPS,gameManager));
    keys.add(new Key(Keys.VIEW_TP,gameManager));
    keys.add(new Key(Keys.VIEW_TD,gameManager));
    keys.add(new Key(Keys.RESET_CAMERA,gameManager));
    keys.add(new Key(Keys.MOUSE_LEFT,gameManager));
    keys.add(new Key(Keys.MOUSE_RIGHT,gameManager));
    keys.add(new Key(Keys.MOUSE_UP,gameManager));
    keys.add(new Key(Keys.MOUSE_DOWN,gameManager));
    keys.add(new Key(Keys.MOUSE_BUTTON_LEFT,gameManager));
    keys.add(new Key(Keys.MOUSE_BUTTON_RIGHT,gameManager));
    keys.add(new Key(Keys.MOUSE_BUTTON_MIDDLE,gameManager));
    keys.add(new Key(Keys.WHEEL_FORWARD,gameManager));
    keys.add(new Key(Keys.WHEEL_BACKWARD,gameManager));
}

/**
 * Update the key state for each key. This is for internal use only.
 * Calling update outside the main game loop will cause the game 
 * to crash.
 */
public void update(){
    
    for (Key key : keys){
        key.update();
    }
    
    for (Key key : keys){
        if (key.triggered && key.isInterruptIdle()){
            setIdle(false);
            return;
        }
    }
        setIdle(true);
}

/**
 * Returns the specified key
 * @param name The name of the key to return.
 * @return <code>Key</code>
 */
public Key key(String name){
    for (Key key : keys){
        if (key.name.equals(name)){
            return key;
        }
    }
    return null;
}

// What happens when a key is pressed
@Override
public void onAction(String binding, boolean isPressed, float tpf) {
    
    if (!enabled){
        return;
    } 
    
    for (Key key : keys){
        if (binding.equals(key.name)){
           key.triggered = isPressed;
        }
    }

    
}
   
// Set what keys control each function of the player
private void map() {
    
    gameManager.app.getInputManager().addMapping(Keys.LEFT, new KeyTrigger(KeyInput.KEY_A));
    gameManager.app.getInputManager().addMapping(Keys.RIGHT, new KeyTrigger(KeyInput.KEY_D));
    gameManager.app.getInputManager().addMapping(Keys.FORWARD, new KeyTrigger(KeyInput.KEY_W));
    gameManager.app.getInputManager().addMapping(Keys.BACKWARD, new KeyTrigger(KeyInput.KEY_S));
    gameManager.app.getInputManager().addMapping(Keys.TURN_LEFT, new KeyTrigger(KeyInput.KEY_Q));
    gameManager.app.getInputManager().addMapping(Keys.TURN_RIGHT, new KeyTrigger(KeyInput.KEY_E));
    gameManager.app.getInputManager().addMapping(Keys.UP, new KeyTrigger(KeyInput.KEY_ADD));
    gameManager.app.getInputManager().addMapping(Keys.DOWN, new KeyTrigger(KeyInput.KEY_MINUS));
    gameManager.app.getInputManager().addMapping(Keys.JUMP, new KeyTrigger(KeyInput.KEY_SPACE));
    gameManager.app.getInputManager().addMapping(Keys.ACTION, new MouseButtonTrigger(MouseInput.BUTTON_LEFT));
    gameManager.app.getInputManager().addMapping(Keys.MOVE_CAMERA, new MouseButtonTrigger(MouseInput.BUTTON_RIGHT));
    gameManager.app.getInputManager().addMapping(Keys.ACTION2, new KeyTrigger(KeyInput.KEY_F9));
    gameManager.app.getInputManager().addMapping(Keys.VIEW_FPS, new KeyTrigger(KeyInput.KEY_F1));
    gameManager.app.getInputManager().addMapping(Keys.VIEW_TP, new KeyTrigger(KeyInput.KEY_F2));
    gameManager.app.getInputManager().addMapping(Keys.VIEW_TD, new KeyTrigger(KeyInput.KEY_F3));
    gameManager.app.getInputManager().addMapping(Keys.RESET_CAMERA, new MouseButtonTrigger(MouseInput.BUTTON_MIDDLE));
    gameManager.app.getInputManager().addMapping(Keys.MOUSE_LEFT, new MouseAxisTrigger(MouseInput.AXIS_X, true));
    gameManager.app.getInputManager().addMapping(Keys.MOUSE_RIGHT, new MouseAxisTrigger(MouseInput.AXIS_X, false));
    gameManager.app.getInputManager().addMapping(Keys.MOUSE_UP, new MouseAxisTrigger(MouseInput.AXIS_Y, false));
    gameManager.app.getInputManager().addMapping(Keys.MOUSE_DOWN, new MouseAxisTrigger(MouseInput.AXIS_Y, true));
    gameManager.app.getInputManager().addMapping(Keys.MOUSE_BUTTON_LEFT, new MouseButtonTrigger(MouseInput.BUTTON_LEFT));
    gameManager.app.getInputManager().addMapping(Keys.MOUSE_BUTTON_RIGHT, new MouseButtonTrigger(MouseInput.BUTTON_RIGHT));
    gameManager.app.getInputManager().addMapping(Keys.MOUSE_BUTTON_MIDDLE, new MouseButtonTrigger(MouseInput.BUTTON_MIDDLE));
    gameManager.app.getInputManager().addMapping(Keys.WHEEL_FORWARD, new MouseAxisTrigger(MouseInput.AXIS_WHEEL, false));
    gameManager.app.getInputManager().addMapping(Keys.WHEEL_BACKWARD, new MouseAxisTrigger(MouseInput.AXIS_WHEEL, true));
    
    for (Key key : keys){
      key.addListener(this);
    }
    
  }
  
/**
 * Adds an input listener for every key in the manager.
 * @param listener The listener
 */
  public void add(InputListener listener){
      for (Key key : keys){
      key.addListener(this);
      }
  }
  
  /**
   * Adds an analog listener for every key in the manager.
   * @param listener The listener
   */
  public void addAnalogListener(AnalogListener listener){
      for (Key key : keys){
      key.addListener(listener);
      }
  }
  
  /**
   * Adds an action listener for every key in the manager.
   * @param listener The listener
   */
  public void addActionListener(ActionListener listener){
      for (Key key : keys){
      key.addListener(listener);
      }
  }
  
    /**
     * @return Is the key manager idle. Returns idle if no keys are pressed.
     * You may add exceptions to the idle state. The exceptional keys can be
     * pressed while the key manager is idle but will not change the idle state.
     */
    public boolean isIdle() {
        return idle;
    }

    /**
     * @param idle Sets the key manager to idle. For internal use only.
     */
    public void setIdle(boolean idle) {
        if (idle != this.idle){
            fireIdleStateChanged(idle);
        }
        this.idle = idle;
    }

    /**
     * @return Is the key manager enabled.
     */
    public boolean isEnabled() {
        return enabled;
    }

    /**
     * @param enabled Set to enable the key manager. For internal use only.
     */
    public void setEnabled(boolean enabled) {
         if (enabled != this.enabled){
            fireEnabledStateChanged(enabled);
         }
         this.enabled = enabled;
         if (!enabled){
             for (Key key : keys){
              key.triggered = false;
              key.down = false;
              key.released = false;
              key.up = false;
              key.pressed = false;
             }
          setIdle(true);
         } else if (enabled){
            
         }
    }

    @Override
    public void onAnalog(String name, float value, float tpf) {
        

    
    }
 
}
