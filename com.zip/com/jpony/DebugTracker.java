package com.jpony;

import com.jpony.UI.UserInterface;
import static com.jpony.JponyConstants.*;
import com.jpony.UI.Label;

/**
 * Provides 3 label controls for monitoring your application.
 * @author beer money
 */
public class DebugTracker {
    
    private final GameManager           gameManager;
    private UserInterface               UI;
    
    public long                         start;
    public long                         stop;
    
    public DebugTracker(GameManager gameManager){
        this.gameManager = gameManager;
        initialize();
    }
    
    // Set up the debugger
    private void initialize(){
        
    UI = new UserInterface(DEBUG_UI,gameManager);
    UI.createLabel(DEBUG1);
    UI.getControl(DEBUG1,Label.class).setSize(500,50);
    UI.getControl(DEBUG1,Label.class).setLocation(50,500);
    UI.createLabel(DEBUG2);
    UI.getControl(DEBUG2,Label.class).setSize(500,50);
    UI.getControl(DEBUG2,Label.class).setLocation(50,600);
    UI.createLabel(DEBUG3);
    UI.getControl(DEBUG3,Label.class).setSize(500,50);
    UI.getControl(DEBUG3,Label.class).setLocation(50,700);
    gameManager.UImanager.add(UI);
    
    }
    
    /**
     * Updates the debugger. This is called each loop. Override this function
     * to input your custom debug code.
     */
    public void update(){

    }
    
    /**
     * Show the debug tracker interface
     */
    public void show(){
        UI.setDisplayed(true);
    }
    
    /**
     * Hide the debug tracker interface.
     */
    public void hide(){
        UI.setDisplayed(false);
    }
    
    /**
     * Sets the text of the debug1 label
     * @param text The text to set.
     */
    public void setDebug1Text(String text){
        UI.getControl(DEBUG1,Label.class).setText(text);
    }
    
    /**
     * Sets the text of the debug1 label
     * @param text The text to set.
     */
    public void setDebug2Text(String text){
        UI.getControl(DEBUG2,Label.class).setText(text);
    }
    
    /**
     * Sets the text of the debug3 label
     * @param text The text to set.
     */
    public void setDebug3Text(String text){
        UI.getControl(DEBUG3,Label.class).setText(text);
    }
    
}
