package com.jpony.player;

import com.jpony.physics.PhysicsConstants;
import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import java.io.IOException;

/**
 * The player control allows you control the player entity behavior.
 * @author beer money
 */
public class PlayerControl extends AbstractControl {
    
    private float                 speed = 6;
    private float                 strafeSpeed = 4;
    private float                 turnSpeed = 3;
    private String                zone = "default";
    private Vector3f              collisionCapsule = new Vector3f(1,3,90);
    private Vector3f              jumpForce = new Vector3f(0,5,0);
    private Vector3f              gravity = new Vector3f(0,0,0);
    private float                 physicsDampening = 0.8f;
    private ControlMode           controlMode = ControlMode.FIRST_PERSON;
    public  Node                  collisionNode = new Node(PhysicsConstants.COLLISION_NODE);
    
    private boolean               disableStrafe = false;
    private boolean               disableTurn = false;
    private float                 slopeIntensity = 0.10f;
    
    @Override
    protected void controlUpdate(float tpf) {
        //TODO: add code that controls Spatial,
        //e.g. spatial.rotate(tpf,tpf,tpf);
    }
    
    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        //Only needed for rendering-related operations,
        //not called when spatial is culled.
    }
    
    public Control cloneForSpatial(Spatial spatial) {
        PlayerControl control = new PlayerControl();
        //TODO: copy parameters to new Control
        return control;
    }
    
    @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //TODO: load properties of this Control, e.g.
        //this.value = in.readFloat("name", defaultValue);
        this.speed = in.readFloat("speed",6);
        this.strafeSpeed = in.readFloat("strafeSpeed",4);
        this.zone = in.readString("zone", "default");
        this.jumpForce = (Vector3f)in.readSavable("jumpForce", new Vector3f(0,5,0));
        this.gravity = (Vector3f)in.readSavable("gravity", new Vector3f(0,0,0));
        this.physicsDampening = in.readFloat("physicsDampening",0.8f);
        this.controlMode = in.readEnum("controlMode",ControlMode.class,ControlMode.FIRST_PERSON);
        this.collisionCapsule = (Vector3f)in.readSavable("collisionCapsule", new Vector3f(1,3,90));
        this.turnSpeed = in.readFloat("turnSpeed",3);
        this.disableStrafe = in.readBoolean("disableStrafe",false);
        this.disableTurn = in.readBoolean("disableTurn",false);
        this.slopeIntensity = in.readFloat("slopeIntensity",0.10f);
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        //TODO: save properties of this Control, e.g.
        //out.write(this.value, "name", defaultValue);
        out.write(this.speed,"speed",6);
        out.write(this.strafeSpeed,"strafeSpeed",4);
        out.write(this.zone,"zone","default");
        out.write(this.jumpForce, "jumpForce", new Vector3f(0,5,0));
        out.write(this.gravity, "gravity", new Vector3f(0,0,0));
        out.write(this.physicsDampening,"physicsDampening",0.8f);
        out.write(this.controlMode,"controlMode",ControlMode.FIRST_PERSON);
        out.write(this.collisionCapsule, "collisionCapsule", new Vector3f(1,3,90));
        out.write(this.turnSpeed,"turnSpeed",3);
        out.write(this.disableStrafe,"disableStrafe",false);
        out.write(this.disableTurn,"disableTurn",false);
        out.write(this.slopeIntensity,"slopeIntensity",0.10f);
        
    }

    /**
     * @return The forward/backward speed of the player
     */
    public float getSpeed() {
        return speed;
    }

    /**
     * @param speed Set the player speed.
     */
    public void setSpeed(float speed) {
        this.speed = speed;
    }

    /**
     * @return The players strafe speed.
     */
    public float getStrafeSpeed() {
        return strafeSpeed;
    }

    /**
     * @param strafeSpeed Set the player strafe speed.
     */
    public void setStrafeSpeed(float strafeSpeed) {
        this.strafeSpeed = strafeSpeed;
    }

    /**
     * @return The players current zone.
     */
    public String getZone() {
        return zone;
    }

    /**
     * @param zone Set the players zone.
     */
    public void setZone(String zone) {
        this.zone = zone;
    }

    /**
     * @return the collisionCapsule
     */
    public Vector3f getCollisionCapsule() {
        return collisionCapsule;
    }

    /**
     * @param collisionCapsule the collisionCapsule to set
     */
    public void setCollisionCapsule(Vector3f collisionCapsule) {
        this.collisionCapsule = collisionCapsule;
    }

    /**
     * @return the jumpForce
     */
    public Vector3f getJumpForce() {
        return jumpForce;
    }

    /**
     * @param jumpForce the jumpForce to set
     */
    public void setJumpForce(Vector3f jumpForce) {
        this.jumpForce = jumpForce;
    }

    /**
     * @return the gravity
     */
    public Vector3f getGravity() {
        return gravity;
    }

    /**
     * @param gravity the gravity to set
     */
    public void setGravity(Vector3f gravity) {
        this.gravity = gravity;
    }

    /**
     * @return the physicsDampening
     */
    public float getPhysicsDampening() {
        return physicsDampening;
    }

    /**
     * @param physicsDampening the physicsDampening to set
     */
    public void setPhysicsDampening(float physicsDampening) {
        this.physicsDampening = physicsDampening;
    }

    /**
     * @return The players control mode.
     */
    public ControlMode getControlMode() {
        return controlMode;
    }

    /**
     * @param controlMode Set the players control mode.
     */
    public void setControlMode(ControlMode controlMode) {
        this.controlMode = controlMode;
    }

    /**
     * @return The players turn speed.
     */
    public float getTurnSpeed() {
        return turnSpeed;
    }

    /**
     * @param turnSpeed Set the player turn speed.
     */
    public void setTurnSpeed(float turnSpeed) {
        this.turnSpeed = turnSpeed;
    }

    /**
     * @return Is strafing disabled.
     */
    public boolean isDisableStrafe() {
        return disableStrafe;
    }

    /**
     * @param disableStrafe Set to true to disable player strafing.
     */
    public void setDisableStrafe(boolean disableStrafe) {
        this.disableStrafe = disableStrafe;
    }

    /**
     * @return Is turning disabled.
     */
    public boolean isDisableTurn() {
        return disableTurn;
    }

    /**
     * @param disableTurn Set to true to disable player turning.
     */
    public void setDisableTurn(boolean disableTurn) {
        this.disableTurn = disableTurn;
    }

  /**
     * @return The slope intensity
     */
    public float getSlopeIntensity() {
        return slopeIntensity;
    }

    /**
     * @param slopeIntensity Set the slope intensity.The slope
     * intensity determines the max angle of slopes you can climb.
     * The value is typically from 0 - 1. Increasing the value will
     * allow you to climb slopes with steeper angles.
     */
    public void setSlopeIntensity(float slopeIntensity) {
        this.slopeIntensity = slopeIntensity;
    }

   
    
}
