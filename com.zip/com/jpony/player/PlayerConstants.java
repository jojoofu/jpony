package com.jpony.player;

public class PlayerConstants {
    
    public static final String        INVENTORY_NODE = "INVENTORY_NODE";
    public static final String        RESPAWN_NODE = "RESPAWN_NODE";
            
}
