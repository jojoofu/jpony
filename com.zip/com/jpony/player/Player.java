package com.jpony.player;

import com.jpony.GameManager;
import com.jpony.animation.AnimationObject;
import com.jpony.entity.EntityControl;
import com.jpony.input.Keys;
import com.jme3.animation.AnimChannel;
import com.jme3.animation.AnimControl;
import com.jme3.animation.AnimEventListener;
import com.jme3.collision.CollisionResults;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.SceneGraphVisitor;
import com.jme3.scene.Spatial;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The player class controls the player movement and gives you access
 * to the player control and node.
 * @author beer money
 */
public class Player implements AnimEventListener{
    
    // Direction and world tracking
    private final Vector3f               camLeft = new Vector3f(0,0,0);
    private final Vector3f               walkDirection = new Vector3f(0,0,0);
    private final Vector3f               playerDirection = new Vector3f(0,0,0);
    private final Vector3f               playerLeft = new Vector3f(0,0,0);
    
    public Node                          node;
    private final GameManager            gameManager;
    public String                        zone = "default";
    
    public AnimationObject               animations;
    
    private boolean                      idle;
    public Inventory                     inventory;
    
    public PlayerControl                 control = new PlayerControl();
    private final List                   listener = new ArrayList();
    private boolean                      allowMovement = true;
    
    
     public Player(GameManager gameManager){
        this.gameManager = gameManager;
        initialize();
     }
    
    private void initialize(){
        getPlayerNode();
        getPlayerControl();
        getAnimations();
        addAnimationsListener();
        inventory = new Inventory(gameManager);
        
    }   
    
    private void getPlayerControl(){
        gameManager.node.depthFirstTraversal(new SceneGraphVisitor() {
          public void visit(Spatial spatial) {
            if (spatial.getControl(PlayerControl.class) != null){
             control = spatial.getControl(PlayerControl.class); 
          }
        }   
       });
    }
    
    private void getAnimations(){
        for (AnimationObject animationObject : gameManager.animationManager.animationObjects){
            if (animationObject.name.equals(node.getName())){
                animations = animationObject;
                return;
            }
        }
    }
    
    private void addAnimationsListener(){
        for (AnimControl control : animations.controls){
            control.addListener(this);
        }
    }
    
    /**
     * Gets the node used for collision against the player.
     * @return <code> Node </code>
     */
    public Node getCollisionNode(){
        return node.getControl(PlayerControl.class).collisionNode;
    }
    
    /**
     * Determines if the player intersects with the specified geometry.
     * @param geometry The geometry to test intersection against.
     * @return True if an intersection occurs.
     */
    public boolean intersects(Geometry geometry){

        CollisionResults results = new CollisionResults();
        node.getWorldBound().collideWith(geometry,results);
        return results.size() > 0;

    }
    
    /**
     * Gets the distance between the player and the specified spatial.
     * @param spatial The spatial to get the distance from.
     * @return The distance.
     */
    public float getSpatialDistance(Spatial spatial){
        
        return  spatial.getWorldTranslation().distance(node.getWorldTranslation());

    }
    
    /**
     * @param vec The start point
     * @return The distance from the specified point to the player.
     */
    public float getDistance(Vector3f vec){
        
        return  vec.distance(node.getWorldTranslation());

    }
    /**
     * Adds a listener to the player.
     * @param listener The listener to add.
     */
    public synchronized void addListener(PlayerListener listener) {
        this.listener.add(listener);
    }
   
    /**
     * Removes a listener from the player.
     * @param listener The listener to remove.
     */
    public synchronized void removeListener(PlayerListener listener) {
        this.listener.remove(listener);
    }

    private synchronized void firePlayerIdle() {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((PlayerListener)iterator.next()).playerIdle();
        }
    }

    private synchronized void firePlayerActive() {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((PlayerListener)iterator.next()).playerIdle();
        }
    }
    
/**
 * Test if an entity is within range of the player.
 * @param spatial The spatial to test
 * @return True if the spatial is within range.
 */
public boolean inRange(Spatial spatial){
    
   if (spatial.getControl(EntityControl.class) != null) {
       if (getSpatialDistance(spatial) < spatial.getControl(EntityControl.class).getRange()){
        return true;
    }
   }
    
    return false;
}
    
private void getPlayerNode(){
    for (Spatial spatial : gameManager.node.descendantMatches(Spatial.class, null)) {    
           if (spatial.getControl(PlayerControl.class) != null) {
               node = (Node)spatial;
           } 
         }
}

/**
 * Updates the player position.
 * @param tpf The Time Per Frame.
 */
public void update(float tpf){
        
    if (control.isEnabled()){
        updateIdleState();
        switchModes(tpf);
    }
           
    }

private void switchModes(float tpf){
    switch (control.getControlMode()) {
            case THIRD_PERSON:
                thirdPersonMovement(tpf);
                break;
            case FIRST_PERSON:
                firstPersonMovement(tpf);
                break;
            case TOP_DOWN:
                topDownMovement(tpf);
                break;
            default:
                break;
        }
}

private void updateIdleState(){
        
   setIdle(gameManager.inputManager.isIdle() && gameManager.physicsManager.isOnGround() && !animations.isInMotion());

}

private void firstPersonMovement(float tpf){
      /*
       * The direction of character is determined by the camera angle
       * the Y direction is set to zero to keep our character from
       * lifting off the terrain. For free flying games add speed 
       * to Y axis
       */
        if (!allowMovement){
        walkDirection.set(0, 0, 0);
        gameManager.physicsManager.playerControl.setWalkDirection(walkDirection);
        node.setLocalTranslation(getCollisionNode().getLocalTranslation());
        return;
        }
        playerDirection.set(getDirection()).multLocal(control.getSpeed(), 0.0f, control.getSpeed());
        camLeft.set(gameManager.app.getCamera().getLeft()).multLocal(control.getStrafeSpeed());
        walkDirection.set(0, 0, 0);
        if (gameManager.inputManager.key(Keys.LEFT).triggered) {
            if (!control.isDisableStrafe()){
              walkDirection.addLocal(camLeft);  
            }
        }
        if (gameManager.inputManager.key(Keys.RIGHT).triggered) {
            if (!control.isDisableStrafe()){
              walkDirection.addLocal(camLeft.negate());  
            }
        }
        if (gameManager.inputManager.key(Keys.FORWARD).triggered) {
            walkDirection.addLocal(playerDirection);
        }
        if (gameManager.inputManager.key(Keys.BACKWARD).triggered) {
            walkDirection.addLocal(playerDirection.negate());
        }
        
        gameManager.physicsManager.playerControl.setWalkDirection(walkDirection);
        node.setLocalTranslation(getCollisionNode().getLocalTranslation());
                    
}

private void thirdPersonMovement(float tpf){
        
    if (!allowMovement){
        walkDirection.set(0, 0, 0);
        gameManager.physicsManager.playerControl.setWalkDirection(walkDirection);
        node.setLocalTranslation(getCollisionNode().getLocalTranslation());
        return;
    }
    
    if (gameManager.cameraManager.control.isTrail() && !gameManager.player.idle){
        gameManager.cameraManager.thirdPerson.trail(tpf);
    }
    
        playerDirection.set(getDirection()).multLocal(control.getSpeed(), 0.0f, control.getSpeed());
        playerLeft.set(getLeft()).multLocal(control.getStrafeSpeed());
        camLeft.set(gameManager.app.getCamera().getLeft()).multLocal(control.getStrafeSpeed());

        walkDirection.set(0, 0, 0);
        if (gameManager.inputManager.key(Keys.TURN_LEFT).triggered) {
            if (!control.isDisableTurn()){
              gameManager.physicsManager.yaw(node, control.getTurnSpeed() * tpf);
            }
        }
        if (gameManager.inputManager.key(Keys.TURN_RIGHT).triggered) {
            if (!control.isDisableTurn()){
              gameManager.physicsManager.yaw(node, -control.getTurnSpeed() * tpf);
            }
        }
        if (gameManager.inputManager.key(Keys.LEFT).triggered) {
            if (!control.isDisableStrafe()){
              walkDirection.addLocal(playerLeft);
            }
        }
        if (gameManager.inputManager.key(Keys.RIGHT).triggered) {
            if (!control.isDisableStrafe()){
              walkDirection.addLocal(playerLeft.negate());
            }
        }
        if (gameManager.inputManager.key(Keys.FORWARD).triggered) {       
            walkDirection.addLocal(playerDirection);
        }
        if (gameManager.inputManager.key(Keys.BACKWARD).triggered) {
            walkDirection.addLocal(playerDirection.negate());
        }

        gameManager.physicsManager.playerControl.setWalkDirection(walkDirection);
        node.setLocalTranslation(getCollisionNode().getLocalTranslation());
        
}

private void topDownMovement(float tpf){
        
        if (!allowMovement){
        walkDirection.set(0, 0, 0);
        gameManager.physicsManager.playerControl.setWalkDirection(walkDirection);
        node.setLocalTranslation(getCollisionNode().getLocalTranslation());
        return;
        }
        playerDirection.set(getDirection()).multLocal(control.getSpeed(), 0.0f, control.getSpeed());
        playerLeft.set(getLeft()).multLocal(control.getStrafeSpeed());
        camLeft.set(gameManager.app.getCamera().getLeft()).multLocal(control.getStrafeSpeed());

        walkDirection.set(0, 0, 0);
        if (gameManager.inputManager.key(Keys.TURN_LEFT).triggered) {
            if (!control.isDisableTurn()){
              gameManager.physicsManager.yaw(node, control.getTurnSpeed() * tpf);
            }
            }
        if (gameManager.inputManager.key(Keys.TURN_RIGHT).triggered) {
            if (!control.isDisableTurn()){
              gameManager.physicsManager.yaw(node, -control.getTurnSpeed() * tpf);
            }          
           }
        if (gameManager.inputManager.key(Keys.LEFT).triggered) {
            if (!control.isDisableStrafe()){
              walkDirection.addLocal(playerLeft);
            }
        }
        if (gameManager.inputManager.key(Keys.RIGHT).triggered) {
            if (!control.isDisableStrafe()){
              walkDirection.addLocal(playerLeft.negate());
            }
        }
        if (gameManager.inputManager.key(Keys.FORWARD).triggered) {       
            walkDirection.addLocal(playerDirection);
        }
        if (gameManager.inputManager.key(Keys.BACKWARD).triggered) {
            walkDirection.addLocal(playerDirection.negate());
        }

        gameManager.physicsManager.playerControl.setWalkDirection(walkDirection);
        node.setLocalTranslation(getCollisionNode().getLocalTranslation());
               
}

/**
 * Gets the players direction.
 * @return The player direction
 */
public Vector3f getDirection() {
        return node.getLocalRotation().getRotationColumn(2);
}

/**
 * Gets the left direction of the player.
 * @return The left direction.
 */
public Vector3f getLeft() {
        return node.getLocalRotation().getRotationColumn(0);       
}

    /**
     * @return Is the player idle.
     */
    public boolean isIdle() {
        return idle;
    }

    /**
     * Fires the player idle state change event.
     * @param idle Set the player idle state.
     */
    public void setIdle(boolean idle) {
        if (idle && idle != this.idle){
            firePlayerIdle();
            playerIdle();
        } else if (!idle && idle != this.idle){
            firePlayerActive();
            playerActive();
        }
        this.idle = idle;
    }

    private void playerIdle(){
       // for (PhysicsObject object : gameManager.physicsManager.physicsObjects){
       //     object.rigidBodyControl.setFriction(object.control.getTraction());  
       //     gameManager.physicsManager.playerControl.setPhysicsDamping(0.0f);
       // }
    }
    
    private void playerActive(){
       // for (PhysicsObject object : gameManager.physicsManager.physicsObjects){
       //     object.rigidBodyControl.setFriction(object.control.getSurfaceResistance());  
       //     gameManager.physicsManager.playerControl.setPhysicsDamping(0.8f);
       // }
    }
    
    @Override
    public void onAnimCycleDone(AnimControl control, AnimChannel channel, String animName) {
        animations.setInMotion(false);
        allowMovement = true;
    }

    @Override
    public void onAnimChange(AnimControl control, AnimChannel channel, String animName) {
        animations.setInMotion(false);
        allowMovement = true;
    }

    /**
     * @return the allowMovement
     */
    public boolean isAllowMovement() {
        return allowMovement;
    }

    /**
     * @param allowMovement the allowMovement to set
     */
    public void setAllowMovement(boolean allowMovement) {
        this.allowMovement = allowMovement;
    }

    

}
