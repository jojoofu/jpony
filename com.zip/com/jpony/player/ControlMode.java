package com.jpony.player;

/**
 * The player control mode.
 * @author april
 */
public enum ControlMode {
    
        FIRST_PERSON,
        THIRD_PERSON,
        TOP_DOWN,
        
}
