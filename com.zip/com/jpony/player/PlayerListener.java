package com.jpony.player;

/**
 * The player event listener
 * @author beer money.
 */
public interface PlayerListener {
    
    /**
     * Fires when the player becomes idle.
     */
    public void playerIdle();
    
    /**
     * Fires when the player becomes active.
     */
    public void playerActivated();
    
}
