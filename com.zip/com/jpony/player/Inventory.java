package com.jpony.player;

import com.jpony.GameManager;
import com.jpony.entity.EntityControl;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;

/**
 * The players inventory.
 * @author beer money
 */
public class Inventory {
    
    public Node                                    inventoryNode;
    public Node                                    respawnNode;
    private final  GameManager                     gameManager;
    
    public Inventory(GameManager gameManager){
        this.gameManager = gameManager;
        inventoryNode = new Node(PlayerConstants.INVENTORY_NODE);
        respawnNode = new Node(PlayerConstants.RESPAWN_NODE);
    }
    
    public void add(Spatial spatial){
        inventoryNode.attachChild(spatial);
         if (spatial.getControl(EntityControl.class).isRespawn()){
           respawnNode.attachChild(spatial.clone());
         }
    }
    
    /**
     * Gets the specified spatial
     * @param name The name of the spatial to return.
     * @return <code>Spatial</code>
     */
    public Spatial get(String name){
        
    for (Spatial spatial : inventoryNode.descendantMatches(Spatial.class, null)) {
        if (spatial.getName().equals(name)){
            return spatial;
        }
    }
    return null;
    }
    
    /**
     * Removes a spatial from the inventory.
     * @param name The name of the spatial to remove.
     */
    public void remove(String name){
        
        inventoryNode.getChild(name).removeFromParent();
        
    }
 
}
