package com.jpony;

import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AbstractAppState;
import java.util.ArrayList;
import java.util.EventObject;
import java.util.Iterator;
import java.util.List;

public class TimerState extends AbstractAppState{
    
   private final List                 listeners = new ArrayList();
   private final GameManager          gameManager;
   
   public TimerState(GameManager gameManager){
       this.gameManager = gameManager;
       attachState();
    }
   
   private void attachState(){
        setEnabled(true);
        gameManager.app.getStateManager().attach(this); 
   }
   
   public synchronized void addListener(TimerStateListener timerStateListener) {
        listeners.add(timerStateListener);
    }
   
   public synchronized void removeListener(TimerStateListener timerStateListener) {
        listeners.remove(timerStateListener);
    }
   
   private synchronized void fireUpdateTimers(float tpf) {
        Iterator iterator = listeners.iterator();
        while(iterator.hasNext()) {
            ((TimerStateListener)iterator.next()).updateTimers(tpf);
        }
    }

    // Note that update is only called while the state is both attached and enabled.
   @Override
   public void update(float tpf) {
      
       fireUpdateTimers(tpf);
       
    }  

}
