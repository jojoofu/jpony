package com.jpony;

public class JponyConstants {
  
    public static final String          DEBUG_UI = "DEBUG_UI";
    public static final String          DEBUG1 = "DEBUG1";
    public static final String          DEBUG2 = "DEBUG2";
    public static final String          DEBUG3 = "DEBUG3";
    
}
