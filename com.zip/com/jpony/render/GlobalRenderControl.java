package com.jpony.render;

import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.math.ColorRGBA;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import com.jme3.shadow.EdgeFilteringMode;
import java.io.IOException;

/**
 * The global render control is used to adjust render settings
 * for the entire scene.
 * @author beer money
 */
public class GlobalRenderControl extends AbstractControl {
    
    private float                    cullGroup1 = 100;
    private float                    cullGroup2 = 150;
    private float                    cullGroup3 = 200;
    private float                    cullGroup4 = 250;
    private int                      shadowMapSize = 1024;
    private int                      shadowSplits = 3;
    private float                    stencilEdgeWidth = 1;
    private float                    stencilEdgeIntensity = 1;
    private float                    shadowGroup1 = 50;
    private float                    shadowGroup2 = 150;
    private float                    shadowGroup3 = 450;
    private float                    shadowGroup4 = 550;
    private float                    shadowIntensity = 0.5f;
    private EdgeFilteringMode        edgeFilteringMode = EdgeFilteringMode.Nearest;
    private boolean                  enableShadows = true;
    private boolean                  enableStencil = true;
    private boolean                  enableFog = true;
    private ColorRGBA                fogColor = ColorRGBA.White;
    private float                    fogDensity = 0.7f;
    private float                    fogDistance = 1000;
    
    @Override
    protected void controlUpdate(float tpf) {
        //TODO: add code that controls Spatial,
        //e.g. spatial.rotate(tpf,tpf,tpf);
    }
    
    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        //Only needed for rendering-related operations,
        //not called when spatial is culled.
    }
    
    public Control cloneForSpatial(Spatial spatial) {
        GlobalRenderControl control = new GlobalRenderControl();
        //TODO: copy parameters to new Control
        return control;
    }
    
    @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //TODO: load properties of this Control, e.g.
        this.cullGroup1 = in.readFloat("cullGroup1", 100);
        this.cullGroup2 = in.readFloat("cullGroup2", 150);
        this.cullGroup3 = in.readFloat("cullGroup3", 200);
        this.cullGroup4 = in.readFloat("cullGroup4", 250);
        this.shadowMapSize = in.readInt("shadowMapSize", 1024);
        this.shadowSplits = in.readInt("shadowSplits",3);
        this.stencilEdgeWidth = in.readFloat("edgeWidth",1);
        this.stencilEdgeIntensity = in.readFloat("edgeIntensity",1);
        this.shadowGroup1 = in.readFloat("shadowGroup1", 50);
        this.shadowGroup2 = in.readFloat("shadowGroup2", 150);
        this.shadowGroup3 = in.readFloat("shadowGroup3", 450);
        this.shadowGroup4 = in.readFloat("shadowGroup4", 550);
        this.shadowIntensity = in.readFloat("shadowIntensity", 0.5f);
        this.edgeFilteringMode = in.readEnum("edgeFilteringMode",EdgeFilteringMode.class, EdgeFilteringMode.Nearest);
        this.enableFog = in.readBoolean("enableFog", true);
        this.enableShadows = in.readBoolean("enableShadows", true);
        this.enableStencil = in.readBoolean("enableStencil", true);
        this.fogColor = (ColorRGBA)in.readSavable("fogColor", ColorRGBA.White);
        this.fogDensity = in.readFloat("fogDensity", 0.7f);
        this.fogDistance = in.readFloat("fogDistance", 1000);
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        //TODO: save properties of this Control, e.g.
        out.write(this.cullGroup1, "cullGroup1", 100);
        out.write(this.cullGroup2, "cullGroup2", 150);
        out.write(this.cullGroup3, "cullGroup3", 200);
        out.write(this.cullGroup4, "cullGroup4", 250);
        out.write(this.shadowMapSize, "shadowMapSize", 1024);
        out.write(this.shadowSplits,"shadowSplits",3);
        out.write(this.stencilEdgeWidth,"edgeWidth",1);
        out.write(this.stencilEdgeIntensity,"edgeIntensity",1);
        out.write(this.shadowGroup1, "shadowGroup1", 50);
        out.write(this.shadowGroup2, "shadowGroup2", 150);
        out.write(this.shadowGroup3, "shadowGroup3", 450);
        out.write(this.shadowGroup4, "shadowGroup4", 550);
        out.write(this.shadowIntensity, "shadowIntensity", 0.5f);
        out.write(this.edgeFilteringMode, "edgeFilteringMode", EdgeFilteringMode.Nearest);
        out.write(this.enableFog, "enableFog", true);
        out.write(this.enableShadows, "enableShadows", true);
        out.write(this.enableStencil, "enableStencil", true);
        out.write(this.fogColor, "fogColor", ColorRGBA.White);
        out.write(this.fogDensity, "fogDensity", 0.7f);
        out.write(this.fogDistance, "fogDistance", 1000);
    }

    /**
     * @return The cull distance of group 1
     */
    public float getCullGroup1() {
        return cullGroup1;
    }

    /**
     * @param cullGroup1 The distance from the player at which the
     * group is culled from the scene.
     */
    public void setCullGroup1(float cullGroup1) {
        this.cullGroup1 = cullGroup1;
    }

    /**
     * @return The cull distance of group 2
     */
    public float getCullGroup2() {
        return cullGroup2;
    }

    /**
     * @param cullGroup2 The distance from the player at which the
     * group is culled from the scene.
     */
    public void setCullGroup2(float cullGroup2) {
        this.cullGroup2 = cullGroup2;
    }

    /**
     * @return The cull distance of group 3
     */
    public float getCullGroup3() {
        return cullGroup3;
    }

    /**
     * @param cullGroup3 The distance from the player at which the
     * group is culled from the scene.
     */
    public void setCullGroup3(float cullGroup3) {
        this.cullGroup3 = cullGroup3;
    }

    /**
     * @return The size of shadow map.
     */
    public int getShadowMapSize() {
        return shadowMapSize;
    }

    /**
     * @param shadowMapSize Set the size of shadow map.
     */
    public void setShadowMapSize(int shadowMapSize) {
        this.shadowMapSize = shadowMapSize;
    }
    
    /**
     * @return The number of shadow splits.
     */
    public int getShadowSplits() {
        return shadowSplits;
    }

    /**
     * @param shadowSplits Set the number of shadow splits.
     */
    public void setShadowSplits(int shadowSplits) {
        this.shadowSplits = shadowSplits;
    }
    
    /**
     * @return The width of the cartoon edge lines
     */
    public float getStencilEdgeWidth() {
        return stencilEdgeWidth;
    }

    /**
     * @param stencilEdgeWidth Set the width of the cartoon edge lines
     */
    public void setStencilEdgeWidth(float stencilEdgeWidth) {
        this.stencilEdgeWidth = stencilEdgeWidth;
    }

    /**
     * @return The intensity of the cartoon edge lines.
     */
    public float getStencilEdgeIntensity() {
        return stencilEdgeIntensity;
    }

    /**
     * @param stencilEdgeIntensity Set the intensity of the cartoon edge lines.
     */
    public void setStencilEdgeIntensity(float stencilEdgeIntensity) {
        this.stencilEdgeIntensity = stencilEdgeIntensity;
    }

    /**
     * @return the shadowGroup1
     */
    public float getShadowGroup1() {
        return shadowGroup1;
    }

    /**
     * @param shadowGroup1 the shadowGroup1 to set
     */
    public void setShadowGroup1(float shadowGroup1) {
        this.shadowGroup1 = shadowGroup1;
    }

    /**
     * @return the shadowGroup2
     */
    public float getShadowGroup2() {
        return shadowGroup2;
    }

    /**
     * @param shadowGroup2 the shadowGroup2 to set
     */
    public void setShadowGroup2(float shadowGroup2) {
        this.shadowGroup2 = shadowGroup2;
    }

    /**
     * @return the shadowGroup3
     */
    public float getShadowGroup3() {
        return shadowGroup3;
    }

    /**
     * @param shadowGroup3 the shadowGroup3 to set
     */
    public void setShadowGroup3(float shadowGroup3) {
        this.shadowGroup3 = shadowGroup3;
    }

    /**
     * @return the cullGroup4
     */
    public float getCullGroup4() {
        return cullGroup4;
    }

    /**
     * @param cullGroup4 the cullGroup4 to set
     */
    public void setCullGroup4(float cullGroup4) {
        this.cullGroup4 = cullGroup4;
    }

    /**
     * @return the shadowGroup4
     */
    public float getShadowGroup4() {
        return shadowGroup4;
    }

    /**
     * @param shadowGroup4 the shadowGroup4 to set
     */
    public void setShadowGroup4(float shadowGroup4) {
        this.shadowGroup4 = shadowGroup4;
    }

    /**
     * @return the shadowIntensity
     */
    public float getShadowIntensity() {
        return shadowIntensity;
    }

    /**
     * @param shadowIntensity the shadowIntensity to set
     */
    public void setShadowIntensity(float shadowIntensity) {
        this.shadowIntensity = shadowIntensity;
    }

    /**
     * @return the edgeFilteringMode
     */
    public EdgeFilteringMode getEdgeFilteringMode() {
        return edgeFilteringMode;
    }

    /**
     * @param edgeFilteringMode the edgeFilteringMode to set
     */
    public void setEdgeFilteringMode(EdgeFilteringMode edgeFilteringMode) {
        this.edgeFilteringMode = edgeFilteringMode;
    }

    /**
     * @return the enableShadows
     */
    public boolean isEnableShadows() {
        return enableShadows;
    }

    /**
     * @param enableShadows the enableShadows to set
     */
    public void setEnableShadows(boolean enableShadows) {
        this.enableShadows = enableShadows;
    }

    /**
     * @return the enableStencil
     */
    public boolean isEnableStencil() {
        return enableStencil;
    }

    /**
     * @param enableStencil the enableStencil to set
     */
    public void setEnableStencil(boolean enableStencil) {
        this.enableStencil = enableStencil;
    }

    /**
     * @return the enableFog
     */
    public boolean isEnableFog() {
        return enableFog;
    }

    /**
     * @param enableFog the enableFog to set
     */
    public void setEnableFog(boolean enableFog) {
        this.enableFog = enableFog;
    }

    /**
     * @return the fogColor
     */
    public ColorRGBA getFogColor() {
        return fogColor;
    }

    /**
     * @param fogColor the fogColor to set
     */
    public void setFogColor(ColorRGBA fogColor) {
        this.fogColor = fogColor;
    }

    /**
     * @return the fogDensity
     */
    public float getFogDensity() {
        return fogDensity;
    }

    /**
     * @param fogDensity the fogDensity to set
     */
    public void setFogDensity(float fogDensity) {
        this.fogDensity = fogDensity;
    }

    /**
     * @return the fogDistance
     */
    public float getFogDistance() {
        return fogDistance;
    }

    /**
     * @param fogDistance the fogDistance to set
     */
    public void setFogDistance(float fogDistance) {
        this.fogDistance = fogDistance;
    }
    
}
