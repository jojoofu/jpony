package com.jpony.render;

import com.jme3.collision.CollisionResults;
import com.jme3.math.Quaternion;
import com.jme3.math.Ray;
import com.jme3.math.Vector3f;
import com.jpony.GameManager;
import com.jpony.input.Keys;
import static com.jpony.input.Keys.MOUSE_DOWN;
import static com.jpony.input.Keys.MOUSE_LEFT;
import static com.jpony.input.Keys.MOUSE_RIGHT;
import static com.jpony.input.Keys.MOUSE_UP;
import static com.jpony.input.Keys.MOVE_CAMERA;
import static com.jpony.input.Keys.WHEEL_BACKWARD;
import static com.jpony.input.Keys.WHEEL_FORWARD;
import com.jpony.player.ControlMode;

/**
 * This class contains the logic for the third person camera controls.
 * Most of the functions contained within are for internal use only.
 * @author beer money
 */
public class CameraThirdPerson {
    
    private final GameManager       gameManager;
    
    public Vector3f                 offSet = new Vector3f(0,0,0);
    private final Vector3f          direction = new Vector3f();
    public Quaternion               resetRotation = new Quaternion();
    
    //collision
    private CollisionResults                              results;
    private Ray                                           ray;
    public Vector3f                                       contactPoint = new Vector3f();
    private Float                                         distanceToCamera;
    private Float                                         distanceToContact;
    
    public CameraThirdPerson(GameManager gameManager){
        this.gameManager = gameManager;
    }
    
    public void trail(float tpf){
        
        float speed = (gameManager.cameraManager.control.getTrailSpeed() * tpf) + tpf;
        
        if (gameManager.cameraManager.rotationNode.getLocalRotation().getY() > 0 && !gameManager.inputManager.key(Keys.MOVE_CAMERA).triggered){
            if (gameManager.cameraManager.rotationNode.getLocalRotation().getY() <= speed && gameManager.cameraManager.rotationNode.getLocalRotation().getY() >= -speed){
             resetRotation.set(gameManager.cameraManager.camera.getRotation().getX(), 0, gameManager.cameraManager.camera.getRotation().getZ(), gameManager.cameraManager.camera.getRotation().getW());
             gameManager.cameraManager.camera.setRotation(resetRotation);
            } else {
             gameManager.physicsManager.yaw(gameManager.cameraManager.rotationNode,-gameManager.cameraManager.control.getTrailSpeed() * tpf); 
            }
        } else if (gameManager.cameraManager.rotationNode.getLocalRotation().getY() < 0 && !gameManager.inputManager.key(Keys.MOVE_CAMERA).triggered){
            if (gameManager.cameraManager.rotationNode.getLocalRotation().getY() <= speed && gameManager.cameraManager.rotationNode.getLocalRotation().getY() >= -speed){
             resetRotation.set(gameManager.cameraManager.camera.getRotation().getX(), 0, gameManager.cameraManager.camera.getRotation().getZ(), gameManager.cameraManager.camera.getRotation().getW());
             gameManager.cameraManager.camera.setRotation(resetRotation);
           } else {
             gameManager.physicsManager.yaw(gameManager.cameraManager.rotationNode,gameManager.cameraManager.control.getTrailSpeed() * tpf);
           }
        }
        
    }
    
    /**
     * Positions the camera and camera node for third person mode.
     */
    public void switchModes(){
 
        gameManager.player.control.setControlMode(ControlMode.THIRD_PERSON);
        gameManager.cameraManager.rotationNode.setLocalRotation(Quaternion.IDENTITY);
        gameManager.cameraManager.cameraNode.setLocalTranslation(gameManager.cameraManager.control.getThirdPersonDefault());
        
    }
    
    /**
     * Updates the camera node and camera.
     * @param tpf 
     */
    public void update(float tpf){
        offSet.set(0, 0, 0);
        offSet.addLocal(gameManager.player.node.getLocalTranslation());
        offSet.addLocal(gameManager.cameraManager.control.getThirdPersonOffSet());
        
        gameManager.cameraManager.camera.setLocation(gameManager.cameraManager.cameraNode.getWorldTranslation());  
        gameManager.cameraManager.cameraNode.lookAt(offSet, Vector3f.UNIT_Y);
        gameManager.cameraManager.camera.setRotation(gameManager.cameraManager.cameraNode.getWorldRotation());
        
    }
    
    /**
     * Updates the camera during when an analog actions occurs.
     * @param value
     * @param name
     * @param tpf 
     */
    public void analogUpdate(float value,String name,float tpf) {
       
        direction.set(gameManager.cameraManager.cameraNode.getLocalRotation().getRotationColumn(2).mult(gameManager.cameraManager.control.getZoomSpeed()));
        
     if (name.equals(MOUSE_LEFT) && gameManager.inputManager.key(MOVE_CAMERA).triggered) {
            gameManager.physicsManager.yaw(gameManager.cameraManager.rotationNode,gameManager.cameraManager.control.getHorizontalDragSpeed() * value);
        } else if (name.equals(MOUSE_RIGHT) && gameManager.inputManager.key(MOVE_CAMERA).triggered) {
            gameManager.physicsManager.yaw(gameManager.cameraManager.rotationNode,-gameManager.cameraManager.control.getHorizontalDragSpeed() * value);
        } else if (name.equals(MOUSE_UP) && gameManager.inputManager.key(MOVE_CAMERA).triggered) {
            gameManager.physicsManager.pitch(gameManager.cameraManager.rotationNode,-gameManager.cameraManager.control.getVerticalDragSpeed() * value);
        } else if (name.equals(MOUSE_DOWN) && gameManager.inputManager.key(MOVE_CAMERA).triggered) {
            gameManager.physicsManager.pitch(gameManager.cameraManager.rotationNode,gameManager.cameraManager.control.getVerticalDragSpeed() * value);
        } else if (name.equals(WHEEL_FORWARD)){
            gameManager.cameraManager.cameraNode.getLocalTranslation().addLocal(direction);
            float distance = gameManager.physicsManager.getDistance(gameManager.cameraManager.camera.getLocation(), gameManager.player.node.getLocalTranslation());
            if ((distance < gameManager.cameraManager.control.getZoomInMax())){
              // We are past the max distance zoom back out.
              gameManager.cameraManager.cameraNode.getLocalTranslation().addLocal(direction.negate());  
            }
        } else if (name.equals(WHEEL_BACKWARD)){
            float distance = gameManager.physicsManager.getDistance(gameManager.cameraManager.camera.getLocation(), gameManager.player.node.getLocalTranslation());
            if (!(distance > gameManager.cameraManager.control.getZoomOutMax())){
                gameManager.cameraManager.cameraNode.getLocalTranslation().addLocal(direction.negate());
            }
        }
     }
     
    /**
     * Adjust the camera view if the line of sight is obscured by
     * any phsycial object or entity.
     */
    public void smartCamera(){
        if (!gameManager.cameraManager.control.isSmartCamera()){
            return;
        }
        direction.set(gameManager.cameraManager.camera.getLocation());
        direction.subtractLocal(gameManager.cameraManager.thirdPerson.offSet).normalizeLocal();
        //Reset results list.
        results = new CollisionResults();
        // Set the ray offSet to the camera's offSet.
        ray = new Ray(gameManager.cameraManager.thirdPerson.offSet,direction);
        // Get collision results
        gameManager.entityManager.node.collideWith(ray, results);
        if (results.size() > 0 ){
            contactPoint = results.getClosestCollision().getContactPoint();
            distanceToCamera = gameManager.cameraManager.camera.getLocation().distance(gameManager.cameraManager.thirdPerson.offSet);
            distanceToContact = gameManager.cameraManager.thirdPerson.offSet.distance(contactPoint);
            if (distanceToCamera > distanceToContact){
                gameManager.cameraManager.camera.setLocation(contactPoint);
            }
            
            
        }
        
    }
    
}
