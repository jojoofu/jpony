package com.jpony.render;

/**
 * Set the JPony shadow mode. There are three modes.
 * Automatic - The shadowing is handled by the render manager.
 * Off - The shadow never draws.
 * Always - The shadow is always drawn.
 * @author beer money
 */
public enum JShadowMode {
    
    AUTOMATIC,
    OFF,
    ALWAYS
    
}
