package com.jpony.render;

public class CameraInput {
    
    public static final String             CAMERA_LEFT = "cameraLeft";
    public static final String             CAMERA_RIGHT = "cameraRight";
    public static final String             CAMERA_UP = "cameraUp";
    public static final String             CAMERA_DOWN = "cameraDown";
    public static final String             SHIFT = "shift";
    public static final String             MOUSE_LEFT = "mouseLeft";
    public static final String             FIRST_PERSON = "firstPerson";
    public static final String             THIRD_PERSON = "thirdPerson";
    
    
}
