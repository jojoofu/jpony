package com.jpony.render;

import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jpony.GameManager;
import static com.jpony.input.Keys.MOUSE_DOWN;
import static com.jpony.input.Keys.MOUSE_LEFT;
import static com.jpony.input.Keys.MOUSE_RIGHT;
import static com.jpony.input.Keys.MOUSE_UP;
import static com.jpony.input.Keys.MOVE_CAMERA;
import static com.jpony.input.Keys.WHEEL_BACKWARD;
import static com.jpony.input.Keys.WHEEL_FORWARD;
import com.jpony.player.ControlMode;

/**
 *
 * @author beer money
 */
public class CameraTopDown {
    
    private final GameManager       gameManager;
    private final Vector3f          direction = new Vector3f();
    
    public CameraTopDown(GameManager gameManager){
        this.gameManager = gameManager;
    }
    
    public void analogUpdate(float value,String name,float tpf) {
     if (name.equals(MOUSE_LEFT) && gameManager.inputManager.key(MOVE_CAMERA).triggered) {
       direction.addLocal(gameManager.cameraManager.camera.getLeft().multLocal(gameManager.cameraManager.control.getDragSpeed() * tpf));
     } else if (name.equals(MOUSE_RIGHT) && gameManager.inputManager.key(MOVE_CAMERA).triggered) {
       direction.addLocal(gameManager.cameraManager.camera.getLeft().multLocal(gameManager.cameraManager.control.getDragSpeed() * tpf).negate());
     } else if (name.equals(MOUSE_UP) && gameManager.inputManager.key(MOVE_CAMERA).triggered) {
       direction.addLocal(gameManager.cameraManager.camera.getRotation().getRotationColumn(1).mult(gameManager.cameraManager.control.getDragSpeed() * value));
     } else if (name.equals(MOUSE_DOWN) && gameManager.inputManager.key(MOVE_CAMERA).triggered) {
       direction.addLocal(gameManager.cameraManager.camera.getRotation().getRotationColumn(1).mult(gameManager.cameraManager.control.getDragSpeed() * value).negate());
     } else if (name.equals(WHEEL_FORWARD)){
       direction.addLocal(gameManager.cameraManager.camera.getDirection().mult(gameManager.cameraManager.control.getZoomSpeed()));
     } else if (name.equals(WHEEL_BACKWARD)){
       direction.addLocal(gameManager.cameraManager.camera.getDirection().mult(gameManager.cameraManager.control.getZoomSpeed()).negate());
     }
    }
    
    public void update(float tpf){
        gameManager.cameraManager.camera.setLocation(gameManager.player.node.getLocalTranslation());
        gameManager.cameraManager.camera.setLocation(gameManager.cameraManager.camera.getLocation().addLocal(gameManager.cameraManager.control.getTopDownDefault()));
        gameManager.cameraManager.camera.setLocation(gameManager.cameraManager.camera.getLocation().addLocal(direction));
    }
    
    // switch to top down mode.
    public void switchModes(){
        
        gameManager.player.control.setControlMode(ControlMode.TOP_DOWN);
        gameManager.cameraManager.rotationNode.setLocalRotation(Quaternion.IDENTITY);
        gameManager.cameraManager.cameraNode.setLocalTranslation(gameManager.cameraManager.control.getTopDownDefault());
        gameManager.cameraManager.camera.setLocation(gameManager.cameraManager.cameraNode.getWorldTranslation());
        gameManager.cameraManager.camera.lookAt(gameManager.player.node.getLocalTranslation(), Vector3f.UNIT_Y);
        gameManager.cameraManager.cameraNode.lookAt(gameManager.player.node.getLocalTranslation(), Vector3f.UNIT_Y);
        direction.set(0,0,0);
        
    }
    
}
