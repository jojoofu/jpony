package com.jpony.render;

import com.jme3.light.DirectionalLight;
import com.jme3.light.Light;
import com.jme3.light.LightList;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector2f;
import com.jme3.post.FilterPostProcessor;
import com.jme3.post.filters.CartoonEdgeFilter;
import com.jme3.post.filters.FogFilter;
import com.jme3.renderer.Caps;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.scene.SceneGraphVisitor;
import com.jpony.GameManager;
import com.jme3.scene.Spatial;
import com.jme3.shadow.DirectionalLightShadowFilter;
import com.jme3.shadow.DirectionalLightShadowRenderer;
import com.jme3.shadow.EdgeFilteringMode;

/**
 * The render manager is a hub for your scene's render controls.
 * @author beer money
 */
public class RenderManager {
    
    private final GameManager              gameManager;
    private Vector2f                       resolution;
    private boolean                        enabled;
    
    private DirectionalLight               sun;
    
    public GlobalRenderControl             control;
    // post process filters
    public FilterPostProcessor             filter;
    public FilterPostProcessor             shadowProcessor;
    public FilterPostProcessor             stencilProcessor;
    public FilterPostProcessor             fogProcessor;
    // effect filters
    public DirectionalLightShadowRenderer  DLshadowRender;
    public DirectionalLightShadowFilter    DLshadowFilter;
    public CartoonEdgeFilter               stencilFilter;
    public FogFilter                       fogFilter;
    // enablers
    private boolean                        enableFog = true;
    private boolean                        enableShadows = true;
    private boolean                        enableStencil = true;
    
    
    public RenderManager(GameManager gameManager){
        this.gameManager = gameManager;
        initialize();
    }
    
    private void initialize(){
        getGlobalRenderControl();
        getDirectionalLight();
        createFilter();
        initShadowFilter();
        initEdgeFilter();
        initFogFilter();
        setCullGroup();
        setShadowGroup();
        postInitCleanUp();
    }
    
    private void postInitCleanUp(){
       gameManager.app.getViewPort().addProcessor(filter);
       setEnableFog(control.isEnableFog());
       setEnableShadows(control.isEnableShadows());
       setEnableStencil(control.isEnableStencil());
    }
    
    private void createFilter(){
        filter = new FilterPostProcessor(gameManager.app.getAssetManager());  
    }
    
    private void initShadowFilter(){
        
        DLshadowRender = new DirectionalLightShadowRenderer(gameManager.app.getAssetManager(), control.getShadowMapSize(),control.getShadowSplits());
        DLshadowFilter = new DirectionalLightShadowFilter(gameManager.app.getAssetManager(), control.getShadowMapSize(), control.getShadowSplits());
        
        DLshadowRender.setLight(sun);
        DLshadowRender.setEdgeFilteringMode(control.getEdgeFilteringMode());
        DLshadowRender.setShadowIntensity(control.getShadowIntensity());
        gameManager.app.getViewPort().addProcessor(DLshadowRender);
        
        DLshadowFilter.setLight(sun);
        DLshadowFilter.setEdgeFilteringMode(control.getEdgeFilteringMode());
        DLshadowFilter.setShadowIntensity(control.getShadowIntensity());
        //filter.addFilter(DLshadowFilter);
        
  }
    
    private void initEdgeFilter(){
        if (gameManager.app.getRenderer().getCaps().contains(Caps.GLSL100)){
            filter.setNumSamples(4);
            stencilFilter = new CartoonEdgeFilter();
            stencilFilter.setEdgeColor(ColorRGBA.Black);
            stencilFilter.setEdgeWidth(control.getStencilEdgeWidth());
            stencilFilter.setEdgeIntensity(control.getStencilEdgeIntensity());
            filter.addFilter(stencilFilter);
        }
    }
    
    private void initFogFilter(){
        fogFilter = new FogFilter(control.getFogColor(),control.getFogDensity(), control.getFogDistance());
        filter.addFilter(fogFilter);
    }
    
    private void getDirectionalLight(){
        
        gameManager.node.depthFirstTraversal(new SceneGraphVisitor() {
          public void visit(Spatial spatial) {
             LightList lights;
             lights = spatial.getLocalLightList();
             hasLight(lights);
        }   
       });    
        
    }
    
    private boolean hasLight(LightList lights){
       for (Light light : lights){
          if (light.getType() == Light.Type.Directional){
              sun = (DirectionalLight)light;
              return true;
          }
       }
       return false;
    }
    
    private void getGlobalRenderControl(){
       gameManager.node.depthFirstTraversal(new SceneGraphVisitor() {
          public void visit(Spatial spatial) {
             if (spatial.getControl(GlobalRenderControl.class) != null){
                 control = spatial.getControl(GlobalRenderControl.class);
             }
        }   
       });  
    }
    
    private void setCullGroup(){
       gameManager.node.depthFirstTraversal(new SceneGraphVisitor() {
          public void visit(Spatial spatial) {
             if (spatial.getControl(RenderControl.class) != null) {
                 switch (spatial.getControl(RenderControl.class).getCullGroup()) {
                     case 1:
                         spatial.getControl(RenderControl.class).setCullDistance(control.getCullGroup1());
                         break;
                     case 2:
                         spatial.getControl(RenderControl.class).setCullDistance(control.getCullGroup2());
                         break;
                     case 3:
                         spatial.getControl(RenderControl.class).setCullDistance(control.getCullGroup3());
                         break;
                     case 4:
                         spatial.getControl(RenderControl.class).setCullDistance(control.getCullGroup4());
                         break;
                     default:
                         break;
                 }
             }
        }   
       });  
    }

    private void setShadowGroup(){
       gameManager.node.depthFirstTraversal(new SceneGraphVisitor() {
          public void visit(Spatial spatial) {
             if (spatial.getControl(RenderControl.class) != null) {
                 switch (spatial.getControl(RenderControl.class).getShadowGroup()) {
                     case 1:
                         spatial.getControl(RenderControl.class).setShadowDistance(control.getShadowGroup1());
                         break;
                     case 2:
                         spatial.getControl(RenderControl.class).setShadowDistance(control.getShadowGroup2());
                         break;
                     case 3:
                         spatial.getControl(RenderControl.class).setShadowDistance(control.getShadowGroup3());
                         break;
                     case 4:
                         spatial.getControl(RenderControl.class).setShadowDistance(control.getShadowGroup4());
                         break;
                     default:
                         break;
                 }
             }
        }   
       });  
    }
    
/**
* Update the spatial's render state.
* @param spatial The spatial to update
*/
public void update(Spatial spatial){
    // The distance from the spatial to the player
    float distance = gameManager.player.getSpatialDistance(spatial);
    // update any spatial with a render control
    cull(spatial,distance);
    cullShadows(spatial,distance);
}

private void cullShadows(Spatial spatial,float distance){
    
    if (spatial.getControl(RenderControl.class) != null) {
        if (distance > spatial.getControl(RenderControl.class).getShadowDistance()) {
            spatial.setShadowMode(RenderQueue.ShadowMode.Off);
        } else {
            spatial.setShadowMode(RenderQueue.ShadowMode.CastAndReceive);
        }
    } else {
        spatial.setShadowMode(RenderQueue.ShadowMode.CastAndReceive);
    }
 
}

/**
* Culls the spatial from the scene.
* @param spatial 
*/
private void cull(Spatial spatial,float distance) {
            
    if (spatial.getControl(RenderControl.class) != null) {
      if (distance > spatial.getControl(RenderControl.class).getCullDistance()) {
        spatial.setCullHint(Spatial.CullHint.Always);
      } else {
        spatial.setCullHint(Spatial.CullHint.Inherit);
      }  
    }
     
}
    
    /**
     * @return The screens resolution.
     */
    public Vector2f getResolution() {
        resolution.x = gameManager.settings.getWidth();
        resolution.y = gameManager.settings.getHeight();
        return resolution;
    }
    
    /**
     * Set the screens resolution.
     * @param width The screen width
     * @param height The screen height
     */
    public void setResolution(int width , int height) {
        gameManager.settings.setWidth(width);
        gameManager.settings.setHeight(height);
        gameManager.app.restart();
        gameManager.UImanager.resize();
        this.resolution = new Vector2f(width,height);
    }

    /**
     * @return Is the render manager enabled.
     */
    public boolean isEnabled() {
        return enabled;
    }

    /**
     * @param enabled Enable or disable the render manager.
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * @return the enableFog
     */
    public boolean isEnableFog() {
        return enableFog;
    }

    /**
     * @param enableFog the enableFog to set
     */
    public void setEnableFog(boolean enableFog) {
        this.enableFog = enableFog;
        fogFilter.setEnabled(enableFog);
    }

    /**
     * @return the enableShadows
     */
    public boolean isEnableShadows() {
        return enableShadows;
    }

    /**
     * @param enableShadows the enableShadows to set
     */
    public void setEnableShadows(boolean enableShadows) {
        this.enableShadows = enableShadows;
        //DLshadowFilter.setEnabled(enableShadows);
    }

    /**
     * @return the enableStencil
     */
    public boolean isEnableStencil() {
        return enableStencil;
    }

    /**
     * @param enableStencil the enableStencil to set
     */
    public void setEnableStencil(boolean enableStencil) {
        this.enableStencil = enableStencil;
        stencilFilter.setEnabled(enableStencil);
    }


}
