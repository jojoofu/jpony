package com.jpony.render;

public class CameraConstants {
    
    public static final String     CAMERA_NODE = "CAMERA_NODE";
    public static final String     ROTATION_NODE = "ROTATION_NODE";
    
}
