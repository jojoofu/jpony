package com.jpony.render;

import com.jme3.math.FastMath;
import com.jme3.math.Matrix3f;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jpony.GameManager;
import static com.jpony.input.Keys.*;
import com.jpony.player.ControlMode;

/**
 *
 * @author beer money
 */
public class CameraFirstPerson {
    
    private final GameManager        gameManager;
    
    private final float[]                                 angles = new float[3];
    private final Quaternion                              lockAngle = new Quaternion();
    
    public CameraFirstPerson(GameManager gameManager){
        this.gameManager = gameManager;
    }
    
    public void analogUpdate(float value,String name,float tpf) {
     
     if (name.equals(MOUSE_LEFT)) {
        rotateCamera(value,Vector3f.UNIT_Y);
        gameManager.physicsManager.yaw(gameManager.player.node,value * gameManager.player.control.getTurnSpeed());
     } else if (name.equals(MOUSE_RIGHT)) {
        rotateCamera(-value,Vector3f.UNIT_Y);
         gameManager.physicsManager.yaw(gameManager.player.node,-value * gameManager.player.control.getTurnSpeed());
     } else if (name.equals(MOUSE_UP)) {
        rotateCamera(-value,gameManager.cameraManager.camera.getLeft());
     } else if (name.equals(MOUSE_DOWN)) {
        rotateCamera(value,gameManager.cameraManager.camera.getLeft());
     } else if (name.equals(WHEEL_FORWARD)) {
       zoomCamera(-value);
     } else if (name.equals(WHEEL_BACKWARD)) {
       zoomCamera(value);
     } else if (name.equals(MOUSE_BUTTON_MIDDLE)) {
       resetZoom();
     } 
     
     limitAngle();
    
    }
    
    /**
     * Unzooms the camera
     */
    public void resetZoom(){
        gameManager.app.getCamera().setFrustumPerspective(45f, (float) gameManager.app.getCamera().getWidth() / gameManager.app.getCamera().getHeight(), 0.01f, 1000f);
    }
    
    public void update(float tpf){
       gameManager.cameraManager.camera.setLocation(gameManager.cameraManager.cameraNode.getWorldTranslation());
    }
    
    private void rotateCamera(float value, Vector3f axis){

        Matrix3f mat = new Matrix3f();
        mat.fromAngleNormalAxis(gameManager.player.control.getTurnSpeed() * value, axis);

        Vector3f up = gameManager.cameraManager.camera.getUp();
        Vector3f left = gameManager.cameraManager.camera.getLeft();
        Vector3f dir = gameManager.cameraManager.camera.getDirection();

        mat.mult(up, up);
        mat.mult(left, left);
        mat.mult(dir, dir);

        Quaternion q = new Quaternion();
        q.fromAxes(left, up, dir);
        q.normalizeLocal();

        gameManager.cameraManager.camera.setAxes(q);
           
    }

    private void limitAngle(){
        
        //this will return the actual rotation angles in radians
        gameManager.cameraManager.camera.getRotation().toAngles(angles);

        //check the x rotation
        if(angles[0]>FastMath.HALF_PI){

        angles[0]=FastMath.HALF_PI;

        gameManager.cameraManager.camera.setRotation(lockAngle.fromAngles(angles));

        }else if(angles[0]<-FastMath.HALF_PI){

        angles[0]=-FastMath.HALF_PI;

        gameManager.cameraManager.camera.setRotation(lockAngle.fromAngles(angles));

        }
    }
    
    // switch to first person mode.
    public void switchModes(){
      
      gameManager.player.control.setControlMode(ControlMode.FIRST_PERSON);
      gameManager.cameraManager.rotationNode.setLocalRotation(Quaternion.IDENTITY);
      gameManager.cameraManager.cameraNode.setLocalTranslation(gameManager.cameraManager.control.getFirstPersonOffSet());
      gameManager.cameraManager.camera.setLocation(gameManager.cameraManager.cameraNode.getWorldTranslation());
      gameManager.cameraManager.camera.setRotation(gameManager.player.node.getLocalRotation());
      
    }
    
    protected void zoomCamera(float value){
        // derive fovY value
        float h = gameManager.cameraManager.camera.getFrustumTop();
        float w = gameManager.cameraManager.camera.getFrustumRight();
        float aspect = w / h;

        float near = gameManager.cameraManager.camera.getFrustumNear();

        float fovY = FastMath.atan(h / near)
                  / (FastMath.DEG_TO_RAD * .5f);
        float newFovY = fovY + value * 0.1f * gameManager.cameraManager.control.getZoomSpeed();
        if (newFovY > 0f) {
            // Don't let the FOV go zero or negative.
            fovY = newFovY;
        }

        h = FastMath.tan( fovY * FastMath.DEG_TO_RAD * .5f) * near;
        w = h * aspect;

        gameManager.cameraManager.camera.setFrustumTop(h);
        gameManager.cameraManager.camera.setFrustumBottom(-h);
        gameManager.cameraManager.camera.setFrustumLeft(-w);
        gameManager.cameraManager.camera.setFrustumRight(w);
    }
    
}
