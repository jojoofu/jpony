package com.jpony.render;

import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import java.io.IOException;

/**
 * The camera control is used for setting up and adjusting 
 * the scene camera.Your scene must have a camera control
 * attached before it can be loaded.
 * @author beer money
 */
public class CameraControl extends AbstractControl {
    
    private float                           horizontalDragSpeed = 2;
    private float                           verticalDragSpeed = 1;
    private float                           dragSpeed = 1;
    private float                           zoomSpeed = 0.7f;
    private Vector3f                        topDownDefault = new Vector3f(0,15,0);;
    private Vector3f                        firstPersonOffSet = new Vector3f(0,2,0);
    private Vector3f                        thirdPersonOffSet = new Vector3f(0,0,0);
    private Vector3f                        thirdPersonDefault = new Vector3f(0,15,-15); 
    private float                           zoomInMax = 1;
    private float                           zoomOutMax = 50;
    private boolean                         trail = false;
    private float                           trailSpeed = 1;
    private boolean                         smartCamera = true;
    
    @Override
    protected void controlUpdate(float tpf) {
        //TODO: add code that controls Spatial,
        //e.g. spatial.rotate(tpf,tpf,tpf);
        
    }
    
    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        //Only needed for rendering-related operations,
        //not called when spatial is culled.
    }
    
    public Control cloneForSpatial(Spatial spatial) {
        CameraControl control = new CameraControl();
        //TODO: copy parameters to new Control
        return control;
    }
   
    @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        this.horizontalDragSpeed = in.readFloat("horizontalDragSpeed",2);
        this.verticalDragSpeed = in.readFloat("verticalDragSpeed",1);
        this.dragSpeed = in.readFloat("dragSpeed",1);
        this.zoomSpeed = in.readFloat("zoomSpeed",0.7f);
        this.firstPersonOffSet = (Vector3f)in.readSavable("firstPersonOffSet", new Vector3f(0,2,0));
        this.thirdPersonOffSet = (Vector3f)in.readSavable("thirdPersonOffSet", new Vector3f(0,0,0));
        this.topDownDefault = (Vector3f)in.readSavable("topDownOffSet", new Vector3f(0,15,0));
        this.thirdPersonDefault = (Vector3f)in.readSavable("thirdPersonDefault", new Vector3f(0,15,-15));
        this.zoomInMax = in.readFloat("zoomInMax",1);
        this.zoomOutMax = in.readFloat("zoomOutMax",50);
        this.trail = in.readBoolean("trail",false);
        this.trailSpeed = in.readFloat("trailSpeed",1);
        this.smartCamera = in.readBoolean("smartCamera",true);
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        out.write(this.horizontalDragSpeed,"horizontalDragSpeed",2);
        out.write(this.verticalDragSpeed,"verticalDragSpeed",1);
        out.write(this.dragSpeed,"dragSpeed",1);
        out.write(this.zoomSpeed,"zoomSpeed",0.7f);
        out.write(this.firstPersonOffSet,"firstPersonOffSet",new Vector3f(0,2,0));
        out.write(this.thirdPersonOffSet,"thirdPersonOffSet",new Vector3f(0,0,0));
        out.write(this.topDownDefault,"topDownOffSet",new Vector3f(0,15,0));
        out.write(this.thirdPersonDefault,"thirdPersonDefault",new Vector3f(0,15,-15));
        out.write(this.zoomInMax,"zoomInMax",1);
        out.write(this.zoomOutMax,"zoomOutMax",50);
        out.write(this.trail,"trail",false);
        out.write(this.trailSpeed,"trailSpeed",1);
        out.write(this.smartCamera,"smartCamera",true);
    }

    /**
     * @return The horizontal mouse drag speed in third person mode.
     */
    public float getHorizontalDragSpeed() {
        return horizontalDragSpeed;
    }

    /**
     * @param horizontalDragSpeed Set the horizontal mouse drag speed.
     */
    public void setHorizontalDragSpeed(float horizontalDragSpeed) {
        this.horizontalDragSpeed = horizontalDragSpeed;
    }

    /**
     * @return The camera drag speed for top down mode.
     */
    public float getDragSpeed() {
        return dragSpeed;
    }

    /**
     * @param dragSpeed Set the camera drag speed.
     */
    public void setDragSpeed(float dragSpeed) {
        this.dragSpeed = dragSpeed;
    }

    /**
     * @return The camera zoom speed.
     */
    public float getZoomSpeed() {
        return zoomSpeed;
    }

    /**
     * @param zoomSpeed Set the camera zoom speed.
     */
    public void setZoomSpeed(float zoomSpeed) {
        this.zoomSpeed = zoomSpeed;
    }

    /**
     * @return The default location when switching to top down mode.
     * This is set in relation to the player.
     */
    public Vector3f getTopDownDefault() {
        return topDownDefault;
    }

    /**
     * @param topDownDefault Set the default location when switching to top down mode.
     * This is set in relation to the player.
     */
    public void setTopDownDefault(Vector3f topDownDefault) {
        this.topDownDefault = topDownDefault;
    }

    /**
     * @return The first person shooter offset determines where the
     * camera sits in relation to the player during first person mode.
     * Use this to make offsets so the camera does not appear within
     * the body of the spatial.
     */
    public Vector3f getFirstPersonOffSet() {
        return firstPersonOffSet;
    }

    /**
     * @param firstPersonOffSet Set the first person shooter offset.
     */
    public void setFirstPersonOffSet(Vector3f firstPersonOffSet) {
        this.firstPersonOffSet = firstPersonOffSet;
    }

    /**
     * @return The point the camera looks at in relation to the 
     * player.
     */
    public Vector3f getThirdPersonOffSet() {
        return thirdPersonOffSet;
    }

    /**
     * @param thirdPersonOffSet Set the point the camera looks at
     * in relation to the player.
     */
    public void setThirdPersonOffSet(Vector3f thirdPersonOffSet) {
        this.thirdPersonOffSet = thirdPersonOffSet;
    }

    /**
     * @return The vertical mouse drag speed for third person mode.
     */
    public float getVerticalDragSpeed() {
        return verticalDragSpeed;
    }

    /**
     * @param verticalDragSpeed Set the vertical mouse drag speed.
     */
    public void setVerticalDragSpeed(float verticalDragSpeed) {
        this.verticalDragSpeed = verticalDragSpeed;
    }

    /**
     * @return The default camera starting position for third person
     * mode. This is set in relation to the player node.
     */
    public Vector3f getThirdPersonDefault() {
        return thirdPersonDefault;
    }

    /**
     * @param thirdPersonDefault Set the default camera starting position for third person
     * mode. This is set in relation to the player node.
     */
    public void setThirdPersonDefault(Vector3f thirdPersonDefault) {
        this.thirdPersonDefault = thirdPersonDefault;
    }

    /**
     * @return How close the camera can zoom into the player.
     */
    public float getZoomInMax() {
        return zoomInMax;
    }

    /**
     * @param zoomInMax Set how close the camera can zoom into the player.
     */
    public void setZoomInMax(float zoomInMax) {
        this.zoomInMax = zoomInMax;
    }

    /**
     * @return How far the camera can zoom out from the player.
     */
    public float getZoomOutMax() {
        return zoomOutMax;
    }

    /**
     * @param zoomOutMax Set how far the camera can zoom out from the player.
     */
    public void setZoomOutMax(float zoomOutMax) {
        this.zoomOutMax = zoomOutMax;
    }

    /**
     * @return Is the camera trailing the player.
     */
    public boolean isTrail() {
        return trail;
    }

    /**
     * @param trail Set to true if you want the camera to trail
     * behind the player when he moves.
     */
    public void setTrail(boolean trail) {
        this.trail = trail;
    }

    /**
     * @return The camera trail speed
     */
    public float getTrailSpeed() {
        return trailSpeed;
    }

    /**
     * @param trailSpeed The camera trail speed.
     */
    public void setTrailSpeed(float trailSpeed) {
        this.trailSpeed = trailSpeed;
    }

    /**
     * @return the smartCamera
     */
    public boolean isSmartCamera() {
        return smartCamera;
    }

    /**
     * @param smartCamera the smartCamera to set
     */
    public void setSmartCamera(boolean smartCamera) {
        this.smartCamera = smartCamera;
    }

}
