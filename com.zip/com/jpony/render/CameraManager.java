package com.jpony.render;

import com.jpony.GameManager;
import com.jpony.player.ControlMode;
import com.jme3.app.FlyCamAppState;
import com.jme3.collision.CollisionResults;
import com.jme3.input.controls.AnalogListener;
import com.jme3.math.Quaternion;
import com.jme3.math.Ray;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.SceneGraphVisitor;
import com.jme3.scene.Spatial;

/**
 * The camera manager is used to adjust camera settings such switching
 * modes and mouse drag speed.
 * @author beer money
 */
public class CameraManager implements AnalogListener{
    
    public com.jme3.renderer.Camera                       camera;
    private final GameManager                             gameManager;
 
    public Node                                           cameraNode = new Node(CameraConstants.CAMERA_NODE);
    public Node                                           rotationNode = new Node(CameraConstants.ROTATION_NODE);
    
    public final CameraThirdPerson                        thirdPerson;
    public final CameraTopDown                            topDown;
    public final CameraFirstPerson                        firstPerson;
    
    public CameraControl                                  control = new CameraControl();
    
    private final Vector3f                                direction = new Vector3f();
    
    public CameraManager(GameManager gameManager){
     
     this.gameManager = gameManager;
     this.camera = gameManager.app.getCamera();
     thirdPerson = new CameraThirdPerson(gameManager);
     topDown = new CameraTopDown(gameManager);
     firstPerson = new CameraFirstPerson(gameManager);
     
     initialize();
     
    }
    
    private void initialize(){
        
        getCameraControl();
        
        gameManager.app.getFlyByCamera().setEnabled(false);
        gameManager.app.getFlyByCamera().unregisterInput();
        gameManager.app.getStateManager().detach(gameManager.app.getStateManager().getState(FlyCamAppState.class));
        addCameraNodes();
        
        gameManager.inputManager.addAnalogListener(this);

    }
    
    private void addCameraNodes(){
     boolean hasNode = false;
     for (Spatial spatial : gameManager.player.node.descendantMatches(Spatial.class, null)) {
         if (spatial.getName().equals(CameraConstants.ROTATION_NODE)){
              rotationNode = (Node)spatial;
              getCameraNode();
              hasNode = true;
         }
     }
     if (!hasNode){
       gameManager.player.node.attachChild(rotationNode);
       rotationNode.attachChild(cameraNode);
     }
    }
    
    private void getCameraNode(){
        for (Spatial spatial : rotationNode.descendantMatches(Spatial.class, null)) {
            if (spatial.getName().equals(CameraConstants.CAMERA_NODE)){
                cameraNode = (Node)spatial;
            }
        }
    }
    
    private void getCameraControl(){
        gameManager.node.depthFirstTraversal(new SceneGraphVisitor() {
          public void visit(Spatial spatial) {
            if (spatial.getControl(CameraControl.class) != null){
             control = spatial.getControl(CameraControl.class); 
          }
        }   
       });
    }
    
    /**
     * Sets the camera mode. There are three modes. First person ,
     * third person and top down.
     * @param controlMode 
     */
    public void setCameraMode(ControlMode controlMode){
        
           switch (controlMode) {
            case FIRST_PERSON:
                firstPerson.switchModes();
                break;
                    
            case THIRD_PERSON:
                thirdPerson.switchModes();
                break;
                         
            case TOP_DOWN:
                topDown.switchModes();
                break;
              
            default:
                System.out.println("Error camera mode not set properly.");
                break;
        }
        
    }
    
    /**
     * Resets the third person camera view to the default angle.
     */
    public void resetCameraTP(){
        if (gameManager.player.control.getControlMode() == ControlMode.THIRD_PERSON){
            rotationNode.setLocalRotation(Quaternion.IDENTITY);
            cameraNode.setLocalTranslation(control.getThirdPersonDefault());
        }
        
    }

    /**
     * Update the camera. This is for internal use only.
     * @param tpf 
     */
    public void update(float tpf){
       
       if (control.isEnabled()){
         
        switch (gameManager.player.control.getControlMode()) {
            case FIRST_PERSON:
                firstPerson.update(tpf);
                break;
                    
            case THIRD_PERSON:
                thirdPerson.update(tpf);
                thirdPerson.smartCamera();
                break;
                         
            case TOP_DOWN:
                topDown.update(tpf);
                break;
             
            default:
                System.out.println("Error camera mode not set properly.");
                break;
        }
        
       }
       
    }
    
    public void onAnalog(String name, float value, float tpf) {
      
      if (control.isEnabled()){     
       switch (gameManager.player.control.getControlMode()) {
            case FIRST_PERSON:
                firstPerson.analogUpdate(value,name,tpf);
                break;
                    
            case THIRD_PERSON:
                thirdPerson.analogUpdate(value,name,tpf);
                break;
                         
            case TOP_DOWN:
                topDown.analogUpdate(value,name,tpf);
                break;
             
            default:
                System.out.println("Error camera mode not set properly.");
                break;
        }    
      }
    }

    
    
}
