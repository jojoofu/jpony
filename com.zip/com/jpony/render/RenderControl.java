package com.jpony.render;

import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import java.io.IOException;

/**
 * The render controls allows you to make changes to a spatials visual
 * state.
 * @author beer money
 */
public class RenderControl extends AbstractControl {
    
    private int                            cullGroup = 1;
    private float                          cullDistance = 150;
    private int                            shadowGroup = 1;
    private float                          shadowDistance = 50;
    
    @Override
    protected void controlUpdate(float tpf) {
        //TODO: add code that controls Spatial,
        //e.g. spatial.rotate(tpf,tpf,tpf);
    }
    
    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        //Only needed for rendering-related operations,
        //not called when spatial is culled.
    }
    
    public Control cloneForSpatial(Spatial spatial) {
        RenderControl control = new RenderControl();
        //TODO: copy parameters to new Control
        return control;
    }
    
    @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        this.cullGroup = in.readInt("cullGroup",1);
        this.cullDistance = in.readInt("cullDistance",150);
        this.shadowGroup = in.readInt("shadowGroup",1);
        this.shadowDistance = in.readInt("shadowDistance",50);
         
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        out.write(this.cullGroup,"cullGroup",1);
        out.write(this.cullDistance,"cullDistance",150);
        out.write(this.shadowGroup,"shadowGroup",1);
        out.write(this.shadowDistance,"shadowDistance",50);
        
    }

    /**
     * @return The spatial's cull group.
     */
    public int getCullGroup() {
        return cullGroup;
    }

    /**
     * @param cullGroup Set the cull group the spatial belongs to.
     * There are only 3 cull groups.
     */
    public void setCullGroup(int cullGroup) {
        this.cullGroup = cullGroup;
    }

    /**
     * @return The distance from the play at which the spatial 
     * is culled.
     */
    public float getCullDistance() {
        return cullDistance;
    }

    /**
     * @param cullDistance Set the distance from the play at which 
     * the spatial is culled.
     */
    public void setCullDistance(float cullDistance) {
        this.cullDistance = cullDistance;
    }

    /**
     * @return the shadowGroup
     */
    public int getShadowGroup() {
        return shadowGroup;
    }

    /**
     * @param shadowGroup the shadowGroup to set
     */
    public void setShadowGroup(int shadowGroup) {
        this.shadowGroup = shadowGroup;
    }

    /**
     * @return the shadowDistance
     */
    public float getShadowDistance() {
        return shadowDistance;
    }

    /**
     * @param shadowDistance the shadowDistance to set
     */
    public void setShadowDistance(float shadowDistance) {
        this.shadowDistance = shadowDistance;
    }

    

}
