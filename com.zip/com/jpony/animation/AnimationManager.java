package com.jpony.animation;

import com.jme3.animation.AnimControl;
import com.jme3.animation.AnimEventListener;
import com.jme3.scene.Node;
import com.jpony.GameManager;
import com.jme3.scene.Spatial;
import java.util.ArrayList;
import java.util.List;
import com.jme3.animation.LoopMode;
import java.util.Collection;

/**
 * The animation manager is a hub for animated spatials. Spatials
 * with animation controls are automatically added to the animation
 * manager for easy access.
 * @author beer money
 */
public class AnimationManager {
    
    public final List<AnimationObject>        animationObjects = new ArrayList<>();
    
    private final GameManager                 gameManager;
    
    public AnimationManager(GameManager gameManager){
        this.gameManager = gameManager;
        getControls();
    }
    
    /**
     * Gets the animation controls from the scene.
     */
    private void getControls(){
        
       for (Spatial spatial : gameManager.node.descendantMatches(Spatial.class, null)) {
         
        if (spatial.getControl(AnimationControl.class) != null){
            
            Node temp = (Node)spatial;
            AnimationObject animationObject = new AnimationObject();
            animationObject.name = spatial.getName();
            
          for (Spatial spatialAnim : temp.descendantMatches(Spatial.class, null)) {
              
              if (spatialAnim.getControl(AnimControl.class) != null){
                 
                 AnimControl animControl = new AnimControl();
                 animControl = spatialAnim.getControl(AnimControl.class);
                 animControl.createChannel();
                 animationObject.controls.add(animControl);
                 playDefaultAnimation(animControl,spatial.getControl(AnimationControl.class).getDefaultAnimation(),spatial.getControl(AnimationControl.class).getAnimationSpeed());
              
              }

            }
          
          animationObjects.add(animationObject); 

         }
       }
       
    }
    
    private void playDefaultAnimation(AnimControl animControl,String animationName,float speed){
        int length = animControl.getNumChannels();
        for (int i = 0; i < length ; i++){
            animControl.getChannel(i).setAnim(animationName);
            animControl.getChannel(i).setSpeed(speed);
            animControl.getChannel(i).setLoopMode(LoopMode.Loop);
        }
    }
    
    /**
     * Stops an animation.
     * @param name The name of the animated spatial.
     */
    public void stop(String name){
        
        for (AnimationObject animationObject : animationObjects) {
            if (animationObject.name.equals(name)) {
                for (AnimControl control : animationObject.controls){
                  int length = control.getNumChannels();
                  for (int i = 0; i < length ; i++){
                     control.getChannel(i).setSpeed(0);          
                  }
                }
            }
        }
    }
    
    /**
     * Plays an animation.
     * @param name The name of the animated spatial.
     * @param animation The name of the animation to play.
     * @param speed The animation speed.
     * @param loopMode The loop mode.
     */
    public void play(String name,String animation,Float speed,LoopMode loopMode){
        for (AnimationObject animationObject : animationObjects) {
            if (animationObject.name.equals(name)) {
                for (AnimControl control : animationObject.controls){
                    for (String animationName : control.getAnimationNames()){
                        if (animationName.equals(animation)){
                           int length = control.getNumChannels();
                           for (int i = 0; i < length ; i++){
                              control.getChannel(i).setAnim(animation);
                              control.getChannel(i).setSpeed(speed);
                              control.getChannel(i).setLoopMode(loopMode);   
                           } 
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Gets an animation object. Animation objects hold references to 
     * the animations controls.
     * @param name The name of the animation object to get. The is the
     * same name as the spatial the animation came from.
     * @return <code>AnimationObject</code>
     */
    public AnimationObject get(String name){
        for (AnimationObject animationObject : animationObjects) {
            if (animationObject.name.equals(name)) {
                return animationObject;
            }
        }
        return null;
    }
    
    /**
     * Adds a listener for every animations control in the scene.
     * This is mainly for testing purposes and is not recommended
     * for regular use.
     * @param listener The listener
     */
    public void addListener(AnimEventListener listener){
        for (AnimationObject animationObject : animationObjects) {
            for (AnimControl control : animationObject.controls){
                control.addListener(listener);
            }
        }
    }
    
    private void printControls(){
        for (AnimationObject object : animationObjects){
            for (AnimControl control : object.controls){
                Collection<String> names = control.getAnimationNames();
                for (String name : names){
                    System.out.println(name);
                }
            }
        }
    }
    
}
