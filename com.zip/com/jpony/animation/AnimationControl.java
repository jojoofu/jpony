package com.jpony.animation;

import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import java.io.IOException;

/**
 * This control acts as a tag for animated spatials. Spatials with this
 * control will automatically be parsed into the animation manager. This
 * control is meant to be used via the scene explorer. You must add this
 * control to the spatial before the scene is loaded.
 * @author beer money
 */
public class AnimationControl extends AbstractControl {
    
    private String           defaultAnimation = "none";
    private float            animationSpeed = 1;
    
    @Override
    protected void controlUpdate(float tpf) {
        //TODO: add code that controls Spatial,
        //e.g. spatial.rotate(tpf,tpf,tpf);
    }
    
    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        //Only needed for rendering-related operations,
        //not called when spatial is culled.
    }
    
    public Control cloneForSpatial(Spatial spatial) {
        AnimationControl control = new AnimationControl();
        //TODO: copy parameters to new Control
        return control;
    }
    
    @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //TODO: load properties of this Control, e.g.
        //this.value = in.readFloat("name", defaultValue);
        this.animationSpeed = in.readFloat("animationSpeed",1);
        this.defaultAnimation = in.readString("defaultAnimation", "none");
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        out.write(this.animationSpeed,"animationSpeed",1);
        out.write(this.defaultAnimation,"defaultAnimation","none");
        //TODO: save properties of this Control, e.g.
        //out.write(this.value, "name", defaultValue);
    }

    /**
     * @return The default animation
     */
    public String getDefaultAnimation() {
        return defaultAnimation;
    }

    /**
     * @param defaultAnimation The animation that plays after the scene is loaded.
     */
    public void setDefaultAnimation(String defaultAnimation) {
        this.defaultAnimation = defaultAnimation;
    }

    /**
     * @return the animation speed
     */
    public float getAnimationSpeed() {
        return animationSpeed;
    }

    /**
     * @param animationSpeed The speed of the animation.
     */
    public void setAnimationSpeed(float animationSpeed) {
        this.animationSpeed = animationSpeed;
    }
    
}
