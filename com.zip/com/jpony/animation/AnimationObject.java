package com.jpony.animation;

import com.jme3.animation.AnimControl;
import java.util.ArrayList;
import java.util.List;

public class AnimationObject {
    
    public List<AnimControl>                  controls =  new ArrayList<AnimControl>();
    
    public String                             name;
    
    private boolean                           inMotion = false;
    
    public AnimationObject(){
        
    }

    /**
     * @return the inMotion
     */
    public boolean isInMotion() {
        return inMotion;
    }

    /**
     * @param inMotion the inMotion to set
     */
    public void setInMotion(boolean inMotion) {
        this.inMotion = inMotion;
    }
    
}
