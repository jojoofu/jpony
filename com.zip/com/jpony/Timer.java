package com.jpony;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The timer class is used to time events. The timer is hooked into the
 * main game loop. Each loop the time per frame in milliseconds is added.
 * Once the timer hits the set time it will fire the tick event and reset
 * to zero. The timer then resumes another count down. The timer will continue
 * this cycle until stopped.
 * @author beer money
 * @version 1.0 final
 */
public class Timer {
    
   private final List               listeners = new ArrayList();
   private boolean                  enabled = false;
   private float                    time = 0;
   private float                    timeElapsed = 0;
   private String                   name;
   
   public Timer(String name,float time){
        this.time = time;
        this.name = name;
   }
   
   /**
    * Start the timer.
    */
   public void start(){
       enabled = true;
   }
   
   /**
    * Stop the timer.
    */
   public void stop(){
       enabled = false;    
   }
   
   /**
    * Add a listener to the timer
    * @param timerListener The listener to add
    */
   public synchronized void addListener(TimerListener timerListener) {
        listeners.add(timerListener);
    }
   
   /**
    * Remove a listener from the timer.
    * @param timerListener The listener to remove.
    */
   public synchronized void removeListener(TimerListener timerListener) {
        listeners.remove(timerListener);
    }
   
   private synchronized void fireTickEvent() {
        Iterator iterator = listeners.iterator();
        while(iterator.hasNext()) {
            ((TimerListener)iterator.next()).tick();
        }
    }
   
   private void add(float amount) {
         timeElapsed += amount;
    }
   
   /**
    * Resets the timer to zero.
    */
   public void reset(){
        timeElapsed = 0;
    }
   
   /**
    * Manually set the time.
    * @param time Time in seconds.
    */
   public void setTime(float time) {
        this.time = time;
    }
   
   /**
    * @return The time in seconds.
    */
   public float getTime(){
        return this.time;    
   }
   
   private boolean timesUp(){
       return timeElapsed > time;
   }
   
   /**
    * Updates the timer. Each frame the tpf is added to current time.
    * Once the timer reaches the set time it fires the tick event.
    * After the tick event is fired the timer resets to zero.
    * @param tpf 
    */
   public void update(float tpf){
        if (enabled){
           add(tpf);
         if (timesUp()){
            fireTickEvent();
            reset();
         }  
        }  
   }

    /**
     * @return The name of the timer
     */
    public String getName() {
        return name;
    }

    /**
     * @param name The name of the timer
     */
    public void setName(String name) {
        this.name = name;
    }

}
