package com.jpony.save;

import com.jpony.GameManager;
import com.jme3.export.binary.BinaryExporter;
import com.jme3.scene.Node;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The save manager handles loading and saving of .j3o files for use
 * with JPony.
 * @author beer money
 */
public class SaveManager {
 
    private final GameManager            gameManager;
    
    public SaveManager(GameManager gameManager){
        this.gameManager = gameManager; 
    }
    
    /**
     * Save to a .j3o file.
     * @param filePath Path to the file.
     * @param node The node to save.
     */
    public void save(String filePath , Node node){
        
    BinaryExporter exporter = BinaryExporter.getInstance();
    File file = new File(filePath);
    try {
      exporter.save(node, file);
    } catch (IOException ex) {
      Logger.getLogger(SaveManager.class.getName()).log(Level.SEVERE, "Error: Failed to save game!", ex);
    }
    
    }
    
    /**
     * Load a .j3o file.
     * @param filePath Path to file.
     * @param node The node to load the file into.
     */
    public void load(String filePath , Node node){
     node = (Node)gameManager.app.getAssetManager().loadModel(filePath);
    }
    
}
