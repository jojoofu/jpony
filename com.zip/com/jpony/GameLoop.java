package com.jpony;

import com.jme3.app.state.AbstractAppState;
import com.jme3.scene.Spatial;

/** The main game loop for a jpony application.
* In the main loop the managers are updated and updates are made
* to individual spatials.
* @author beer money
* @version 0.5
**/
public class GameLoop extends AbstractAppState{
    
    private final GameManager         gameManager;
    private boolean                   pause = true;  
    
    public GameLoop(GameManager scene){
        this.gameManager = scene;  
    }
    
    /**
     * Stops the game loop. Call this before you
     * load a new scene. Attemptig to load a scene with the main
     * loop running will result in an error.
     */
    public void stop(){
        pause = true;
    }
    
    /**
     * Starts the game loop. This should only be called
     * after you initliaze your game.
     */
    public void start(){
        pause = false;
    }
    
/**
 * hooks into the main JME update loop
 * @param tpf Time Per Frame
 */
@Override
public void update(float tpf) {
    
    loop(tpf);
    
}

/**
 * The main loop.Here we update our managers and individual spatials
 * @param tpf Time Per Frame
 */
private void loop(float tpf){
    
    if (!pause) {
    
    // update key input
    gameManager.inputManager.update();
    // move player
    gameManager.player.update(tpf);
    // move camera
    gameManager.cameraManager.update(tpf);
    // check if player is on ground
    gameManager.physicsManager.playerOnGround();
    // update our timers
    gameManager.timerManager.update(tpf);
    
    // make updates to individual spatials in scene and picking node
    for (Spatial spatial : gameManager.node.descendantMatches(Spatial.class, null)) {
             
             // update the spatial's render state
             gameManager.renderManager.update(spatial);
             // update phsyics state
             gameManager.physicsManager.update(spatial);
             //possible move to player idle event ****
             gameManager.physicsManager.adjustFriction(spatial);
             // collect any pick up on touch entities
             gameManager.entityManager.collectOnTouch(spatial);
             // swap nearby objects to picking node
             gameManager.entityManager.update(spatial);
        
    } 

    //post update - once our spatials have been updated we perform post
    //update task such entity picking and debug updates.
    // pick our targeted object from the entity picking node 
    // and parse its information
    gameManager.entityManager.getTarget();
    // update debug tracker
    gameManager.debugTracker.update();
    
    }
          
}

}
