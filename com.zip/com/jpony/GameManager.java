package com.jpony;

import com.jpony.save.SaveManager;
import com.jpony.UI.UserInterfaceManager;
import com.jme3.app.SimpleApplication;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jpony.animation.AnimationManager;
import com.jpony.audio.AudioManager;
import com.jpony.entity.EntityManager;
import com.jpony.input.InputManager;
import com.jpony.physics.PhysicsManager;
import com.jpony.render.RenderManager;
import com.jme3.system.AppSettings;
import com.jpony.entity.EntityControl;
import com.jpony.physics.PhysicsControl;

/**
 * The hub for all managers. This class acts an organizer and hub for
 * easy access to all of the managers.
 * @author beer money
 * @version 0.5
 */
public class GameManager{

public SimpleApplication                          app;
public AnimationManager                           animationManager;
public AudioManager                               audioManager;
public com.jpony.render.CameraManager             cameraManager;
public EntityManager                              entityManager;
public GameLoop                                   gameLoop;
public InputManager                               inputManager;
public PhysicsManager                             physicsManager;
public com.jpony.player.Player                    player;
public RenderManager                              renderManager;
public Node                                       node;
public AppSettings                                settings;
public TimerManager                               timerManager;
public DebugTracker                               debugTracker;
public UserInterfaceManager                       UImanager;
public SaveManager                                saveManager;

public GameManager(String filePath,AppSettings settings,SimpleApplication app){
 
     this.settings = settings;
     this.app = app;
     initialize(filePath);
    
 }
 
// set up the game
private void initialize(String filePath){
    
    // Turn off testing output
    app.setDisplayFps(false);       
    app.setDisplayStatView(false);
    // set the camera to have closer clipping
    app.getCamera().setFrustumPerspective(45f, (float) app.getCamera().getWidth() / app.getCamera().getHeight(), 0.01f, 1000f);
    app.getCamera().setLocation(new Vector3f(0,1,0));
    // set the back ground color
    app.getViewPort().setBackgroundColor(new ColorRGBA(0.7f, 0.8f, 1f, 1f));
    // load the scene and store it in a node
    node = (Node)app.getAssetManager().loadModel(filePath);
    // attach scene to our root node
    app.getRootNode().attachChild(node);
    // create our manager classes
    createManagers();
    
    getControlParents();
            
  }

private void createManagers() {
    
    // create new manager and register them in this order
    UImanager = new UserInterfaceManager(this);
    inputManager = new InputManager(this);
    timerManager = new TimerManager(this);
    animationManager = new AnimationManager(this);
    player = new com.jpony.player.Player(this);
    physicsManager = new PhysicsManager(this);
    entityManager = new EntityManager(this);
    renderManager = new RenderManager(this);
    audioManager = new AudioManager(this);
    cameraManager = new com.jpony.render.CameraManager(this);
    cameraManager.setCameraMode(player.control.getControlMode());
    gameLoop = new GameLoop(this);
    gameLoop.setEnabled(true);
    app.getStateManager().attach(gameLoop);
    debugTracker = new DebugTracker(this);
    saveManager = new SaveManager(this);
    
}

/**
 * Get the parent nodes of our physics and entity controls. Then 
 * when swapping between picking and scene nodes uses the parent
 * as a reference.
 */
private void getControlParents(){
    for (Spatial spatial : node.descendantMatches(Spatial.class, null)) {
        if (spatial.getControl(PhysicsControl.class) != null){
            spatial.getControl(PhysicsControl.class).parent = spatial.getParent();
            spatial.getControl(PhysicsControl.class).world = spatial.getWorldTranslation();
        }
        if (spatial.getControl(EntityControl.class) != null){
            spatial.getControl(EntityControl.class).parent = spatial.getParent();
            spatial.getControl(EntityControl.class).world = spatial.getWorldTranslation();
        }
    }
}
/**
 * Returns the specified geometry. 
 * If no such geometry exist returns null.
 * @param name The name of the geometry to return
 * @return The specified geometry
 */
public Geometry getGeometry(String name){
        
        for (Spatial spatial : node.descendantMatches(Geometry.class, null)) {
           if (spatial.getName().equals(name)) {
               return (Geometry)spatial;
           }
        }
          return null;
    }

}
