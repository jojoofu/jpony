package com.jpony.physics;

import com.jme3.bullet.control.RigidBodyControl;

/**
 * The physics object is used for storing references to a spatial's
 * controls.
 * @author beer money
 */
public class PhysicsObject {
     
     public PhysicsControl               control;
     public RigidBodyControl             rigidBodyControl;
     public String                       name;
     public boolean                      inRange = false;
     
     public PhysicsObject(){
         
     }
  
}
