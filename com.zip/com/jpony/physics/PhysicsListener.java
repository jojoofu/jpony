package com.jpony.physics;

import com.jme3.scene.Spatial;

/**
 * The physics event listener.
 * @author april
 */
public interface PhysicsListener {
    
    /**
     * Fired when the spatials physics are activated.
     * @param spatial The physics spatial.
     */
    public void physicsApplied(Spatial spatial);
    
    /**
     * Fires when the spatials physics are deactivated.
     * @param spatial The physics spatial.
     */
    public void physicsRemoved(Spatial spatial);
    
}
