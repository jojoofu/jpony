package com.jpony.physics;

public class PhysicsConstants {
    
    public static final String          COLLISION_NODE = "COLLISION_NODE";
    
}
