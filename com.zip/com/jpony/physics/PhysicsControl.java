package com.jpony.physics;

import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import java.io.IOException;

/**
 * The physics control is used make changes to a spatials physical state.
 * @author beer money
 */
public class PhysicsControl extends AbstractControl {
    
    private float                    weight = 0;
    private float                    range = 10;
    private float                    surfaceResistance = 0f;
    private float                    traction = 8f;
    
    public Node                      parent;
    public Vector3f                  world = new Vector3f(0,0,0);
    public int                       passes = 0;
    public boolean                   pass = false;
    
    @Override
    protected void controlUpdate(float tpf) {
        //TODO: add code that controls Spatial,
        //e.g. spatial.rotate(tpf,tpf,tpf);
    }
    
    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        //Only needed for rendering-related operations,
        //not called when spatial is culled.
    }
    
    public Control cloneForSpatial(Spatial spatial) {
        PhysicsControl control = new PhysicsControl();
        //TODO: copy parameters to new Control
        return control;
    }
    
    @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //TODO: load properties of this Control, e.g.
        //this.value = in.readFloat("name", defaultValue);
        this.weight = in.readFloat("weight",0);
        this.range = in.readFloat("range", 10);
        this.surfaceResistance = in.readFloat("surfaceResistance",0);
        this.traction = in.readFloat("traction", 8);
        
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        //TODO: save properties of this Control, e.g.
        //out.write(this.value, "name", defaultValue);
        out.write(this.weight,"weight", 0);
        out.write(this.range,"range",10);
        out.write(this.surfaceResistance,"surfaceResistance", 0);
        out.write(this.traction,"traction",8);
    }

    /**
     * @return The spatials weight.
     */
    public float getWeight() {
        return weight;
    }

    /**
     * @param weight Set the spatials weight
     */
    public void setWeight(float weight) {
        this.weight = weight;
    }

    /**
     * @return The spatials range.
     */
    public float getRange() {
        return range;
    }

    /**
     * @param range The range of the spatial from the player at which the
     * physics is activated.
     */
    public void setRange(float range) {
        this.range = range;
    }

    /**
     * @return The spatials friction.
     */
    public float getSurfaceResistance() {
        return surfaceResistance;
    }

    /**
     * @param surfaceResistance Set the spatials friction.
     */
    public void setSurfaceResistance(float surfaceResistance) {
        this.surfaceResistance = surfaceResistance;
    }

    /**
     * @return The surface traction of the spatial.
     */
    public float getTraction() {
        return traction;
    }

    /**
     * @param traction Set the surface traction.
     */
    public void setTraction(float traction) {
        this.traction = traction;
    }
    
}
