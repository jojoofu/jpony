package com.jpony.physics;

import com.jpony.GameManager;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.collision.shapes.CollisionShape;
import com.jme3.bullet.control.BetterCharacterControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.bullet.util.CollisionShapeFactory;
import com.jme3.collision.CollisionResults;
import com.jme3.math.Ray;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.terrain.geomipmap.TerrainQuad;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The physics manager handles changing a spatials physical state.
 * @author beer money.
 */
public class PhysicsManager {
    
    public BulletAppState                bulletAppState;
    //public BetterCharacterControl        playerControl;
    public PhysicsCharacter              playerControl;
    public GameManager                   gameManager;
    
    private boolean                      onGround = true;
    
    public List<PhysicsObject>           physicsObjects = new ArrayList<>();
    private final List                   listener = new ArrayList();
    
    // ground and angle
    private float                         groundTolerance;
    public float                         distanceToGround;
    public float                         angleDepth;
    
    public PhysicsManager(GameManager gameManager){
        this.gameManager = gameManager;

        /** Set up Physics */
        bulletAppState = new BulletAppState();
        gameManager.app.getStateManager().attach(bulletAppState);
        createPlayerControl();
    }

    /**
     * Adds a physics listener.
     * @param listener The listener to add.
     */
    public synchronized void addListener(PhysicsListener listener) {
        this.listener.add(listener);
    }
    
    /**
     * Removes a physics listener.
     * @param listener The listener to remove.
     */
    public synchronized void removeListener(PhysicsListener listener) {
        this.listener.remove(listener);
    }

    private synchronized void fireApplied(Spatial spatial) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((PhysicsListener)iterator.next()).physicsApplied(spatial);
        }
    }
    
    private synchronized void fireRemoved(Spatial spatial) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((PhysicsListener)iterator.next()).physicsRemoved(spatial);
        }
    }

/**
 * Sets the spatials friction.
 * @param name The name of the spatial.
 * @param force The force of the friction.
 */
public void setFriction(String name,float force) {
          
       for (Spatial spatial : gameManager.node.descendantMatches(Spatial.class, null)) {
         if (spatial.getName().equals(name)){
             if (spatial.getControl(PhysicsControl.class) != null) {
              getRigidBodyControl(spatial.getName()).setFriction(force);   
             }
         }
        } 
          
      }

/**
 * Sets the spatials friction.
 * @param spatial The spatial whose friction to set.
 * @param force The force of the friction.
 */
public void setFriction(Spatial spatial,float force) {
          
    getRigidBodyControl(spatial.getName()).setFriction(force);
             
}
    
/**
 * Sets the friction of all physics spatials in the scene.
 * @param force The force of the friction.
 */
public void setGlobalFriction(float force) {
          
         for (Spatial spatial : gameManager.node.descendantMatches(Spatial.class, null)) {
              
           if (spatial.getControl(PhysicsControl.class) != null) {
                   getRigidBodyControl(spatial.getName()).setFriction(force);
           } 

         }
          
      }
   
private void createPlayerControl(){
    
    // create character control parameters (Radius,Height,Weight)
    // Radius and Height determine the size of the collision bubble
    // Weight determines how much gravity effects the control
    addCollisionNode();
    addPlayerControl();
    bulletAppState.getPhysicsSpace().add(playerControl);
    createRigidBodies();
    setGroundTolerance();
}

private void addPlayerControl(){
         
         if (gameManager.player.control.collisionNode.getControl(BetterCharacterControl.class) != null){
            playerControl = gameManager.player.control.collisionNode.getControl(PhysicsCharacter.class);
            playerControl.warp(gameManager.player.control.collisionNode.getLocalTranslation());
            gameManager.player.node.setLocalTranslation(gameManager.player.control.collisionNode.getLocalTranslation());
         } else {
            playerControl = new PhysicsCharacter(gameManager.player.control.getCollisionCapsule().x,gameManager.player.control.getCollisionCapsule().y,gameManager.player.control.getCollisionCapsule().z,gameManager);
            playerControl.warp(gameManager.player.node.getLocalTranslation());
            playerControl.setJumpForce(gameManager.player.control.getJumpForce());
            playerControl.setGravity(gameManager.player.control.getGravity());
            playerControl.setPhysicsDamping(gameManager.player.control.getPhysicsDampening());
            gameManager.player.control.collisionNode.setLocalTranslation(gameManager.player.node.getLocalTranslation());
            gameManager.player.control.collisionNode.addControl(playerControl);
         }
         
}

private void addCollisionNode(){
    boolean hasNode = false;
    for (Spatial spatial : gameManager.node.descendantMatches(Spatial.class, null)) {
        if (spatial.getName().equals(PhysicsConstants.COLLISION_NODE)){
            gameManager.player.control.collisionNode = (Node)spatial;
            hasNode = true;
        }
    }
    if (!hasNode){
      gameManager.node.attachChild(gameManager.player.control.collisionNode);  
    }
    
}

/**
 * Turn a node left to right.
 * @param node The node to turn.
 * @param radian The radian amount of the turn.
 */
public void yaw(Node node,Float radian){
    node.rotate(0, radian, 0);
}

/**
 * Turn a node front to back.
 * @param node The node to turn.
 * @param radian The radian amount of the turn.
 */
public void pitch(Node node,Float radian){
    node.rotate(radian,0 , 0);
}

/**
 * Turn a node side to side.
 * @param node The node to turn.
 * @param radian The radian amount of the turn.
 */
public void roll(Node node,Float radian){
    node.rotate(0, 0, radian);
}
    
private void createRigidBodies(){
    
     for (Spatial spatial : gameManager.node.descendantMatches(Spatial.class, null)) {
              
           if (spatial.getControl(PhysicsControl.class) != null) {
               addRigidBody(spatial);
           } 
           
        }   
     
}

private void addRigidBody(Spatial spatial){
    
      if (spatial.getControl(RigidBodyControl.class) != null){
          RigidBodyControl tempBody = spatial.getControl(RigidBodyControl.class);
          bulletAppState.getPhysicsSpace().add(tempBody);
          
          PhysicsObject tempPhysicsObject = new PhysicsObject();
          tempPhysicsObject.rigidBodyControl = tempBody;
          tempPhysicsObject.name = spatial.getName();
          tempPhysicsObject.control = spatial.getControl(PhysicsControl.class);
          physicsObjects.add(tempPhysicsObject); 
      } else {
         RigidBodyControl tempBody;
         CollisionShape sceneShape = CollisionShapeFactory.createMeshShape(spatial);
         tempBody = new RigidBodyControl(sceneShape,spatial.getControl(PhysicsControl.class).getWeight());
         spatial.addControl(tempBody);
         bulletAppState.getPhysicsSpace().add(tempBody);
      
         PhysicsObject tempPhysicsObject = new PhysicsObject();
         tempPhysicsObject.rigidBodyControl = tempBody;
         tempPhysicsObject.name = spatial.getName();
         tempPhysicsObject.control = spatial.getControl(PhysicsControl.class);
         physicsObjects.add(tempPhysicsObject); 
      }
      
      
}

/**
 * Update a physics spatial. For internal use only.
 * @param spatial 
 */
public void update(Spatial spatial){
    
   if (spatial.getControl(PhysicsControl.class) != null) {
       if (gameManager.player.getSpatialDistance(spatial) < spatial.getControl(PhysicsControl.class).getRange()){
           setInRange(true,spatial);
       } else {
           setInRange(false,spatial);
       }
   } 
    
}

/**
 * Determines if the physics spatial is within range of the player.
 * @param spatial The spatial to test.
 * @return True if the spatial is within range.
 */
public boolean inRangeOf(Spatial spatial){
    return gameManager.player.getSpatialDistance(spatial) < spatial.getControl(PhysicsControl.class).getRange();
}

/**
 * Gets the spatials rigid body control.
 * @param name The name of the spatial.
 * @return <code>RigidBodyControl</code>
 */
public RigidBodyControl getRigidBodyControl(String name){
    for (PhysicsObject tempObject : physicsObjects){
        if (tempObject.name.equals(name)) {
            return tempObject.rigidBodyControl;
        }
    }
        return null;
}

/**
 * Gets the physics object associated with the player. The physics
 * object contains references to the spatials rigid body as well as
 * other variables for tracking physics updates.
 * @param name The name of spatial
 * @return <code>PhysicsObject</code>
 */
public PhysicsObject getPhysicsObject(String name){
    for (PhysicsObject physicsObject : physicsObjects){
        if (physicsObject.name.equals(name)) {
            return physicsObject;
        }
    }
        return null;
}

/**
 * Sets the spatial's friction and traction. For internal use only.
 * @param spatial The spatial to set.
 */
public void adjustFriction(Spatial spatial){

    if (spatial.getControl(PhysicsControl.class) != null) {
       if (!onGround) {
          gameManager.physicsManager.setFriction(spatial,0);
          return;
       }
       if (gameManager.inputManager.isIdle()){
            gameManager.physicsManager.setFriction(spatial,spatial.getControl(PhysicsControl.class).getTraction());  
            gameManager.physicsManager.playerControl.setPhysicsDamping(0.0f);     
       } else {
            gameManager.physicsManager.setFriction(spatial,spatial.getControl(PhysicsControl.class).getSurfaceResistance());  
            gameManager.physicsManager.playerControl.setPhysicsDamping(gameManager.player.control.getPhysicsDampening()); 
       } 
  }
    
}

/**
 * Check if the player is on the ground.
 */
public void playerOnGround(){
    distanceToGround = distanceToGround();
    angleDepth = getGroundTolerance() - distanceToGround;
    onGround = distanceToGround < getGroundTolerance();
    gameManager.physicsManager.playerControl.slopeAngle.set(gameManager.physicsManager.playerControl.capsuleAngle.x,gameManager.physicsManager.playerControl.capsuleAngle.y + distanceToGround);
}

private float distanceToGround(){

        CollisionResults results = new CollisionResults();
        // 2. Aim the ray from cam loc to cam direction.
        Ray ray = new Ray(gameManager.player.node.getLocalTranslation(),Vector3f.UNIT_Y.negate());
        // 3. Collect intersections between Ray and Shootables in results list.
        gameManager.node.collideWith(ray, results);
        // 4. Print the results
        if (results.size() > 0) {
            return results.getClosestCollision().getDistance();
        }
        return -1;
}

    /**
     * @return Is the player on the ground.
     */
    public boolean isOnGround() {
        return onGround;
    }

    private void setInRange(boolean inRange,Spatial spatial) {
        
        if (inRange && inRange != getPhysicsObject(spatial.getName()).inRange){
            physicsApplied(spatial);
            fireApplied(spatial);
        } else if (!inRange && inRange != getPhysicsObject(spatial.getName()).inRange){
            physicsRemoved(spatial);
            fireRemoved(spatial);
        }
            getPhysicsObject(spatial.getName()).inRange = inRange;
    }
    
    private void physicsApplied(Spatial spatial){
        getRigidBodyControl(spatial.getName()).setEnabled(true);
        // adds only non terrain objects to picking node if specified to ingore terrain
        ignoreTerrain(spatial);
    }
    
    private void physicsRemoved(Spatial spatial){
        getRigidBodyControl(spatial.getName()).setEnabled(false);
        spatial.getControl(PhysicsControl.class).parent.attachChild(spatial);
        spatial.getLocalTranslation().subtractLocal(spatial.getControl(PhysicsControl.class).world); 
    }
    
    private void ignoreTerrain(Spatial spatial){

    if (gameManager.entityManager.isIgnoreTerrain()){
        if (spatial instanceof TerrainQuad){
            // do not add to picking node
        } else {
            copyWorld(spatial);
            gameManager.entityManager.node.attachChild(spatial);
            spatial.getLocalTranslation().addLocal(spatial.getControl(PhysicsControl.class).world); 
        }
    } else {
        copyWorld(spatial);
        gameManager.entityManager.node.attachChild(spatial);
        spatial.getLocalTranslation().addLocal(spatial.getControl(PhysicsControl.class).world); 
    }
        
    }
    
private void copyWorld(Spatial spatial){
    spatial.getControl(PhysicsControl.class).world = spatial.getWorldTranslation().subtract(spatial.getLocalTranslation());
}
    
/**
 * Determines if the player instersects with a spatial.
 * @param spatial The spatial to test.
 * @return True if an intersection occurs.
 */
public boolean intersects(Spatial spatial){
   
    return gameManager.player.node.getWorldBound().intersects(spatial.getWorldBound());

}

/**
 * Returs the distance between two vectors.
 * @param to To vector
 * @param from From Vector
 * @return 
 */
public float getDistance(Vector3f from,Vector3f to){
        
        return  from.distance(to);

}

    /**
     * @return The ground tolerance.
     */
    public float getGroundTolerance() {
        return groundTolerance;
    }
    
    /**
     * Set the distance from the ground at which slop angles are measured.
     */
    public void setGroundTolerance() {
        groundTolerance = gameManager.player.control.getCollisionCapsule().y * gameManager.player.control.getSlopeIntensity();
    }

}
