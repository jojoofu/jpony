package com.jpony;

public interface TimerListener {
    
    public void tick();
    
}
