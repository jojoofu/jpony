package com.jpony;

import java.util.ArrayList;

/**
 * Manages the updates to timers.
 * @author beer money
 */
public class TimerManager {
    
    private final GameManager        gameManager;
    private final ArrayList<Timer>   timers = new ArrayList();
    
    public TimerManager(GameManager gameManager){
        this.gameManager = gameManager;
    }
    
    /**
     * Updates all timers.
     * @param tpf The Timer Per Frame
     */
    public void update(float tpf){
        for (Timer timer : timers){
            timer.update(tpf);
        }
    }
    
    /**
     * Adds a timer to the manager
     * @param timer The timer to add.
     */
    public void add(Timer timer){
       timers.add(timer);
    }
    
    /**
     * Removes a timer from the manager.
     * @param name The name of the timer to remove.
     */
    public void remove(String name){
        int size = timers.size();
        for (int i = 0; i < size ; i++){
            if (timers.get(i).getName().equals(name)){
                timers.remove(i);
                return;
            }
        }
    }
    
}
