package com.jpony.UI;

public class ControlConstants {
    
    public static final int               BUTTON = 1;
    public static final int               IMAGE = 2;
    public static final int               TEXT_BOX = 3;
    public static final int               DIALOGUE_BOX = 4;
    public static final int               LABEL = 5;
    public static final int               FRAME = 6;
    public static final int               SCROLL_BAR = 7;
    
    public static final String            CONTROL_TYPE = "CONTROL_TYPE";
    public static final String            MOUSE_DRAG = "MOUSE_DRAG";
    public static final String            RESIZABLE = "RESIZABLE";
    public static final String            ENABLED = "ENABLED";
    public static final String            TEXT = "TEXT";
    public static final String            TRUE_SIZE = "TRUE_SIZE";
    public static final String            TRUE_LOCATION = "TRUE_LOCATION";
    public static final String            SIZE = "SIZE";
    public static final String            LOCATION = "LOCATION";
    
    
}
