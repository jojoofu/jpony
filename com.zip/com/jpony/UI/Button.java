package com.jpony.UI;

import com.jpony.GameManager;
import com.jme3.asset.plugins.FileLocator;
import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.texture.Texture2D;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Button extends Control {
     
    private Texture2D                       hoverTexture;
    private Texture2D                       pressedTexture;
    private Texture2D                       defaultTexture;
    
    private String                          hoverFile;
    private String                          pressedFile;
    private String                          defaultFile;
    
    @Override
    public void construct(String name,GameManager gameManager){
        super.construct(name,gameManager);
    }
    
    @Override
    public void initialize(GameManager gameManager){
        super.initialize(gameManager);
        this.hoverTexture = (Texture2D)gameManager.app.getAssetManager().loadTexture(hoverFile);
        this.pressedTexture = (Texture2D)gameManager.app.getAssetManager().loadTexture(pressedFile);
        this.defaultTexture = (Texture2D)gameManager.app.getAssetManager().loadTexture(defaultFile);
    }
    
    @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //TODO: load properties of this Control, e.g.
        this.hoverFile = in.readString("hoverFile","orangebutton.png");
        this.pressedFile = in.readString("pressedFile","redbutton.png");
        this.defaultFile = in.readString("defaultFile","greenbutton.png");
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        //TODO: save properties of this Control, e.g.
        out.write(this.hoverFile, "hoverFile", "orangebutton.png");
        out.write(this.pressedFile, "pressedFile", "redbutton.png");
        out.write(this.defaultFile, "defaultFile", "greenbutton.png");
    }
    
    @Override
    public void mouseEnter() {
        super.mouseEnter();
        material.setTexture("ColorMap",hoverTexture);
    }

    @Override
    public void mouseExit() {
       super.mouseExit();
       material.setTexture("ColorMap",defaultTexture);
    }

    @Override
    public void mouseDown() {
       super.mouseDown();
       material.setTexture("ColorMap",pressedTexture);
    }

    @Override
    public void mouseUp() {
       super.mouseUp();
       material.setTexture("ColorMap", hoverTexture);
    }

    private void createGraphics(BufferedImage bufferedImage){
        // create image
     bufferedImage = new BufferedImage((int)getTrueSize().x, (int)getTrueSize().y,BufferedImage.TYPE_INT_ARGB);
     // create graphics object from image
     graphics = bufferedImage.createGraphics();
     // make image transparent
     graphics.setBackground(new Color(0, 0, 0, 0));
     // draw string
     graphics.setColor(getColor());
     graphics.setFont(getFont());
     graphics.fillRect(0, 0, (int)getTrueSize().x, (int)getTrueSize().y);
     graphics.dispose();
    }

    /**
     * @return the hoverTexture
     */
    public Texture2D getHoverTexture() {
        return hoverTexture;
    }

    public void setHoverTexture(File file) {
      gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
      this.hoverTexture = (Texture2D)gameManager.app.getAssetManager().loadTexture(file.getName()); 
      this.hoverFile = file.getName();
      gameManager.app.getAssetManager().unregisterLocator(file.getParent(), FileLocator.class);
    }

    /**
     * @return the pressedTexture
     */
    public Texture2D getPressedTexture() {
        return pressedTexture;
    }

    public void setPressedTexture(File file) {
      gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
      this.pressedTexture = (Texture2D)gameManager.app.getAssetManager().loadTexture(file.getName()); 
      this.pressedFile = file.getName();
      gameManager.app.getAssetManager().unregisterLocator(file.getParent(), FileLocator.class);
    }

    /**
     * @return the defaultTexture
     */
    public Texture2D getDefaultTexture() {
        return defaultTexture;
    }
    
    public void setDefaultTexture(File file) {
      gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
      this.defaultTexture = (Texture2D)gameManager.app.getAssetManager().loadTexture(file.getName()); 
      this.defaultFile = file.getName();
      gameManager.app.getAssetManager().unregisterLocator(file.getParent(), FileLocator.class);
      material.setTexture("ColorMap",defaultTexture);
    }

}
