package com.jpony.UI;

import com.jpony.GameManager;
import java.util.ArrayList;
import java.util.List;

public class UserInterfaceManager {
    
    private final GameManager            gameManager;

    private final List<UserInterface>    userInterface = new ArrayList<UserInterface>();
    
    public UserInterfaceManager(GameManager gameManager){
        this.gameManager = gameManager;
    }
    
    public UserInterface get(String name){
        for (UserInterface userInt : userInterface){
            if (userInt.getName().equals(name)){
                return userInt;
            }
        }
        return null;
    }
    
    public void add(UserInterface UI){
        userInterface.add(UI);
    }
    
    public void remove(UserInterface UI){
        int i = 0;
        for (UserInterface userInt : userInterface){
            if (userInt.getName().equals(UI.getName())){
                userInterface.remove(i);
                return;
            }
            i++;
        }
    }
    
    public void remove(String name){
        int i = 0;
        for (UserInterface userInt : userInterface){
            if (userInt.getName().equals(name)){
                userInterface.remove(i);
                return;
            }
            i++;
        }
    }
    
    public void show(UserInterface UI){
        
        for (UserInterface userInt : userInterface){
            if (userInt.getName().equals(UI.getName())){
                  gameManager.app.getStateManager().attach(userInt);
                  return;
            }
        }
    }
    
    public void hide(UserInterface UI){
        for (UserInterface userInt : userInterface){
            if (userInt.getName().equals(UI.getName())){
                  gameManager.app.getStateManager().detach(userInt);
                  return;
            }
        }
    }
    
    public void show(String name){
        
        for (UserInterface userInt : userInterface){
            if (userInt.getName().equals(name)){
                gameManager.app.getStateManager().attach(userInt);
                return;
            }
        }
    }
    
    public void hide(String name){
        for (UserInterface userInt : userInterface){
            if (userInt.getName().equals(name)){
                gameManager.app.getStateManager().detach(userInt);
                return;
            }
        }
    }
    
    public List getInterfaces(){
        return userInterface;
    }
    
    public void resize(){
        for (UserInterface UI : userInterface){
            UI.resize();
        }
    }
    
}
