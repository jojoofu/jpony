package com.jpony.UI;

import com.jpony.GameManager;
import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.math.Vector2f;
import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Label extends Control {
    
    private Vector2f                   borderBuffer = new Vector2f(2,2);
    private String                     text;
    private int                        fontSize;
    
    @Override
    public void construct(String name,GameManager gameManager){
        super.construct(name,gameManager);
        // create default font
        setFont(new Font(Font.SANS_SERIF, Font.PLAIN , 20));
        this.text = name;
    }
    
    @Override
    public void initialize(GameManager gameManager){
        super.initialize(gameManager);
        // create font
        setFont(new Font(Font.SANS_SERIF, Font.PLAIN , fontSize));
        // create graphics object
        createGraphics();
    }
    
    
    
    @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //TODO: load properties of this Control, e.g.
        this.text = in.readString("text","label");
        this.fontSize = in.readInt("fontSize",20);
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        //TODO: save properties of this Control, e.g.
        out.write(this.text, "text", "label");
        out.write(this.fontSize, "fontSize", 20);
    }
    
    @Override
    public void mouseEnter() {
        super.mouseEnter();
    }

    @Override
    public void mouseExit() {
       super.mouseExit();
    }

    @Override
    public void mouseDown() {
       super.mouseDown();
    }

    @Override
    public void mouseUp() {
       super.mouseUp();
    }
    
    private void createGraphics(){
     // create image
     image = new BufferedImage((int)getTrueSize().x, (int)getTrueSize().y,BufferedImage.TYPE_INT_ARGB);
     // create graphics object from image
     graphics = image.createGraphics();
     // make image transparent
     graphics.setBackground(new Color(0, 0, 0, 0));
     // draw string
     graphics.setColor(getColor());
     graphics.setFont(getFont());
    }

    private void drawString(){
     graphics.setColor(getFontColor());
     graphics.drawString(text,borderBuffer.x, ((getTrueSize().y / 2) + ((graphics.getFontMetrics(getFont()).getHeight() / 2) / 2) ));
    }
    
    public void scaleFont(){
        
        int fontHeight = 0;
        int imageHeight = (int)getTrueSize().y;
        int size = 1;
        boolean next = true;
        
        while (next){ 
           Font newFont = new Font(getFont().getFamily(), Font.PLAIN , size);
           fontHeight = graphics.getFontMetrics(newFont).getHeight();
           if (fontHeight > imageHeight){
               size--;
               fontSize = size;
               setFont(new Font(getFont().getFamily(), Font.PLAIN, size));
               graphics.setFont(getFont());
               next = false;
           }
           size++;
        }
        
    }

    public void draw(){
        createGraphics();
        drawString();
        setImage(image,true);
        graphics.dispose();
    }
    
    /**
     * @return the borderBuffer
     */
    public Vector2f getBorderBuffer() {
        return borderBuffer;
    }

    /**
     * @param borderBuffer the borderBuffer to set
     */
    public void setBorderBuffer(Vector2f borderBuffer) {
        this.borderBuffer = borderBuffer;
    }

    /**
     * @return the text
     */
    public String getText() {
        return text;
    }

    /**
     * @param text the text to set
     */
    public void setText(String text) {
     if (this.text.equals(text)){
         return;
     }   
     this.text = text;
     draw();
     
    }
    
    @Override
    public void setSize(int width , int height) {
        this.size.x = width;
        this.size.y = height;
        imageToScreen();
        scaleFont();
        draw();
    }
    
}
