package com.jpony.UI;

import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jpony.GameManager;
import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

public class DialogueBox extends Control{
    
    private String                    text;
    private ArrayList<String>         lines = new ArrayList();
    public int                        groups;
    private int                       linesPerBox;
    private int                       lineHeight;
    public int                        groupIndex = 0;
    
    @Override
    public void construct(String name,GameManager gameManager){
        super.construct(name,gameManager);
        // create default font
        setFont(new Font(Font.SANS_SERIF, Font.PLAIN , 20));
        this.text = name;
        lines.clear();
        lines.add(name);
        draw();
    }
    
    @Override
    public void initialize(GameManager gameManager){
        super.initialize(gameManager);
        setFont(new Font(Font.SANS_SERIF, Font.PLAIN , 20));
        text = getName();
        lines.clear();
        lines.add(text);
        draw();
    }
    
    @Override
    public void mouseEnter() {
        super.mouseEnter();
    }

    @Override
    public void mouseExit() {
       super.mouseExit();
    }

    @Override
    public void mouseDown() {
       super.mouseDown();
    }

    @Override
    public void mouseUp() {
       super.mouseUp();
    }
    
     @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //TODO: load properties of this Control, e.g.
        
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        //TODO: save properties of this Control, e.g.
        
    }
    
    public void draw(){
      createImage();
      getLinesPerBox();
      drawLines();
      // draw the border
      //graphics.drawRect(0, 0, (int)getTrueSize().x-1, (int)getTrueSize().y-1);
      graphics.dispose();
      setImage(image,true);
    }
    
    private void getLinesPerBox(){
       int height = (int)getTrueSize().y;
       lineHeight = graphics.getFontMetrics(getFont()).getHeight();
       linesPerBox = (int)(height / lineHeight);
    }
    
    private void drawLines(){
     
    splitTerminator();
    int startX = 5;
    int lineCount = 0;
    int startY = 0;
    int total = lines.size();
    float group = (float)lines.size() / (float)linesPerBox;
    if (group < 1){
      groups = 0;
    } else {
      groups = (int)Math.ceil(group);
    }
    //groups = (int)Math.ceil((float)lines.size() / (float)linesPerBox);
    int subtract = 0;
    if (groupIndex > 0){
        subtract = -1;
    }
    for (int i = groupIndex * (linesPerBox + subtract); i < total; i++){
        lineCount++;
        if (!(lineCount >= linesPerBox)){
          startY += lineHeight;
          graphics.drawString(lines.get(i), startX,startY); 
        } 
    }

    }
    
    private void createImage(){
     // create image
     image  = new BufferedImage((int)getTrueSize().x, (int)getTrueSize().y,BufferedImage.TYPE_INT_ARGB);
     // create graphics object from image
     graphics = image.createGraphics();
     // set the font
     graphics.setFont(getFont());
     // fill image with color
     graphics.setColor(getColor());
     // make image transparent
     graphics.setBackground(new Color(0, 0, 0, 0));
     // get the font color
     graphics.setColor(getFontColor());
     
    }
    
    private void splitTerminator(){
        
        lines.clear();
        String items[] = text.split("\\r?\\n");
        for (String next : items){
          getLines(next);
        } 
    }
    
    private void getLines(String line){

        String[] arr = line.split(" ");
        int index = 0;
        while ( index < arr.length )
    {
        String nextLine = arr[index++];
        while ((index < arr.length) && (graphics.getFontMetrics(getFont()).stringWidth(nextLine + " " + arr[index]) < (getTrueSize().x - 5)))
        {
            nextLine = nextLine + " " + arr[index];
            index++;
        }

        lines.add(nextLine);
  
    }
    
    }
    
    /**
     * @return The dialogue text.
     */
    public String getText() {
        return text;
    }

    /**
     * @param text Set the dialogue text.
     */
    public void setText(String text) {
        if (this.text.equals(text)){
         return;
        }   
        this.text = text;
        groupIndex = 0;
        draw();
    }


    
}
