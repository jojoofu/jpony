package com.jpony.UI;

import com.jpony.GameManager;
import com.jpony.input.Keys;
import com.jme3.asset.plugins.FileLocator;
import com.jme3.audio.AudioData;
import com.jme3.audio.AudioNode;
import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.material.Material;
import com.jme3.material.RenderState;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Geometry;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.texture.Texture2D;
import com.jme3.texture.plugins.AWTLoader;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The base class for GUI controls.
 * @author beer money
 */
public class Control extends AbstractControl {
    
    public GameManager                     gameManager;

    // image
    protected  AWTLoader                   imageLoader;
    protected BufferedImage                image;
    public  Graphics2D                     graphics;
    private File                           imageFile;
    protected Material                     material;
    
    // font
    private Font                           font;
    private Color                          fontColor = Color.BLACK;
    
    //general
    private String                         name;
    private boolean                        visible = true;
    private boolean                        selected = false;
    private Color                          color = Color.WHITE;
    private boolean                        resizable = false;
    
    // size and location settings
    protected Vector2f                     size = new Vector2f(100,100);
    private   Vector2f                     trueSize = new Vector2f(100,100);
    private   Vector2f                     location = new Vector2f(0,0);
    private   Vector2f                     trueLocation = new Vector2f(0,0);
    private   Vector2f                     scale = new Vector2f(1000,1000);
    
    // audio
    private AudioNode                      audioEnter = null;
    private AudioNode                      audioExit = null;
    private AudioNode                      audioClick = null;
    private String                         enterName = "null";
    private String                         exitName = "null";
    private String                         clickName = "null";
    //mouse
    private boolean                        enter = false;
    protected boolean                      mouseDown = false;
    private boolean                        mouseDrag = false;
    protected boolean                      mouseOver = false;
    private Vector2f                       lastLocation = new Vector2f(0,0);
    
    //used to skip first loop for mouse detection
    private boolean                        firstLoop = true;
    
    private final List                     listener = new ArrayList();
    
    // nodes
    private Control                        parent;
    private List<Control>                  children = new ArrayList<>();
    
    private float                          zOrder;
    
    private Boolean                        focus = false;
    
    /**
     * Creates references to our game manager and performs initial set up.
     * This must be called after our control is created.
     * @param name The name of the control
     * @param gameManager A reference to our game manager
     */
    public void construct(String name,GameManager gameManager){
        this.gameManager = gameManager;
        this.name = name;
        // draw a gray rectangle to the image
        createImage();
        // create a new material and add it to the spatial
        createMaterial();
        // set the new image to the material texture
        setImage(image,true);
    }
    
    /**
     * Creates references to our game manager and performs initial set up.
     * This must be called after the control is loaded from a file.
     * @param gameManager A reference to our game manager
     */
    public void initialize(GameManager gameManager){
        this.gameManager = gameManager;
        // set a reference to our spatials material
        Geometry temp = (Geometry)spatial;
        material = temp.getMaterial();
        //initialize awt loader
        imageLoader = new AWTLoader();
        // load and setup audio files
        if (!enterName.equals("null")){
         audioEnter = new AudioNode(gameManager.app.getAssetManager(),enterName,AudioData.DataType.Buffer);
         audioEnter.setPositional(false);   
        }
        if (!exitName.equals("null")){
         audioExit = new AudioNode(gameManager.app.getAssetManager(),exitName,AudioData.DataType.Buffer);
         audioExit.setPositional(false);  
        }
        if (!clickName.equals("null")){
         audioClick = new AudioNode(gameManager.app.getAssetManager(),clickName,AudioData.DataType.Buffer);
         audioClick.setPositional(false);  
        }
  
    }
    
    private void createImage(){
     //initialize awt loader
     imageLoader = new AWTLoader();
     // create image
     image  = new BufferedImage((int)getTrueSize().x, (int)getTrueSize().y,BufferedImage.TYPE_INT_ARGB);
     // create graphics object from image
     graphics = image.createGraphics();
     // set the font
     graphics.setFont(getFont());
     // fill image with color
     graphics.setColor(Color.GRAY);
     graphics.fillRect(0, 0, (int)getTrueSize().x, (int)getTrueSize().y);
     // dispose of graphics object
     graphics.dispose();
    }
    
    private void createMaterial(){
        material = new Material(gameManager.app.getAssetManager(),"Common/MatDefs/Misc/Unshaded.j3md");
        material.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);
        spatial.setMaterial(material);
    }
    
    @Override
    protected void controlUpdate(float tpf) {
        //TODO: add code that controls Spatial,
        //e.g. spatial.rotate(tpf,tpf,tpf);
        if (!isVisible() || !enabled){
            return;
        }
        if (firstLoop){
            firstLoop = false;
            return;
        }
        updateMouseState();
    }
    
    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        //Only needed for rendering-related operations,
        //not called when spatial is culled.
    }
    
    public com.jme3.scene.control.Control cloneForSpatial(Spatial spatial) {
        Control control = new Control();
        //TODO: copy parameters to new Control
        return control;
    }
    
    @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //TODO: load properties of this Control, e.g.
        //this.value = in.readFloat("name", defaultValue);
        this.size = (Vector2f)in.readSavable("size",new Vector2f(100,100));
        this.trueSize = (Vector2f)in.readSavable("trueSize",new Vector2f(100,100));
        this.location = (Vector2f)in.readSavable("location",new Vector2f(100,100));
        this.trueLocation = (Vector2f)in.readSavable("trueLocation",new Vector2f(100,100));
        this.mouseDrag = in.readBoolean("mouseDrag",false);
        this.resizable = in.readBoolean("resizable",false);
        this.selected = in.readBoolean("selected",false);
        this.name = in.readString("name","default");
        this.visible = in.readBoolean("visible",true);
        this.enterName = in.readString("enterName","null");
        this.exitName = in.readString("exitName","null");
        this.clickName = in.readString("clickName","null");
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        //TODO: save properties of this Control, e.g.
        out.write(this.size, "size", new Vector2f(100,100));
        out.write(this.trueSize, "trueSize", new Vector2f(100,100));
        out.write(this.location, "location", new Vector2f(100,100));
        out.write(this.trueLocation, "trueLocation", new Vector2f(100,100));
        out.write(this.mouseDrag, "mouseDrag",false);
        out.write(this.resizable, "resizable",false);
        out.write(this.selected, "selected",false);
        out.write(this.name, "name","default");
        out.write(this.visible,"visible",true);
        out.write(this.enterName, "enterName","null");
        out.write(this.exitName, "exitName","null");
        out.write(this.clickName, "clickName","null");
    }
    
    /**
     * Adds a control listener.
     * @param listener The listener
     */
    public synchronized void addListener(ControlListener listener) {
        this.listener.add(listener);
    }
    
    /**
     * Removes the controls listener.
     * @param listener The listener
     */
     public synchronized void removeListener(ControlListener listener) {
         this.listener.remove(listener);
     }

    private synchronized void fireMouseEnter(Control control) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((ControlListener)iterator.next()).mouseEnter(control);
        }
    }
    
    private synchronized void fireMouseExit(Control control) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((ControlListener)iterator.next()).mouseExit(control);
        }
    }
    
    private synchronized void fireMouseDown(Control control) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((ControlListener)iterator.next()).mouseDown(control);
        }
    }
    
    private synchronized void fireMouseUp(Control control) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((ControlListener)iterator.next()).mouseUp(control);
        }
    }
    
    private synchronized void fireControlResize(Control control) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((ControlListener)iterator.next()).controlResize(control);
        }
    }
    
    private synchronized void fireControlDrag(Control control) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((ControlListener)iterator.next()).controlDrag(control);
        }
    }
    
    private synchronized void fireMouseMove(Control control) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((ControlListener)iterator.next()).mouseMove(control);
        }
    }
    
    /**
     * Scales our image size to screen space.
     */
    private void sizeToScreen(){
        float width = ((float)getSize().x/scale.x) * gameManager.settings.getWidth();
        float height = ((float)getSize().y/scale.y) * gameManager.settings.getHeight();
        trueSize.x = (int)width;;
        trueSize.y = (int)height;
    }
    
    /**
     * Scales our image location to screen space.
     */
    private void locationToScreen(){
        float x = ((float)getLocation().x/scale.x) * gameManager.settings.getWidth();
        float y = ((float)getLocation().y/scale.y) * gameManager.settings.getHeight();
        trueLocation.x = (int)x;
        trueLocation.y = (int)y;
    }
    
    /**
     * Scales our screen space size to a percentage based scale.
     */
    private void locationToPercent(){
        float x = ((float)getTrueLocation().x * scale.x) / gameManager.settings.getWidth();
        float y = ((float)getTrueLocation().y * scale.y) / gameManager.settings.getHeight();
        location.x = (int)x;
        location.y =  (int)y;
    }
    
    /**
     * Scales our screen location to a percentage based scale.
     */
    private void sizeToPercent(){
        float width = ((float)trueSize.x * scale.x) / gameManager.settings.getWidth();
        float height = ((float)trueSize.y * scale.y) / gameManager.settings.getHeight();
        size.x = (int)width;
        size.y =  (int)height;
    }
    
    /**
     * Scales our image to screen space.
     */
    public void imageToScreen(){
        sizeToScreen();
        locationToScreen();
        updateQuad();
    }
    
    public void imageToPercent(){
        locationToPercent();
        sizeToPercent();
        updateQuad();
    }
    
    /**
     * Resizes the image to screen space. This should only be called
     * after adjustment is made to the screen resolution.
     */
    public void resize(){
      imageToScreen();
      if (spatial.getControl(Label.class) != null){
           Label label = (Label)this;
           label.setSize((int)this.size.x,(int)this.size.y); 
      }
    }
    
    /**
     * Updates the quads screen coordinates and size.
     */
    private void updateQuad(){
        spatial.setLocalScale(new Vector3f(trueSize.x, trueSize.y, 1f));
        spatial.setLocalTranslation(trueLocation.x,trueLocation.y,getSpatial().getLocalTranslation().z);  
    }
    
    /**
     * Set the controls image.
     * @param bufferedImage The image to set
     * @param flipY Flip the images coordinates.
     */
    protected void setImage(BufferedImage bufferedImage,boolean flipY){
      material.setTexture("ColorMap", new Texture2D(imageLoader.load(bufferedImage, flipY)));
      material.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha); 
    }
    
    /**
     * Determines if the mouse is over the control.
     * @return True if the mouse is over the control otherwise returs false;
     */
    private boolean mouseOver() {
       
    int x = (int) gameManager.app.getInputManager().getCursorPosition().x;
    int y = (int) gameManager.app.getInputManager().getCursorPosition().y;
    
    Rectangle mouse = new Rectangle(x, y, 1, 1);
    Rectangle control = new Rectangle((int)trueLocation.x,(int)trueLocation.y,(int)trueSize.x,(int)trueSize.y);
    
    mouseOver = mouse.intersects(control);
    return mouseOver;
        
    }
    
    /**
     * Drags the control along the screen with the mouse.
     */
    protected void mouseDrag(){
        
        if (isMouseDrag() && isMouseDown() && isSelected() ){
            int x = (int)gameManager.app.getInputManager().getCursorPosition().x - (int)lastLocation.x;
            int y = (int) gameManager.app.getInputManager().getCursorPosition().y - (int)lastLocation.y;
            lastLocation.x = (int) gameManager.app.getInputManager().getCursorPosition().x;
            lastLocation.y = (int) gameManager.app.getInputManager().getCursorPosition().y;
            trueLocation.x += x;
            trueLocation.y += y;
            
            getSpatial().setLocalTranslation(trueLocation.x,trueLocation.y,getSpatial().getLocalTranslation().z);
            locationToPercent();
            moveChildren(x,y);
            controlDrag();
            fireControlDrag(this);
        }
    }
    
    /**
     * Resizes the control by dragging the mouse
     * @return True the control is selected and mouseResize is set to true.
     */
    private boolean mouseResize(){
        
        if (isResizable() && isMouseDown() && isSelected() ){

            int x = (int)gameManager.app.getInputManager().getCursorPosition().x - (int)lastLocation.x;
            int y = (int)gameManager.app.getInputManager().getCursorPosition().y - (int)lastLocation.y;
            lastLocation.x = (int) gameManager.app.getInputManager().getCursorPosition().x;
            lastLocation.y = (int) gameManager.app.getInputManager().getCursorPosition().y;
            trueSize.x += x;
            trueSize.y += y;
            if (!(trueSize.x < 1) && !(trueSize.y < 1)){
                spatial.setLocalScale(trueSize.x, trueSize.y, 1f);
                sizeToPercent(); 
            } else {
                trueSize.x = 1;
                trueSize.y = 1;
                sizeToPercent(); 
            }
            
            controlResize();
            fireControlResize(this);
            return true;
        }
       
        return false;
    }
    
    /**
     * Moves the children of the parent control
     * @param x The mouse X coordinate
     * @param y The mouse Y coordinate
     */
    private void moveChildren(int x , int y){
        
        for (Control child : getChildren()){
            child.trueLocation.x += x;
            child.trueLocation.y += y;
            child.getSpatial().setLocalTranslation(child.trueLocation.x,child.trueLocation.y,child.getSpatial().getLocalTranslation().z);
            child.locationToPercent();
            child.moveChildren(x, y);
        }
        
    }
    
    public void mouseMove(){
        
    }
    
    /**
     * Update the mouse state to determine if the mouse is inside
     * the control area , it can be dragged or resized.
     */
    private void updateMouseState(){
    // mouse is inside the control area
    setEnter(mouseOver());
    if (mouseOver){
       fireMouseMove(this);
       mouseMove();
    }
    if (isEnter()){
        setMouseDown(gameManager.inputManager.key(Keys.MOUSE_BUTTON_LEFT).triggered);
    }
    if (!mouseResize()){
       mouseDrag();
    }
    
    }

    public void mouseEnter() {
        if (audioEnter != null){
            audioEnter.playInstance();
        }
    }

    public void mouseExit() {
        if (audioExit != null){
            audioExit.playInstance();
        }
    }

    public void mouseDown() {
        if (audioClick != null){
            audioClick.playInstance();
        }
        // Set the last location of the mouse after click
        lastLocation.x = (int) gameManager.app.getInputManager().getCursorPosition().x;
        lastLocation.y = (int) gameManager.app.getInputManager().getCursorPosition().y;
    }

    public void mouseUp() {

    }
    
    public void controlResize() {
        
    }
    
    public void controlDrag() {
        
    }
    
    /**
     * Adds a child control. The child control will follow the movements
     * of the parent control.
     * @param control The control to be added.
     */
    public void attachChild(Control control){
        control.setParent(this);
        this.getChildren().add(control);
    }
    
    /**
     * Removes the control from the parents child list.
     */
    public void removeFromParent(){

        for (Control child : parent.getChildren()){
            if (child.name.equals(this.name)){
                parent.getChildren().remove(child);
                return;
            }
        }
        
    }
    
    /**
     * @return The name of the control
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        spatial.setName(name);
        this.name = name;
    }

    /**
     * @return The default font color
     */
    public Color getFontColor() {
        return fontColor;
    }

    /**
     * @param fontColor the fontColor to set
     */
    public void setFontColor(Color fontColor) {
        this.fontColor = fontColor;
    }

    /**
     * @return The actual size of the image in screen coordinates
     */
    public Vector2f getTrueSize() {
        return trueSize;
    }

    /**
     * @param trueSize Set the image size in screen coordinates
     */
    public void setTrueSize(Vector2f trueSize) {
        this.trueSize = trueSize;
        sizeToPercent();
        imageToScreen();
    }

    /**
     * @return the font
     */
    public Font getFont() {
        return font;
    }

    /**
     * @param font the font to set
     */
    public void setFont(Font font) {
        this.font = font;
    }

    /**
     * @return The percentage based size
     */
    public Vector2f getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(Vector2f size) {
        this.size = size;
        imageToScreen();
    }
    
    public void setSize(int width , int height) {
        this.size.x = width;
        this.size.y = height;
        imageToScreen();
    }
    
    /**
     * @return The percentage based location
     */
    public Vector2f getLocation() {
        return location;
    }

    /**
     * @param location the location to set
     */
    public void setLocation(Vector2f location) {
        this.location = location;
        imageToScreen();
    }
    
    public void setLocation(int x , int y) {
        this.location.x = x;
        this.location.y = y;
        imageToScreen();
    }
    
    /**
     * @return The controls location in screen space.
     */
    public Vector2f getTrueLocation() {
        return trueLocation;
    }

    /**
     * Sets the controls location in screen space.
     * @param trueLocation The controls location in screen space.
     */
    public void setTrueLocation(Vector2f trueLocation) {
        this.trueLocation = trueLocation;
        locationToPercent();
        imageToScreen();
    }

    /**
     * @return The controls scale in percentages.
     */
    public Vector2f getScale() {
        return scale;
    }

    /**
     * @param scale Set the controls scale in percentages.
     */
    public void setScale(Vector2f scale) {
        this.scale = scale;
    }

    /**
     * @return Is the control visible.
     */
    public boolean isVisible() {
        return visible;
    }

    /**
     * @param visible Is the control visible
     */
    public void setVisible(boolean visible) {
        this.visible = visible;
        if (visible){
            getSpatial().setCullHint(Spatial.CullHint.Never);
        } else {
            getSpatial().setCullHint(Spatial.CullHint.Always); 
        }
    }

    /**
     * @return the image
     */
    public BufferedImage getImage() {
        return image;
    }

    /**
     * @return Has the mouse entered the control area
     */
    private boolean isEnter() {
        return enter;
    }

    /**
     * Determine if the mouse is inside the control then fire mouse events.
     * @param enter Is the mouse inside the control.
     */
    private void setEnter(boolean enter) {
        if (enter && enter != this.enter){
            fireMouseEnter(this);
            mouseEnter();
        } else if (!enter && enter != this.enter){
            fireMouseExit(this);
            mouseExit();
        }
        this.enter = enter;
    }

    /**
     * @return Is the mouse button down
     */
    public boolean isMouseDown() {
        return mouseDown;
    }

    /**
     * Set the mouse button down state then fires the mouse events.
     * @param mouseDown Is the mouse button down.
     */
    private void setMouseDown(boolean mouseDown) {
        if (mouseDown && mouseDown != this.mouseDown){
            fireMouseDown(this);
            mouseDown();
        } else if (!mouseDown && mouseDown != this.mouseDown){
            fireMouseUp(this);
            mouseUp();
        }
        this.mouseDown = mouseDown;
    }

    /**
     * @return The audio enter node
     */
    public AudioNode getAudioEnter() {
        return audioEnter;
    }

    /**
     * Loads an audio file into the audio enter node.
     * @param file The file to load
     */
    public void setAudioEnter(File file) {
        gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
        audioEnter = new AudioNode(gameManager.app.getAssetManager(),file.getName(),AudioData.DataType.Buffer);
        audioEnter.setPositional(false);
        enterName = file.getName();
        gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
    }
    
    /**
     * Sets the audio enter node
     * @param audio The audio node
     */
    public void setAudioEnter(AudioNode audio) {
        audioEnter = audio;
    }
    
    /**
     * @return The audio exit node
     */
    public AudioNode getAudioExit() {
        return audioExit;
    }
    
    /**
     * Loads an audio file into the audio exit node.
     * @param file The file to load
     */
    public void setAudioExit(File file) {
        gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
        audioExit = new AudioNode(gameManager.app.getAssetManager(),file.getName(),AudioData.DataType.Buffer);
        audioExit.setPositional(false);
        exitName = file.getName();
        gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
    }
    
    /**
     * Sets the audio exit node
     * @param audio The audio node
     */
    public void setAudioExit(AudioNode audio) {
        audioExit = audio;
    }
    
    /**
     * @return Returns the on click audio node
     */
    public AudioNode getAudioClick() {
        return audioClick;
    }
    
    /**
     * Loads an audio file into the audio click node.
     * @param file The file to load
     */
    public void setAudioClick(File file) {
        gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
        audioClick = new AudioNode(gameManager.app.getAssetManager(),file.getName(),AudioData.DataType.Buffer);
        audioClick.setPositional(false);
        clickName = file.getName();
        gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
    }
    
    /**
     * Sets the audio click node
     * @param audio The audio node
     */
    public void setAudioClick(AudioNode audio) {
        audioClick = audio;
    }
    
    /**
     * @return Can you drag the control with the mouse.
     */
    public boolean isMouseDrag() {
        return mouseDrag;
    }

    /**
     * @param mouseDrag Can the control be dragged with the mouse.
     */
    public void setMouseDrag(boolean mouseDrag) {
        this.mouseDrag = mouseDrag;
    }

    /**
     * @return Is the control selected
     */
    public boolean isSelected() {
        return selected;
    }

    /**
     * @param selected the selected to set
     */
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    /**
     * @return The parent control
     */
    public Control getParent() {
        return parent;
    }

    /**
     * @param parent Sets the parent control
     */
    public void setParent(Control parent) {
        this.parent = parent;
    }

    /**
     * @return the zOrder
     */
    public float getzOrder() {
        return zOrder;
    }

    /**
     * @param zOrder The zOrder deterines the order in which the controls are draw.
     * Controls with a higher zOrder are drawn on top of other controls.
     * Set anywhere from 0 - 0.99 do not set at 1 or above.
     */
    public void setzOrder(float zOrder) {
        getSpatial().setLocalTranslation(spatial.getLocalTranslation().x, spatial.getLocalTranslation().y, zOrder);
        this.zOrder = zOrder;
    }

    /**
     * @return Is the mouse over the control
     */
    public boolean isMouseOver() {
        return mouseOver;
    }

    /**
     * @return The default back ground color
     */
    public Color getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * @return Can the control be resized with the mouse
     */
    public boolean isResizable() {
        return resizable;
    }

    /**
     * @param resizable the resizable to set
     */
    public void setResizable(boolean resizable) {
        this.resizable = resizable;
    }

    /**
     * @return The controls children.
     */
    public List<Control> getChildren() {
        return children;
    }

    /**
     * @param children Set the controls children.
     */
    public void setChildren(List<Control> children) {
        this.children = children;
    }

    /**
     * @return Is the control focused
     */
    public Boolean getFocus() {
        return focus;
    }

    /**
     * @param focus True if the control has focus
     */
    public void setFocus(Boolean focus) {
        this.focus = focus;
    }

    

}
