package com.jpony.UI;

public interface ControlListener {
    
    public void mouseEnter(Control control);
    
    public void mouseExit(Control control);
    
    public void mouseDown(Control control);
    
    public void mouseUp(Control control);
    
    public void controlResize(Control control);
    
    public void controlDrag(Control control);
    
    public void mouseMove(Control control);
    
}
