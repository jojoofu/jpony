package com.jpony.UI.common;

/**
 * The dialogue control listener.
 * @author beer money
 */
public interface DialogueListener {
    
    public void buttonNext();
    
    public void buttonPrevious();
    
    public void buttonClose();
    
}
