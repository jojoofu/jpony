package com.jpony.UI.common;

import com.jpony.GameManager;
import com.jpony.UI.Control;
import com.jpony.UI.ControlListener;
import com.jpony.UI.DialogueBox;
import com.jpony.UI.UserInterface;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A basic dailogue box.
 * @author beer money
 */
public class DialogueControl implements ControlListener{
    
    private final GameManager            gameManager;
    public UserInterface                 UI;
    
    private String                       path = System.getProperty("user.dir");
    private final List                   listener = new ArrayList();
    
    private String                       text;
    
    public DialogueControl(GameManager gameManager){
        this.gameManager = gameManager;
        initialize();
    }
    
    private void initialize(){
     UI = new UserInterface("dialogue",gameManager);
     File file = new File(path + "/assets/Interface/common/dialogue.j3o");
     UI.load(file);
     UI.addListener(this);
     UI.getControl("background").setEnabled(true);
     UI.getControl("background").setMouseDrag(true);
     UI.getControl("text").setMouseDrag(false);
     UI.getControl("background").attachChild(UI.getControl("portrait"));
     UI.getControl("background").attachChild(UI.getControl("text"));
     UI.getControl("background").attachChild(UI.getControl("previous"));
     UI.getControl("background").attachChild(UI.getControl("next"));
     UI.getControl("background").attachChild(UI.getControl("close"));
     UI.getControl("next").setzOrder(0.1f);
     UI.getControl("previous").setzOrder(0.1f);
     UI.getControl("close").setzOrder(0.1f);
     gameManager.UImanager.add(UI);
    }
    
     /**
     * Adds a dialogue listener.
     * @param listener The listener to add.
     */
    public synchronized void addListener(DialogueListener listener) {
        this.listener.add(listener);
    }
    
    /**
     * Removes a dialogue listener.
     * @param listener The listener to remove.
     */
    public synchronized void removeListener(DialogueListener listener) {
        this.listener.remove(listener);
    }

    private synchronized void fireNext() {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((DialogueListener)iterator.next()).buttonNext();
        }
    }
    
    private synchronized void firePrevious() {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((DialogueListener)iterator.next()).buttonPrevious();
        }
    }
    
    private synchronized void fireClose() {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((DialogueListener)iterator.next()).buttonClose();
        }
    }
    
    public void buttonNext() {
        UI.getControl("text",DialogueBox.class).groupIndex++;
        if (UI.getControl("text",DialogueBox.class).groupIndex > UI.getControl("text",DialogueBox.class).groups){
            UI.getControl("text",DialogueBox.class).groupIndex--;
        }
        UI.getControl("text",DialogueBox.class).draw();
    }

    public void buttonPrevious() {
        UI.getControl("text",DialogueBox.class).groupIndex--;
        if (UI.getControl("text",DialogueBox.class).groupIndex < 0){
            UI.getControl("text",DialogueBox.class).groupIndex++;
        }
        UI.getControl("text",DialogueBox.class).draw();
    }

    public void buttonClose() {
        UI.setDisplayed(false);
    }

    @Override
    public void mouseEnter(Control control) {
       
    }

    @Override
    public void mouseExit(Control control) {
       
    }

    @Override
    public void mouseDown(Control control) {
        if (control.getName().equals("next")){
            buttonNext();
            fireNext();
       } else if (control.getName().equals("previous")){
           buttonPrevious();
           firePrevious();
       } else if (control.getName().equals("close")){
           buttonClose();
           fireClose();
       }
    }

    @Override
    public void mouseUp(Control control) {
        
    }

    @Override
    public void controlResize(Control control) {
        
    }

    @Override
    public void controlDrag(Control control) {
        
    }

    /**
     * @return the text
     */
    public String getText() {
        text = UI.getControl("text",DialogueBox.class).getText();
        return text;
    }

    /**
     * @param text the text to set
     */
    public void setText(String text) {
        this.text = text;
        UI.getControl("text",DialogueBox.class).setText(text);
    }

    @Override
    public void mouseMove(Control control) {
       
    }
    
}
