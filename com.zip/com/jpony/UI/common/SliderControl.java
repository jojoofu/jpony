package com.jpony.UI.common;

import com.jme3.math.Vector2f;
import com.jpony.GameManager;
import static com.jpony.input.Keys.*;
import com.jpony.UI.Control;
import com.jpony.UI.ControlListener;
import com.jpony.UI.UserInterface;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author beer money
 */
public class SliderControl implements ControlListener {
    
    private final GameManager            gameManager;
    public UserInterface                 UI;
    
    private String                       path = System.getProperty("user.dir");
    private final List                   listener = new ArrayList();
    
    private String                       text;
    private String                       name;
    private Vector2f                     location = new Vector2f(0,0);
    
    private boolean                      buttonDown = false;
    private int                          leftBounds;
    private int                          rightBounds;
    private int                          upperBounds;
    private int                          lowerBounds;
    
    public SliderControl(GameManager gameManager,String name){
        this.gameManager = gameManager;
        this.name = name;
        initialize(name);
    }
    
    private void initialize(String name){
     UI = new UserInterface(name,gameManager);
     File file = new File(path + "/assets/Interface/common/slider.j3o");
     UI.load(file);
     UI.addListener(this);
     UI.getControl("bar").setEnabled(false);
     UI.getControl("bar").setMouseDrag(false);
     UI.getControl("bar").attachChild(UI.getControl("button"));
     UI.getControl("button").setzOrder(0.1f);
     gameManager.UImanager.add(UI);
    }
    
    private void updateButton(int mouseX){
       mouseX -= UI.getControl("button").getTrueSize().x /2;
       location.set(mouseX, UI.getControl("button").getTrueLocation().y);
       UI.getControl("button").setTrueLocation(location);    
    }
    
    @Override
    public void mouseEnter(Control control) {
       if (control.getName().equals("bar")){
           leftBounds = (int)control.getTrueLocation().x;
           rightBounds = (int)(control.getTrueLocation().x + control.getTrueSize().x);
       } 
       if (control.getName().equals("button")){
           upperBounds = (int)control.getTrueLocation().y;
           lowerBounds = (int)(control.getTrueLocation().y + control.getTrueSize().y);
       }
    }

    @Override
    public void mouseExit(Control control) {
      
    }

    @Override
    public void mouseDown(Control control) {
       
    }

    @Override
    public void mouseUp(Control control) {
      
    }

    @Override
    public void controlResize(Control control) {
     
    }

    @Override
    public void controlDrag(Control control) {
       
    }
    
    @Override
    public void mouseMove(Control control) {
       int x = (int)gameManager.app.getInputManager().getCursorPosition().x;
       int y = (int)gameManager.app.getInputManager().getCursorPosition().y;
       if (control.isMouseDown() && (y > upperBounds) && (y < lowerBounds) && (x > leftBounds) && (x < rightBounds)){
               updateButton(x); 
       }
    }
    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    
}
