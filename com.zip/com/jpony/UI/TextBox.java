package com.jpony.UI;

import com.jpony.GameManager;
import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.input.KeyInput;
import com.jme3.input.RawInputListener;
import com.jme3.input.event.JoyAxisEvent;
import com.jme3.input.event.JoyButtonEvent;
import com.jme3.input.event.KeyInputEvent;
import com.jme3.input.event.MouseButtonEvent;
import com.jme3.input.event.MouseMotionEvent;
import com.jme3.input.event.TouchEvent;
import com.jme3.math.Vector2f;
import com.jpony.Timer;
import com.jpony.TimerListener;
import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Scanner;

public class TextBox extends Control implements RawInputListener , TimerListener {
    
    private Vector2f                   borderBuffer = new Vector2f(2,2);
    private String                     text;
    private int                        fontSize;
    private Scanner                    scan = new Scanner(System.in);
    private Timer                      timer;
    private boolean                    drawLine = false;
    
    @Override
    public void construct(String name,GameManager gameManager){
        super.construct(name,gameManager);
        // create default font
        setFont(new Font(Font.SANS_SERIF, Font.PLAIN , 20));
        this.text = name;  
        gameManager.app.getInputManager().addRawInputListener(this);
        timer = new Timer(name,0.2f);
        timer.addListener(this);
        timer.start();
        gameManager.timerManager.add(timer);
    }
    
    @Override
    public void initialize(GameManager gameManager){
        super.initialize(gameManager);
        // create font
        setFont(new Font(Font.SANS_SERIF, Font.PLAIN , fontSize));
        // create graphics object
        createGraphics(); 
        gameManager.app.getInputManager().addRawInputListener(this);
        timer = new Timer(getName(),0.2f);
        timer.addListener(this);
        timer.start();
        gameManager.timerManager.add(timer);
    }
    
    @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //TODO: load properties of this Control, e.g.
        this.text = in.readString("text","textBox");
        this.fontSize = in.readInt("fontSize",20);
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        //TODO: save properties of this Control, e.g.
        out.write(this.text, "text", "textBox");
        out.write(this.fontSize, "fontSize", 20);
    }
    
    @Override
    public void mouseEnter() {
        super.mouseEnter();
    }

    @Override
    public void mouseExit() {
       super.mouseExit();
    }

    @Override
    public void mouseDown() {
       super.mouseDown();
       setFocus(true);
    }

    @Override
    public void mouseUp() {
       super.mouseUp();
    }
    
    private void createGraphics(){
     // create image
     image = new BufferedImage((int)getTrueSize().x, (int)getTrueSize().y,BufferedImage.TYPE_INT_ARGB);
     // create graphics object from image
     graphics = image.createGraphics();
     // make image transparent
     graphics.setBackground(new Color(0, 0, 0, 0));
     // draw string
     graphics.setColor(getColor());
     graphics.setFont(getFont());
    }

    private void drawString(){
     graphics.setColor(getFontColor());
     graphics.drawString(text,borderBuffer.x, ((getTrueSize().y / 2) + ((graphics.getFontMetrics(getFont()).getHeight() / 2) / 2) ));
     if (drawLine){
      int width = graphics.getFontMetrics().stringWidth(text);
      int height = graphics.getFontMetrics(getFont()).getHeight();
      graphics.drawLine(width, height - 2, width + 15, height - 2);
     }
    }
    
    public void scaleFont(){
        
        int fontHeight = 0;
        int imageHeight = (int)getTrueSize().y;
        int size = 1;
        boolean next = true;
        
        while (next){ 
           Font newFont = new Font(getFont().getFamily(), Font.PLAIN , size);
           fontHeight = graphics.getFontMetrics(newFont).getHeight();
           if (fontHeight > imageHeight){
               size--;
               fontSize = size;
               setFont(new Font(getFont().getFamily(), Font.PLAIN, size));
               graphics.setFont(getFont());
               next = false;
           }
           size++;
        }
        
    }

    public void draw(){
        createGraphics();
        drawString();
        setImage(image,true);
        graphics.dispose();
    }
    
    /**
     * @return the borderBuffer
     */
    public Vector2f getBorderBuffer() {
        return borderBuffer;
    }

    /**
     * @param borderBuffer the borderBuffer to set
     */
    public void setBorderBuffer(Vector2f borderBuffer) {
        this.borderBuffer = borderBuffer;
    }

    /**
     * @return the text
     */
    public String getText() {
        return text;
    }

    /**
     * @param text the text to set
     */
    public void setText(String text) {
     if (this.text.equals(text)){
         return;
     }   
     this.text = text;
     draw();
     
    }
    
    @Override
    public void setSize(int width , int height) {
        this.size.x = width;
        this.size.y = height;
        imageToScreen();
        scaleFont();
        draw();
    }

    @Override
    public void beginInput() {
        
    }

    @Override
    public void endInput() {
       
    }

    @Override
    public void onJoyAxisEvent(JoyAxisEvent evt) {
        
    }

    @Override
    public void onJoyButtonEvent(JoyButtonEvent evt) {
       
    }

    @Override
    public void onMouseMotionEvent(MouseMotionEvent evt) {
       
    }

    @Override
    public void onMouseButtonEvent(MouseButtonEvent evt) {
      
    }

    @Override
    public void onKeyEvent(KeyInputEvent evt) {
       if (!enabled){
           return;
       }
       if (getFocus()){
           if (evt.getKeyCode() == KeyInput.KEY_BACK){
               if (text.length() == 0){
                   return;
               }
               text = text.substring(0,text.length()-1);
               draw();
           } else {
               text += evt.getKeyChar();
               draw();
           }
       }
    }

    @Override
    public void onTouchEvent(TouchEvent evt) {
        
    }

    @Override
    public void tick() {
       drawLine = !drawLine;
       if (getFocus()){
        draw();   
       }
       
    }

    

}
