package com.jpony.UI;

public class ControlType {
    
    public static final int               BUTTON = 1;
    public static final int               IMAGE = 2;
    public static final int               TEXTBOX = 3;
    public static final int               TEXTBUTTON = 4;
    public static final int               LABEL = 5;
    public static final int               WINDOW = 6;
    public static final int               SLIDER = 7;
    
}
