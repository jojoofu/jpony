package com.jpony.UI;

import com.jpony.GameManager;
import com.jme3.asset.plugins.FileLocator;
import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.texture.Texture2D;
import java.io.File;
import java.io.IOException;

public class Image extends Control {
    
    private String             textureName;
    private Texture2D          texture;
    
    @Override
    public void construct(String name,GameManager gameManager){
        super.construct(name,gameManager);
    }
    
    @Override
    public void initialize(GameManager gameManager){
        super.initialize(gameManager);
        this.texture = (Texture2D)gameManager.app.getAssetManager().loadTexture(textureName); 
        material.setTexture("ColorMap",texture);
    }
    
    @Override
    public void mouseEnter() {
        super.mouseEnter();
    }

    @Override
    public void mouseExit() {
       super.mouseExit();
    }

    @Override
    public void mouseDown() {
       super.mouseDown();
    }

    @Override
    public void mouseUp() {
       super.mouseUp();
    }
    
     @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //TODO: load properties of this Control, e.g.
        this.textureName = in.readString("textureName","jmonkey.png");
       
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        //TODO: save properties of this Control, e.g.
        out.write(this.textureName, "textureName", "jmonkey.png");
        
    }
    
    public void setTexture(File file){
      gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
      this.texture = (Texture2D)gameManager.app.getAssetManager().loadTexture(file.getName()); 
      material.setTexture("ColorMap",texture);
      this.textureName = file.getName();
      gameManager.app.getAssetManager().unregisterLocator(file.getParent(), FileLocator.class);
    }

}
