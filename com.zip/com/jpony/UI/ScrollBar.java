package com.jpony.UI;

import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jpony.GameManager;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class ScrollBar extends Control {

    private Color                 backColor = Color.WHITE;
    private Color                 endBarColor = Color.GRAY;
    private Color                 barColor = Color.DARK_GRAY;
    
    @Override
    public void construct(String name,GameManager gameManager){
        super.construct(name,gameManager);
        draw();
    }
    
    @Override
    public void initialize(GameManager gameManager){
        super.initialize(gameManager);
        draw();
    }
    
    @Override
    public void mouseEnter() {
        super.mouseEnter();
    }

    @Override
    public void mouseExit() {
       super.mouseExit();
    }

    @Override
    public void mouseDown() {
       super.mouseDown();
    }

    @Override
    public void mouseUp() {
       super.mouseUp();
    }
    
     @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //this.hoverFile = in.readString("hoverFile","orangebutton.png");
        
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        //out.write(this.hoverFile, "hoverFile", "orangebutton.png");
    }
    
    @Override
    protected void controlUpdate(float tpf) {
        super.controlUpdate(tpf);
        if (mouseDown){
            
        }
    }
    
    private void createGraphics(){
     // create image
     image = new BufferedImage((int)getTrueSize().x, (int)getTrueSize().y,BufferedImage.TYPE_INT_ARGB);
     // create graphics object from image
     graphics = image.createGraphics();
    }
    
    private void drawScrollBox(){
     // draw back ground
     graphics.setColor(backColor);
     graphics.fillRect(0, 0, (int)getTrueSize().x, (int)getTrueSize().y);
    }
    
    private void drawEndBars(){
     // draw left bar
     graphics.setColor(endBarColor);
     int x = (int)((float)getTrueSize().x * 0.1f);
     int y = (int)getTrueSize().y;
     graphics.fillRect(0,0,x,y);  
     // draw right bar
     graphics.fillRect((int)getTrueSize().x - x,0,x,y); 
    }
    
    /**
     * Draws the control.
     */
    public void draw(){
        createGraphics();
        drawScrollBox();
        drawEndBars();
        setImage(image,true);
        graphics.dispose();
    }
    
    @Override
    public void setSize(int width , int height) {
        this.size.x = width;
        this.size.y = height;
        imageToScreen();
        draw();
    }
    
}
