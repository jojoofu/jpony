package com.jpony.UI;

import com.jpony.GameManager;
import com.jpony.input.Keys;
import com.jme3.app.Application;
import com.jme3.app.state.AbstractAppState;
import com.jme3.app.state.AppStateManager;
import com.jme3.asset.plugins.FileLocator;
import com.jme3.export.binary.BinaryExporter;
import com.jme3.material.Material;
import com.jme3.math.Vector2f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Quad;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The user interface class represent a 2D GUI. Each instance of this class
 * should be used for each unique GUI.
 * @author beer money
 */
public class UserInterface extends AbstractAppState {
  
    private final GameManager              gameManager;
    private String                         name;
    private final List<Control>            controls = new ArrayList<>();
    
    public Control                         selection;
    public Node                            node;
    private boolean                        displayed = false;
    
    public UserInterface(String name,GameManager gameManager){
        
        this.gameManager = gameManager;
        this.name = name;
        node = new Node(name);
        
    }
    
    @Override
    public void initialize(AppStateManager stateManager, Application app) {
        super.initialize(stateManager, app);
    }
    
    /**
     * Updates the interface. This hooks into the main JME loop.
     * @param tpf The Time Per Frame
     */
    @Override
    public void update(float tpf) {
        super.update(tpf);
        select();
    }
    
    /**
     * Clean up the interface once we are done using it.
     */
    @Override
    public void cleanup() {
        super.cleanup();    
    }
    
    /**
     * Clear all elements in the interface.
     */
    public void clear(){
        controls.clear();
        node.detachAllChildren();
    }
    
    /**
     * Creates a label and adds it to the interface.
     * @param name The name of the label
     */
    public void createLabel(String name){
      Spatial spatial = new Geometry(name, new Quad(1,1));
      Material material = new Material(gameManager.app.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
      spatial.setMaterial(material);
      Label label = new Label();
      spatial.addControl(label);
      label.construct(name,gameManager);
      label.setSize(150,50); 
      label.setLocation(new Vector2f(450,450));
      label.setText(name);
      add(spatial);
    }
    
    /**
     * Creates a new text box and adds it to the interface.
     * @param name The name of the text box.
     */
    public void createTextBox(String name){
      Spatial spatial = new Geometry(name, new Quad(1,1));
      Material material = new Material(gameManager.app.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
      spatial.setMaterial(material);
      TextBox textBox = new TextBox();
      spatial.addControl(textBox);
      textBox.construct(name,gameManager);
      textBox.setSize(150,50); 
      textBox.setLocation(new Vector2f(450,450));
      textBox.setText(name);
      add(spatial);
    }
    
    /**
     * Creates a new image and adds it to the user interface.
     * @param name The name of the image.
     * @param imageFile The image file.
     */
    public void createImage(String name,File imageFile){
      Spatial spatial = new Geometry(name, new Quad(1,1));
      Material material = new Material(gameManager.app.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
      spatial.setMaterial(material);
      Image image = new Image();
      spatial.addControl(image);
      image.construct(name,gameManager);
      image.setSize(100,100); 
      image.setLocation(new Vector2f(450,450));
      image.setTexture(imageFile);
      add(spatial);
    }
    
    public void createButton(String name,File hover,File pressed,File Default){
      Spatial spatial = new Geometry(name, new Quad(1,1));
      Material material = new Material(gameManager.app.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
      spatial.setMaterial(material);
      Button button = new Button();
      spatial.addControl(button);
      button.construct(name,gameManager);
      button.setSize(100,100); 
      button.setLocation(new Vector2f(450,450));
      button.setHoverTexture(hover);
      button.setPressedTexture(pressed);
      button.setDefaultTexture(Default);
      add(spatial);
    }
    
    /**
     * Creates a new dialogue box and adds it to the interface.
     * @param name The name of the dialogue box.
     */
    public void createDialogueBox(String name){
      Spatial spatial = new Geometry(name, new Quad(1,1));
      Material material = new Material(gameManager.app.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
      spatial.setMaterial(material);
      DialogueBox dialogueBox = new DialogueBox();
      spatial.addControl(dialogueBox);
      dialogueBox.construct(name,gameManager);
      dialogueBox.setLocation(new Vector2f(450,450));
      dialogueBox.setText(name);
      add(spatial);
    }
    
    /**
     * Changes the font color for all labels in the interface.
     * @param color The new color.
     */
    public void setFontColor(Color color){
        for (Control control : getControls()){
            control.setFontColor(color);
            if (control.getSpatial().getControl(Label.class) != null){
               Label label = (Label)control;
               label.draw();
            }
        }
    }
    
    /**
     * Removes the specified element from the interface.
     * @param name The name of the element to remove.
     */
    public void remove(String name){
            
        int length = controls.size();
        
        for (int i=0;i < length;i++){
            if (controls.get(i).getName().equals(name)){
                controls.remove(i);
                node.getChild(name).removeFromParent();
                return;
            }
        }
        
    }
    
    /**
     * Adds a new spatial to the control interface. The spatial must be an
     * instance of Quad and have a GUI control attached.
     * @param spatial The spatial to attach.
     */
    public void add(Spatial spatial){
        if (spatial.getControl(Image.class) != null){
              node.attachChild(spatial);
              getControls().add(spatial.getControl(Image.class));
          } else if (spatial.getControl(Button.class) != null){
              node.attachChild(spatial);
              getControls().add(spatial.getControl(Button.class));
          } else if (spatial.getControl(Label.class) != null){
              node.attachChild(spatial);
              getControls().add(spatial.getControl(Label.class));
          } else if (spatial.getControl(DialogueBox.class) != null){
              node.attachChild(spatial);
              getControls().add(spatial.getControl(DialogueBox.class));
          } else if (spatial.getControl(TextBox.class) != null){
              node.attachChild(spatial);
              getControls().add(spatial.getControl(TextBox.class));
          } 
        
    }
    
    /**
     * Adds a listener for every control in the interface. Use the controls
     * addListener method directly to if you only want to add a listerner for
     * a single control.
     * @param Listener The listener
     */
    public void addListener(ControlListener Listener){
        for (Control control : getControls()){
            control.addListener(Listener);
        } 
    }
    
    /**
     * Removes the listener from all controls in the interface.
     * @param Listener The listener
     */
    public void removeListener(ControlListener Listener){
        for (Control control : getControls()){
            control.removeListener(Listener);
        } 
    }
    
    /**
     * Disables all controls in this interface.
     */
    private void disable(){
        for (Control control : getControls()){
            control.setEnabled(false);
        } 
    }
    
    /**
     * Enables all controls in this interface.
     */
    private void enable(){
        for (Control control : getControls()){
            control.setEnabled(true);
        } 
    }
    
    /**
     * Resizes the interface. This should only be called after a change
     * in the screen resolution.
     */
    public void resize(){
        for (Control control : getControls()){
            control.resize();
        } 
    }
    
    /**
     * Gets the current control the mouse is over.
     */
    private void select(){
        
        String closest = "";
        float previous = 0;
        
        if (gameManager.inputManager.key(Keys.MOUSE_BUTTON_LEFT).pressed){
        for (Control control : getControls()){
            if (control.isMouseOver()){
                if (control.getzOrder() >= previous){
                    previous = control.getzOrder();
                    closest = control.getName();
                }
            }
        }
        
           for (Control control : getControls()){
              control.setSelected(control.getName().equals(closest));
              control.setFocus(false);
              if (control.getName().equals(closest)){
                 selection = control;
                 control.setFocus(true);
              }
              
           }
           
        }
    }
    
    /**
     * Save the interface to a .j3o file
     * @param file The file to save.
     */
    public void save(File file){
    
    gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
    BinaryExporter exporter = BinaryExporter.getInstance();
    try {
      exporter.save(node, file);
    } catch (IOException ex) {
      Logger.getLogger(UserInterface.class.getName()).log(Level.SEVERE, "Error: Failed to save game!", ex);
    }
    
    gameManager.app.getAssetManager().unregisterLocator(file.getParent(), FileLocator.class);
    
    }
    
    /**
     * Load the interface from a file.
     * @param file The file to load from.
     */
    public void load(File file){
      gameManager.app.getAssetManager().registerLocator(file.getParent(), FileLocator.class);
      node = (Node)gameManager.app.getAssetManager().loadModel(file.getName());
      for (Spatial spatial : node.descendantMatches(Spatial.class, null)) {
          if (spatial.getControl(Image.class) != null){
              spatial.getControl(Image.class).initialize(gameManager);
              getControls().add(spatial.getControl(Image.class));
          } else if (spatial.getControl(Button.class) != null){
              spatial.getControl(Button.class).initialize(gameManager);
              getControls().add(spatial.getControl(Button.class));
          } else if (spatial.getControl(Label.class) != null){
              spatial.getControl(Label.class).initialize(gameManager);
              getControls().add(spatial.getControl(Label.class));
          } else if (spatial.getControl(DialogueBox.class) != null){
              spatial.getControl(DialogueBox.class).initialize(gameManager);
              getControls().add(spatial.getControl(DialogueBox.class));
          } else if (spatial.getControl(TextBox.class) != null){
              spatial.getControl(TextBox.class).initialize(gameManager);
              getControls().add(spatial.getControl(TextBox.class));
          } 
      }
      gameManager.app.getAssetManager().unregisterLocator(file.getParent(), FileLocator.class);
    }
    
    /**
     * Returns the control at the specified index
     * @param index The index
     * @return <code>Control</code>
     */
    public Control getControl(int index){
        return controls.get(index);
    }
    
    /**
     * Returns the specified control.
     * @param name The name of the control to return.
     * @return <code>Control</code>
     */
    public Control getControl(String name){
        for (Control control : controls){
            if (control.getName().equals(name)){
                return control;
            }
        }
        return null;
    }
    
    /**
     * Returns the specified control as a subclass of control.
     * @param <T> The type of control.
     * @param name The name of the control.
     * @param controlType The type of control you are searching for.
     * @return <code>Control</code>
     */
    public <T extends Control> T getControl(String name,Class<T> controlType){
        for (Control control : controls) {
            if (controlType.isAssignableFrom(control.getClass()) && control.getName().equals(name)) {
                return (T) control;
            }
        }
        return null;
    }
    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return The Control list for the interface. This is typically for
     * internal use only.
     */
    public List<Control> getControls() {
        return controls;
    }

    /**
     * @return the displayed
     */
    public boolean isDisplayed() {
        return displayed;
    }

    /**
     * Show or hide the user interface.
     * @param displayed Set true to show the user interface.
     */
    public void setDisplayed(boolean displayed) {
        this.displayed = displayed;
        if (displayed){
          gameManager.app.getGuiNode().attachChild(node);
          gameManager.app.getStateManager().attach(this);
          enable();  
        } else {
          node.removeFromParent();
          gameManager.app.getStateManager().detach(this);
          disable();  
        }
    }
    
    

}
