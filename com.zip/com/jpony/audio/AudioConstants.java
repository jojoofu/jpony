package com.jpony.audio;

public class AudioConstants {
    
    public static final String         AUDIO_NODE = "AUDIO_NODE";
    
}
