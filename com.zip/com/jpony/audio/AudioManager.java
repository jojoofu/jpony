package com.jpony.audio;

import com.jpony.GameManager;
import com.jme3.audio.AudioNode;
import com.jme3.scene.Node;
import com.jme3.scene.SceneGraphVisitor;
import com.jme3.scene.Spatial;

/**
 * The audio manager is hub for the audio nodes in your scene.
 * All audio nodes in your scene are add into the audio manager
 * at load.
 * @author beer money
 */
public class AudioManager {
    
    public GameManager             gameManager;
    public Node                    node;
    
    public AudioManager(GameManager gameManager){
         this.gameManager = gameManager;
         initialize();
    }
    
    private void initialize(){
        node = new Node(AudioConstants.AUDIO_NODE);
        gameManager.node.attachChild(node);
        gameManager.node.depthFirstTraversal(new SceneGraphVisitor() {
          public void visit(Spatial spatial) {
            if (spatial instanceof AudioNode){
                  node.attachChild(spatial);
            }
        }   
       });
    }
    
    /**
     * Plays an audio node.
     * @param name The name of the audio node to play.
     * @param instance Set to true to play an instance of the sound.
     * You can play multiple instances of the same sound at once.
     */
    public void play(String name,boolean instance){
        if (name.equals("")){
            return;
        }
        for (AudioNode audio : node.descendantMatches(AudioNode.class, null)) {
         if (audio.getName().equals(name)){
            if (instance){
                audio.playInstance();
            } else {
                audio.play();
            }
            
         }
        }
    }
    
    /**
     * Adds an audio node to the audio manager.
     * @param node The node to add.
     */
    public void add(AudioNode node){
        this.node.attachChild(node);
    }
    
    /**
     * Removes and audio node from the audio manager.
     * The name of the audio node to remove.
     * @param name 
     */
    public void remove(String name){
       node.getChild(name).removeFromParent();
    }
    
    /**
     * Gets an audio node.
     * @param name The name of the audio node to get.
     * @return <code>AudioNode</code>
     */
    public AudioNode get(String name){
        for (AudioNode audio : node.descendantMatches(AudioNode.class, null)) {
            if (audio.getName().equals(name)){
                return audio;
            }
        }
        return null;
    }
    
}
