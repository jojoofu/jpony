package com.jpony.entity;

/**
* The entity collection type. A collectible entity will
* be added to the player inventory upon activation. There are 
* three collection methods.
* NEVER - The entity will not be collected.
* ON_TOUCH - The entity is collected when the player touches it.
* ON_PRESS - The entity is collected when the action key is pressed.
*/
public enum Collectible {
    
    ON_PRESS,
    ON_TOUCH,
    NEVER
    
}
