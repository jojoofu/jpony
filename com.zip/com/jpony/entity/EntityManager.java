package com.jpony.entity;

import com.jme3.bounding.BoundingBox;
import com.jme3.collision.CollisionResults;
import com.jme3.math.Ray;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jpony.GameManager;
import com.jpony.input.Keys;
import com.jpony.physics.PhysicsControl;
import com.jme3.math.Vector2f;
import com.jme3.scene.Geometry;
import com.jme3.terrain.geomipmap.TerrainQuad;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The entity manager is a hub for entities in your scene. You access
 * and makes changes to entities via the entity manager.
 * @author beer money
 */
public class EntityManager implements EntityListener{


private final GameManager            gameManager;  
    
private boolean                      ignoreTerrain = false;
private CollisionResults             results;
private Ray                          ray;
public Node                          node = new Node(EntityConstants.PICKING_NODE);

public Spatial                       target;
private Spatial                      lastTarget;

private boolean                      isTargeted = false;

private final List                   listener = new ArrayList();

public EntityManager(GameManager gameManager){
     this.gameManager = gameManager;
     initialize();
 }
 
private void initialize(){  
    addPickingNode();
}
 
private void addPickingNode(){
     boolean hasNode = false;
     for (Spatial spatial : gameManager.node.descendantMatches(Spatial.class, null)) {
         if (spatial.getName().equals(EntityConstants.PICKING_NODE)){
              node = (Node)spatial;
              hasNode = true;
         }
     }
     if (!hasNode){
       gameManager.node.attachChild(node);
     }
    }

/**
 * Adds a entity listener.
 * @param listener The listener
 */
public synchronized void addListener(EntityListener listener) {
  this.listener.add(listener);
}
   
/**
 * Removes the entity listener.
 * @param listener The listener to remove
 */
public synchronized void removeListener(EntityListener listener) {
  this.listener.remove(listener);
}

    private synchronized void fireCollect(Spatial spatial) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((EntityListener)iterator.next()).entityCollect(spatial);
        }
    }
    
    private synchronized void fireClick(Spatial spatial) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((EntityListener)iterator.next()).entityPress(spatial);
        }
    }
    
    private synchronized void fireEnter(Spatial spatial) {
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((EntityListener)iterator.next()).entityCursorEnter(spatial);
        }
    }
    
    private synchronized void fireExit(Spatial spatial) {
        if (lastTarget == null){
            return;
        }
        Iterator iterator = listener.iterator();
        while(iterator.hasNext()) {
            ((EntityListener)iterator.next()).entityCursorExit(spatial);
        }
    }

// Remove item from scene and add it to the player's inventory.
private void collect(Spatial spatial){
    
    fireCollect(spatial);
    entityCollect(spatial);
    gameManager.player.inventory.add(spatial);
    gameManager.audioManager.play(spatial.getControl(EntityControl.class).getCollectAudio(), true);
    spatial.removeFromParent();
    
}

/**
 * Adds the item to player inventory if it can be collected on touch.
 * For internal use only. Calling this outside of the main loop will
 * cause the game to crash.
 * @param spatial The spatial to add.
 * @return True if the spatial can be collected.
 */
public boolean collectOnTouch(Spatial spatial){
       
    if (spatial.getControl(EntityControl.class) != null){
         if (spatial.getControl(EntityControl.class).getCollect() == Collectible.ON_TOUCH){
      if (gameManager.physicsManager.intersects(spatial)){
             collect(spatial);
             return true;
        }  
    }
    }
                return false;                       
}

/**
 * Drops the entity at the player world. Still in development.
 * @param spatial The spatial to drop.
 */
public void drop(Spatial spatial){
    
    gameManager.node.attachChild(spatial);
    float y = ((BoundingBox)spatial.getWorldBound()).getYExtent();
    spatial.setLocalTranslation(gameManager.player.node.getLocalTranslation().x,gameManager.player.node.getLocalTranslation().y + (y / 2),gameManager.player.node.getLocalTranslation().z);
    gameManager.player.inventory.remove(spatial.getName());
    
}

// Collect items that are clickable
private void collectOnClick(Spatial spatial){

    if (spatial.getControl(EntityControl.class) != null){
     if (spatial.getControl(EntityControl.class).getCollect() == Collectible.ON_PRESS){
               collect(spatial);
      }    
    }
         
}

/**
 * Updates the entities. For internal use only. Calling this outside
 * the main game loop will cause the game to crash.
 * @param spatial The spatial to update.
 */
public void update(Spatial spatial){
    if (!collectOnTouch(spatial)){
        // spatial is not collected and can be processed
        inRange(spatial);
    } 
}

// Check if the entity is within range of the player
private void inRange(Spatial spatial){
    
    if (spatial.getControl(EntityControl.class) != null) {
       if (gameManager.player.getSpatialDistance(spatial) < spatial.getControl(EntityControl.class).getRange() || spatial.getControl(EntityControl.class).isAlwaysShowInfo() ){
           setInRange(true,spatial);
       } else {
           setInRange(false,spatial);
       }
       }  
}

// Fire the enter / leave range events.
private void setInRange(boolean inRange,Spatial spatial) {
        
        if (inRange && inRange != spatial.getControl(EntityControl.class).isInRange()){
            //is in range swap to picking node
            withinRange(spatial);
            spatial.getControl(EntityControl.class).pass = true;
        } else if (!inRange && inRange != spatial.getControl(EntityControl.class).isInRange()){
            //is out of range swap to scene node
            outOfRange(spatial);
        }
        spatial.getControl(EntityControl.class).setInRange(inRange);
        
}

// Event entity out of range.
private void outOfRange(Spatial spatial){
    spatial.getControl(EntityControl.class).parent.attachChild(spatial);
    spatial.getLocalTranslation().subtractLocal(spatial.getControl(EntityControl.class).world); 
}

// Event entity within range.
private void withinRange(Spatial spatial){
    if (ignoreTerrain){
             if (spatial instanceof TerrainQuad){
                 // do not add to picking node
             } else {
                copyWorld(spatial);
                node.attachChild(spatial);
                spatial.getLocalTranslation().addLocal(spatial.getControl(EntityControl.class).world); 
             }
    } else {
        copyWorld(spatial);
        node.attachChild(spatial);
        spatial.getLocalTranslation().addLocal(spatial.getControl(EntityControl.class).world); 
    }
    
}

private void copyWorld(Spatial spatial){
    spatial.getControl(EntityControl.class).world = spatial.getWorldTranslation().subtract(spatial.getLocalTranslation());
}

/**
 * Gets the entity closest to the cursor. For interal use only. Calling
 * this outside the main game loop will cause the game to crash.
 */
public void getTarget(){
    
        // 1. Reset results list.
        results = new CollisionResults();
        // 2. Aim the ray from cam loc to cam direction.
        if (gameManager.app.getInputManager().isCursorVisible()){
            Vector2f click2d = gameManager.app.getInputManager().getCursorPosition();
            Vector3f click3d = gameManager.cameraManager.camera.getWorldCoordinates(
            new Vector2f(click2d.x, click2d.y), 0f).clone();
            Vector3f dir = gameManager.cameraManager.camera.getWorldCoordinates(
            new Vector2f(click2d.x, click2d.y), 1f).subtractLocal(click3d).normalizeLocal();
            ray = new Ray(click3d, dir);   
        } else {
            ray = new Ray(gameManager.cameraManager.camera.getLocation(), gameManager.cameraManager.camera.getDirection());
        }  
          // 3. Collect intersections between Ray and Shootables in results list.
          node.collideWith(ray, results);
           // 4. Print the results
        if (results.size() > 0 ){
            target = getParentControl(results.getClosestCollision().getGeometry());
            //target = results.getClosestCollision().getGeometry();
            if (target.getControl(EntityControl.class) != null){
                lastTarget = target;
            }
        } else {
            target = null;
        }
        
        fireTargetEvents();
        
}

// Fires the entity target events.
private void fireTargetEvents(){
    
    if ( target != null && target.getControl(EntityControl.class) != null){
        setIsTargeted(true,target);
        if (gameManager.inputManager.key(Keys.ACTION).pressed){
            fireClick(target);
            entityPress(target);
        }
    } else {
        setIsTargeted(false,target);
    }
    
}

// The is targeted event setter.
private void setIsTargeted(boolean isTargeted,Spatial spatial) {
    if (isTargeted && isTargeted != this.isTargeted){
        fireEnter(spatial);
        entityCursorEnter(spatial);
    } else if (!isTargeted && isTargeted != this.isTargeted){
        fireExit(spatial);
        entityCursorExit(lastTarget);
    }
    
    this.isTargeted = isTargeted;
}

// Get the spatial(entity) that is the parent of the target geometry.
private Spatial getParentControl(Geometry geometry){
    
    if (geometry.getControl(EntityControl.class) != null){
        return geometry.getControl(EntityControl.class).parent;
    } else if (geometry.getControl(PhysicsControl.class) != null){
        return geometry.getControl(PhysicsControl.class).parent;
    }
    for(Spatial spatial = geometry.getParent(); spatial != null; spatial = spatial.getParent() ) {
       if (spatial.getControl(EntityControl.class) != null || spatial.getControl(PhysicsControl.class) != null){
         return spatial;
        }    
     }
    return null;

}

    /**
     * @return Should the entity manager ignore terrain quads during picking.
     */
    public boolean isIgnoreTerrain() {
        return ignoreTerrain;
    }

    /**
     * @param ignoreTerrain Setting ignore terrain to true will cause
     * the entity manager to ignore terrain quads during picking. This
     * increase game speed at the possible cost of picking accuracy. By 
     * default this is set to false.
     */
    public void setIgnoreTerrain(boolean ignoreTerrain) {
        this.ignoreTerrain = ignoreTerrain;
    }

    /**
     * @return Is the entity targeted.
     */
    public boolean isIsTargeted() {
        return isTargeted;
    }

    @Override
    public void entityCursorEnter(Spatial spatial) {
       
    }

    @Override
    public void entityCursorExit(Spatial spatial) {
       
    }

    @Override
    public void entityPress(Spatial spatial) {
       if (spatial.getControl(EntityControl.class).isAlwaysShowInfo()){
           if (gameManager.player.getSpatialDistance(spatial) < spatial.getControl(EntityControl.class).getRange()){
              collectOnClick(spatial); 
           }
       } else {
              collectOnClick(spatial);
       } 
    }

   @Override
    public void entityCollect(Spatial spatial) {
       
    }


}
