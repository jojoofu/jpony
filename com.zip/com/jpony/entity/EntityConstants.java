package com.jpony.entity;

public class EntityConstants {
    
    public static final String              PICKING_NODE = "PICKING_NODE";
    public static final String              ENTITY_UI = "ENTITY_UI";
    public static final String              INFORMATION_TEXT = "INFORMATION_TEXT";
    public static final String              ACTION_TEXT = "ACTION_TEXT";
    
}
