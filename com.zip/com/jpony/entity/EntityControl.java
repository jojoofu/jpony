package com.jpony.entity;

import com.jme3.export.InputCapsule;
import com.jme3.export.JmeExporter;
import com.jme3.export.JmeImporter;
import com.jme3.export.OutputCapsule;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import java.io.IOException;

/**
 * The entity control sets the behavior of an entity.
 * An entity is any non static part for you scene. For 
 * example a switch , a door you open or an NPC.
 * @author beer money
 */
public class EntityControl extends AbstractControl {

    private float                         range = 1;
    private String                        actionText = "object activated";
    private Collectible                   collect = Collectible.NEVER;
    private String                        information = "object";
    private boolean                       alwaysShowInfo = false;
    private boolean                       respawn = false;
    private Vector3f                      respawnLocation;
    private float                         respawnTime = 3;
    private String                        collectAudio = "";
    private boolean                       inRange = false;
    
    public Node                           parent;
    public Vector3f                       world = new Vector3f(0,0,0);
    public boolean                        pass = false;
    public int                            passes = 0;
    /**
     * @return The entity's range. The range is how close an entity
     * must be to the player before it is activated by the entity
     * manager.
     */
    public float getRange() {
        return range;
    }
    
    /**
     * @param range The range of the entity.
     */
    public void setRange(float range) {
        this.range = range;
    }

    /**
     * @return The entity collection type.
     */
    public Collectible getCollect() {
        return collect;
    }

    /**
     * @param collect the collectible to set
     */
    public void setCollect(Collectible collect) {
        this.collect = collect;
    }

    /**
     * @return The information about the object. This will information
     * will be displayed once the cursor hovers over the object if the 
     * object is within range.
     */
    public String getInformation() {
        return information;
    }

    /**
     * @param information the information to set
     */
    public void setInformation(String information) {
        this.information = information;
    }

    /**
     * @return The entity will respawn after being removed from
     * the scene.
     */
    public boolean isRespawn() {
        return respawn;
    }

    /**
     * @param respawn the respawn to set
     */
    public void setRespawn(boolean respawn) {
        this.respawn = respawn;
    }

    /**
     * @return The respawn world.
     */
    public Vector3f getRespawnLocation() {
        return respawnLocation;
    }

    /**
     * @param respawnLocation the respawnLocation to set
     */
    public void setRespawnLocation(Vector3f respawnLocation) {
        this.respawnLocation = respawnLocation;
    }
    //Any local variables should be encapsulated by getters/setters so they
    //appear in the SDK properties window and can be edited.
    //Right-click a local variable to encapsulate it with getters and setters.

    @Override
    protected void controlUpdate(float tpf) {
        //TODO: add code that controls Spatial,
        //e.g. spatial.rotate(tpf,tpf,tpf);
    }
    
    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        //Only needed for rendering-related operations,
        //not called when spatial is culled.
    }
    
    public Control cloneForSpatial(Spatial spatial) {
        EntityControl control = new EntityControl();
        //TODO: copy parameters to new Control
        return control;
    }
    
    @Override
    public void read(JmeImporter im) throws IOException {
        super.read(im);
        InputCapsule in = im.getCapsule(this);
        //TODO: load properties of this Control, e.g.
        //this.value = in.readFloat("name", defaultValue);
        this.collectAudio = in.readString("collectAudio","");
        this.actionText = in.readString("actionText","object activated");
        this.range = in.readFloat("activationDistance",1);
        this.collect = in.readEnum("collect",Collectible.class,Collectible.NEVER);
        this.respawn = in.readBoolean("respawn",false);
        this.respawnTime = in.readFloat("respawnTimer",3);
        this.respawnLocation = (Vector3f)in.readSavable("respawnLocation", new Vector3f(0,0,0));
        this.information = in.readString("information","object");
        this.alwaysShowInfo = in.readBoolean("alwaysShowInfo", false);
        this.inRange = in.readBoolean("inRange",false);
    }
    
    @Override
    public void write(JmeExporter ex) throws IOException {
        super.write(ex);
        OutputCapsule out = ex.getCapsule(this);
        out.write(this.collectAudio,"collectAudio","");
        out.write(this.actionText,"actionText","object activated");
        out.write(this.range,"activationDistance",1);
        out.write(this.collect,"collect",Collectible.NEVER);
        out.write(this.respawn,"respawn",false);
        out.write(this.respawnTime,"respawnTimer",3);
        out.write(this.respawnLocation, "respawnLocation", new Vector3f(0,0,0));
        out.write(this.information,"information","object");
        out.write(this.alwaysShowInfo,"alwaysShowInfo",false);
        out.write(this.inRange,"inRange",false);
        //TODO: save properties of this Control, e.g.
        //out.write(this.value, "name", defaultValue);
    }

    /**
     * @return The amount of time until respawn.
     */
    public float getRespawnTime() {
        return respawnTime;
    }

    /**
     * @param respawnTime The respawn time.
     */
    public void setRespawnTime(float respawnTime) {
        this.respawnTime = respawnTime;
    }

    /**
     * @return the collectAudio
     */
    public String getCollectAudio() {
        return collectAudio;
    }

    /**
     * @param collectAudio the collectAudio to set
     */
    public void setCollectAudio(String collectAudio) {
        this.collectAudio = collectAudio;
    }

    /**
     * @return the alwaysShowInfo
     */
    public boolean isAlwaysShowInfo() {
        return alwaysShowInfo;
    }

    /**
     * @param alwaysShowInfo the alwaysShowInfo to set
     */
    public void setAlwaysShowInfo(boolean alwaysShowInfo) {
        this.alwaysShowInfo = alwaysShowInfo;
    }

    /**
     * @return The range of the entity. The player must be within
     * this range of the entity for it to be activated.
     */
    public boolean isInRange() {
        return inRange;
    }

    /**
     * @param inRange Set the range of the entity.
     */
    public void setInRange(boolean inRange) {
        this.inRange = inRange;
    }

    /**
     * @return The text that displays via the entity hud after you 
     * activate(press the action key) and entity.
     */
    public String getActionText() {
        return actionText;
    }

    /**
     * @param actionText Set the action information string
     */
    public void setActionText(String actionText) {
        this.actionText = actionText;
    }
    
}
