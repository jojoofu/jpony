package com.jpony.entity;

import com.jme3.scene.Spatial;

/**
 * The entity event listener.
 * @author beer money
 */
public interface EntityListener {
    
    /**
     * The cursor enters the area of the entity.
     * @param spatial The entity.
     */
    public void entityCursorEnter(Spatial spatial);
    
    /**
     * The cursor leaves the area of the entity.
     * @param spatial The last entity targeted.
     */
    public void entityCursorExit(Spatial spatial);
    
    /**
     * The entity action key pressed event.
     * @param spatial The entity.
     */
    public void entityPress(Spatial spatial);
    
    /**
     * The entity collection event.
     * @param spatial The entity
     */
    public void entityCollect(Spatial spatial);
            
}
